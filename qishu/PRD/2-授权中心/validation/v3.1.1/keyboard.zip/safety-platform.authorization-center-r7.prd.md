<!-- prd-workspace:{"schemaVersion":1,"docId":"safety-platform.authorization-center","version":"0.3.0","revision":7,"updatedAt":"2026-09-12T05:13:19.591Z"} -->
# 授权中心产品需求文档

本文将账号、组织、权限、应用接入和临时委托串成可评审的业务流程，供产品、开发、测试和安全负责人共同确认。覆盖原始 PRD 的 14 项功能，并逐项指出 DDL 的支撑情况、缺口和实施前需要确定的规则。

| 元信息 | 内容 |
|---|---|
| 文档 ID | safety-platform.authorization-center |
| 业务版本 | 0.3.0 |
| 状态 | 待决策 |
| 日期 | 2026-09-12 |
| 适用系统 | 安全生产智能体平台·授权中心；名称取自输入 DDL |
| 整理方式 | prd-writer v3.1（技能元信息3.1.1），revise / full；复核原始资料，展开测试数据、用例与逐项验收 |
| 责任角色 | 产品负责人、授权业务负责人、安全负责人、技术负责人、DBA、测试负责人；具体人员待指定 |
| 原始资料 | [PRD.md](PRD.md)、[DDL.md](DDL.md)，保留原文件 |
| 技能依据 | [prd-writer v3.1](../skills/prd-writer-v3.1/prd-writer/SKILL.md) |
| 核验限制 | 已读取两份资料并做文本核对；未获得授权中心业务实现、部署数据库、现网协议和批准记录；未执行 SQL 或业务接口 |
| 文件使用 | Markdown 为正文来源；配套 HTML 可离线阅读、搜索、编辑、批注和导出；编辑修订号不代表业务版本获批 |

### 编号说明

编号用于追溯，不表示优先级、批准或验收状态。沿用既有两位序号；本次不重新编号，也不将 AC 改为分层编号。表中九类业务前缀均在本文使用。P0/P1/P2 是优先级，不是需求编号；HTML 自动生成的 RV 是评审记录编号，填写人身份未经验证。

| 前缀 | 含义 | 格式与示例 | 出现章节 |
|---|---|---|---|
| S | 资料来源及核验范围 | S-01，顺序两位编号 | 文首来源标记；正文引用 |
| US | 用户故事与功能范围 | US-01，顺序两位编号 | 第一、二章；第九章追溯 |
| BR | 业务规则 | BR-01，顺序两位编号 | 第二章；接口、状态及测试引用 |
| AC | 验收标准 | AC-01，本文使用独立两位编号 | 第二章；第九、十章 |
| API | 接口操作定义；一组可含多个明确操作 | API-01，顺序两位编号 | 第五章；第九章追溯 |
| DB | 数据库设计、缺口及修订条目 | DB-01，顺序两位编号 | 第四章；测试与待决策引用 |
| TC | 业务测试组与独立用例 | TC-01为原组；TC-01-001为组内独立用例 | 第九章；第十章逐项验收 |
| TD | 合成测试数据集 | TD-01，顺序两位编号 | 第九、十章及本地生成器 |
| Q | 待决策事项 | Q-01，顺序两位编号 | 第十二章；全篇引用 |
| RV | 本机文档评审记录（本文尚未生成） | RV-时间戳编码，由 HTML 工具生成 | 文档评审记录；本文未使用实例 |

### 来源标记

“原文要求”表示用户资料中明确写出的目标，未证明已经实现或经过批准；“DDL事实”表示 SQL 文本中确实存在的声明，不代表数据库已经建成；“建议方案”表示为补齐流程提出的设计；“待决策”表示需要责任角色确定。下文 BR、AC、API 中的建议也受关联 Q 约束，不能因写成验收语句就视为已批准。

| 来源编号 | 资料及定位 | 可支持的结论 |
|---|---|---|
| S-01 | PRD.md：鉴权中心验证流程 | AppKey 检查、静态权限、数据范围、委托兜底及 401/403 |
| S-02 | PRD.md：功能需求 1—14 | 原始功能范围与明确列出的操作 |
| S-03 | DDL.md：PostgreSQL DDL 1—14 | 14 张业务主表、1 张默认分区的声明及字段、索引、示例数据 |
| S-04 | DDL.md：使用说明 | PostgreSQL 12+ 的资料约定；不是实测环境 |
| S-05 | 技能 project-profile.md | up-sl-back/JPA/tb_ 前缀/全 HTTP 200 等模板背景；本项目未确认适用，不直接采用 |

### 阅读导航

- 业务评审：第一、二、六、十二章。
- 开发评审：第三、四、五、八、十一章。
- 测试评审：第九、十章，并逐项查看 AC 对应的 Q。
- 数据问题：第四章 DB-01—DB-18；文档验证证据见同目录的《交付验证报告》。

合成往返验证：中文 😀 < > & `code`。

| 字段 | 内容 |
|---|---|
| 测试 | a\|b |

```json
{"内容":"中文", "pipe":"a|b", "end":"</script>"}
```

```sql
SELECT '合成验证';
```

## 一图统揽

图中框内为原文 14 项本期功能，实线连接入口、主要处理步骤与数据，虚线表示依赖或待决策约束，不表示已实现接口。成员维护和委托处理动作仍是待批准的闭环补充建议。此图只提供导航，权限判断以 BR-01—BR-07 为准；图和条款必须同步维护。

```mermaid
flowchart TB
  Admin["管理员 / 后台配置入口"]
  Actor["自然人、服务账号 / 登录或场景入口"]
  Client["接入应用 / 授权与开放接口入口"]
  Auditor["审计人员 / 日志查询入口"]
  subgraph Scope["本期：授权中心原文 14 项功能"]
    Identity["账号、组织、用户组 US-01 / US-02 / US-03"]
    Config["参数、字典 US-05 / US-06"]
    Policy["操作、权限组、用户与组织授权 US-07 / US-08 / US-09 / US-10"]
    Token["令牌管理 US-04；开放能力 US-14 复用"]
    App["应用注册、绑定、明细与刷新 US-11"]
    Gate["应用身份检查 BR-01；账号身份与应用操作上限为建议 BR-02 / BR-03"]
    Static{"静态操作权限 BR-04"}
    RowScope["返回 SELF / DEPT / SPECIFIED 数据范围 BR-05"]
    Delegation["委托申请 US-12；批准/拒绝/撤销待 Q-07"]
    Fallback{"仅静态无权限时匹配有效委托 BR-06 / BR-07"}
    ResourceScope["仅指定资源和有效期内的许可"]
    Reject["拒绝：应用无效 401；无操作许可 403"]
    Audit["日志新增、详情、列表和自动归档 US-13"]
    IdData[("account / organization / user_group / user_group_account / token")]
    PolicyData[("operation / permission_group / permission_group_account / permission_group_org / app_authorization")]
    ConfigData[("sys_param / sys_dict")]
    DelegationData[("delegation")]
    AuditData[("audit_log 与默认分区；建库问题 DB-01—DB-03")]
  end
  Business["业务系统：可信资源归属、行过滤、单资源写入与执行结果 Q-04"]
  Dependencies["外部依赖待核验：身份凭据设施、组织成员来源、时钟、归档存储"]
  Decisions["Q-01—Q-16：隔离/继承/凭据/委托/撤权/审计/协议/迁移待决策"]
  Excluded["不自动纳入：SSO、通用审批引擎、转授链、业务设备控制执行"]
  Admin --> Identity
  Admin --> Config
  Admin --> Policy
  Admin --> App
  Actor --> Token
  Actor --> Delegation
  Client --> Gate
  Client --> Token
  Client --> Identity
  Auditor --> Audit
  App -.-> Gate
  Token -.-> Gate
  Policy -.-> Static
  Identity -.-> Static
  Gate -->|通过| Static
  Gate -->|拒绝| Reject
  Static -->|有操作权限| RowScope
  Static -->|无操作权限| Fallback
  Delegation -.-> Fallback
  Fallback -->|全部条件满足| ResourceScope
  Fallback -->|任一条件不满足| Reject
  RowScope --> Business
  ResourceScope --> Business
  Gate -.-> Audit
  Reject -.-> Audit
  Business -.-> Audit
  Identity --- IdData
  Token --- IdData
  Policy --- PolicyData
  App --- PolicyData
  Config --- ConfigData
  Delegation --- DelegationData
  Audit --- AuditData
  Dependencies -.-> Identity
  Dependencies -.-> Token
  Dependencies -.-> Delegation
  Dependencies -.-> Audit
  Decisions -.-> Scope
  Scope -.-> Excluded
```

“有静态权限但目标行超范围”由业务系统拒绝该行，不转入委托；图中因此没有从 RowScope 到 Fallback 的路径。开放获取用户详情/权限使用 API-14 的应用、对象与字段限制，不能因图中入口连线而获得账号管理权。其他认证失败、依赖异常的具体响应按第二、五、八章及 Q-15 定稿，图中 401/403 不覆盖所有错误类型。

图表显示说明：左侧目录显示二至六级标题；父级定位并折叠/展开，箭头只折叠，子级直达内容。配套《授权中心.prd.html》已内嵌 Mermaid 11.16.0，六张图在正文原位离线渲染；可展开复制源码、切换适应宽度/原始尺寸，修改或重新导出HTML后按当前源码重绘。状态表始终保留。旧版独立《授权中心.图示.html》仅为历史副本，本版以主HTML为准。

## 修订记录

| 业务版本 | 日期 | 修改者/工具 | 原因与影响 | 批准情况 |
|---|---|---|---|---|
| 0.3.0 | 2026-09-12 | Codex；prd-writer 3.1.1 | 补全14表和默认分区DDL、表列注释、索引依据与验证对应；多级目录折叠和子标题定位；保留141用例/10数据集/30验收点与未决Q | 无真人签署，待决策 |
| 0.2.0 | 2026-09-12 | Codex；prd-writer v3.1 | 保留原US/BR/AC/API/DB/TC/Q，新增TD-01—TD-10；将30测试组展开为141条独立用例，逐项列30个AC；生成可复现夹具，主HTML原位渲染6图；业务规则未获批准 | 无真人签署，待决策 |
| 0.1.1 | 2026-09-12 | Codex，按调整后的 prd-writer v3.0 重新生成 | 增加编号说明、总览图与状态图；状态表拆为当前状态/事件/下一状态并与图逐条对应；沿用全部 US/BR/AC/API/DB/TC/Q 编号，未批准新增业务；重新执行文档验证 | 无真人签署，待决策 |
| 0.1.0 | 2026-09-08 | Codex，按 prd-writer v3.0 整理 | 建立 US/BR/AC/API/TC/Q 追溯，覆盖 14 项功能，记录 DDL 差异；不改变原始文件 | 无真人签署，待决策 |

## 一、背景与目标

### 1.1 业务背景与价值

原文要求接入应用统一验证用户能否执行指定操作，再限制可访问的数据行；当用户没有静态操作权限时，可以通过有效委托访问指定资源。后台同时维护账号、组织、跨部门用户组、操作码、权限组、应用授权和审计日志。现有资料缺少部分关联模型、生命周期动作与公共接口协议，开发人员无法仅凭原始清单确定完整行为。

本文中“授权”指配置或授予权限，“鉴权”指对一次请求作出允许或拒绝判断。应用身份、账号身份、操作权限、资源范围是分别检查的条件；应用接入成功不表示该应用中的所有用户都具备全部操作权限。

### 1.2 角色与主要任务

| 角色 | 核心任务 | 来源状态 |
|---|---|---|
| 账号/组织管理员 | 管理账号、组织与成员关系 | 管理功能为原文要求；岗位拆分及授权范围待 Q-01 |
| 权限管理员 | 维护操作码、权限组及用户/组织分配 | 原文要求；管理角色本身如何授权待 Q-01 |
| 应用接入负责人 | 注册应用、绑定操作授权、检查接入状态 | 原文要求；可管理哪些应用待 Q-01 |
| 普通用户 | 登录、退出、在自己获准范围内操作业务数据 | 原文要求；自然人登录方式待 Q-05 |
| 服务账号 | 通过应用凭据或证书进行自动化访问 | 原文要求；身份与凭据绑定待 Q-05 |
| 委托申请人/授权处理人 | 申请指定资源的临时访问，由有权主体处理 | 申请为原文要求；处理人及审批规则待 Q-07 |
| 审计人员/运维人员 | 查询操作记录、处理归档故障 | 日志查询和归档为原文要求；岗位权限待 Q-09 |

### 1.3 本期范围与优先级建议

P0 表示鉴权闭环及上线安全前提，P1 表示原文范围内的管理能力和运行能力，P2 表示可延期增强。优先级是排期建议，不是已批准承诺；本期包含下表全部原文功能，若裁剪 P1 需要产品重新确认。

| US | 功能 | 本期操作范围 | 优先级建议 | 数据支撑与缺口 |
|---|---|---|---|---|
| US-01 | 账号管理 | 新增、编辑、删除、详情、列表；服务账号登录限制 | P0 | account；凭据关联、删除和冻结效果待定 |
| US-02 | 组织结构管理 | 新增、编辑、删除、详情、列表 | P0 | organization；账号归属关系缺失 |
| US-03 | 用户组管理 | 新增、编辑、删除、详情、列表；成员维护为必要补充建议 | P1 | user_group、user_group_account；不推定参与授权 |
| US-04 | 令牌管理 | 登录、退出、刷新令牌、注销令牌 | P0 | token；刷新配对与场景生命周期缺失 |
| US-05 | 参数管理 | 新增、编辑、删除、详情、列表 | P1 | sys_param；类型、生效范围和敏感参数规则待定 |
| US-06 | 字典管理 | 新增、编辑、删除、详情、列表 | P1 | sys_dict；字典项结构和引用检查待定 |
| US-07 | 操作管理 | 新增、详情、列表 | P0 | operation；本期不自行增加编辑、删除入口 |
| US-08 | 权限组管理 | 新增、编辑、删除、详情、列表 | P0 | permission_group；operation_ids 完整性需补齐 |
| US-09 | 权限组与用户关联 | 新增、编辑、删除、详情、列表 | P0 | permission_group_account |
| US-10 | 权限组与组织关联 | 新增、编辑、删除、详情、列表 | P0 | permission_group_org；继承规则待定 |
| US-11 | 应用授权 | 应用注册、操作授权码绑定、获取授权明细、验证授权、授权刷新 | P0 | app_authorization；单组/多组及应用权限上限待定 |
| US-12 | 委托授权 | 申请委托授权；激活、拒绝、撤销为闭环补充建议 | P0 | delegation；状态转换、应用隔离、授权来源待定 |
| US-13 | 日志中心 | 新增、详情、列表、自动归档 | P0 核心记录 / P1 归档 | audit_log；分区主键及拒绝日志字段有缺口 |
| US-14 | 开放能力 | 获取、注销、刷新令牌；获取用户详情、用户权限 | P0 | 复用 US-04、US-11；开放字段与对象范围待定 |

### 1.4 非本期范围

原文未提出的多租户平台、SSO/第三方身份联邦、多因素认证、通用审批引擎、委托链转授、跨应用委托共享、权限套餐、账单、设备控制执行、批量导入导出和可视化报表均不自动纳入。多租户是否存在是 Q-01 的架构前提，不能把资料缺少 tenant_id 解读为已经确认单租户。HTML 文档工具的批注不属于授权中心的产品功能。

### 1.5 成功指标与依赖

| 指标 | 定义 | 基线/目标/观察周期 | 数据来源与责任角色 |
|---|---|---|---|
| 鉴权正确性 | 按批准规则计算的允许/拒绝结果与实际一致的比例 | 基线未知；目标由测试与安全负责人批准；每次候选版本验证 | US/AC/TC 矩阵与测试记录 |
| 接入完成时间 | 从应用注册开始到首次通过端到端授权校验的耗时 | 基线、目标、统计周期待 Q-13 | 接入过程记录；应用接入负责人 |
| 权限变更生效时延 | 撤权或冻结提交至所有接入节点拒绝旧权限的时间 | 目标和测量边界待 Q-08、Q-13 | 变更审计、节点校验结果；技术负责人 |
| 审计可追溯性 | 抽样操作是否可关联主体、应用、动作、资源、权限来源和结果 | 目标、抽样规模、周期待 Q-09、Q-13 | 审计查询与业务执行记录；审计负责人 |

依赖包括：可信账号身份来源、组织成员数据来源、业务资源到创建者/部门的映射、应用凭据验证设施、服务端时钟、审计存储和实际 API 协议。每项的现有实现与维护责任人均待提供，不推定宿主 deepseek-harness 的组件就是授权中心后端。

## 二、用户故事、规则与验收

### 2.1 用户故事与可见结果

| 编号 | 用户故事 | 完成后的用户可见结果 |
|---|---|---|
| US-01 | 作为账号管理员，我需要维护自然人和服务账号，便于给正确主体分配访问资格 | 可查询详情与状态；凭据不在详情中明文显示；失败定位到字段 |
| US-02 | 作为组织管理员，我需要维护单位、部门、班组和岗位树，使组织归属可被权限规则使用 | 展示父子关系；无效移动或删除给出引用原因 |
| US-03 | 作为管理员，我需要将跨部门人员组成用户组，便于管理成员 | 可查看和调整成员；界面不将用户组标成权限组 |
| US-04 | 作为用户或服务账号，我需要获取、刷新和注销令牌，按正常或场景方式访问 | 显示登录结果和有效期；过期提示重新认证；刷新失败不反复自动重试 |
| US-05 | 作为配置管理员，我需要维护系统参数，使参数值可查询和调整 | 显示配置值及生效说明；未批准参数不能随意控制鉴权行为 |
| US-06 | 作为配置管理员，我需要维护字典，使业务使用一致的选项 | 可看到编码、选项和引用错误；不能误把空字典当全部选项 |
| US-07 | 作为权限管理员，我需要登记操作码，使应用和权限组使用同一操作标识 | 操作码唯一且能查询；明确本期不提供编辑/删除 |
| US-08 | 作为权限管理员，我需要将操作组合为权限组，集中维护可执行动作 | 显示组内操作和变更影响；冲突后先刷新再提交 |
| US-09 | 作为权限管理员，我需要把权限组授予指定账号，并可调整或撤回关联 | 显示直接授权来源；重复提交不创建重复关联 |
| US-10 | 作为权限管理员，我需要把权限组授予组织，使符合归属规则的成员继承权限 | 显示组织授权来源及继承范围，范围规则待 Q-02 |
| US-11 | 作为应用接入方，我需要声明应用可使用的操作并请求授权判断 | 区分应用无效、无操作权限和数据限制；返回可解释的授权结果 |
| US-12 | 作为缺少静态权限的用户，我需要申请指定资源的临时授权 | 看到申请状态、资源清单和有效时间；未生效委托不能使用 |
| US-13 | 作为审计人员，我需要查明实际执行人及授权来源，并在归档后定位记录 | 按 trace、账号、应用、操作、时间筛选；日志内容脱敏 |
| US-14 | 作为已接入应用，我需要通过开放接口获取令牌和获准的用户信息 | 开放返回受限字段与当前应用权限，不能读取凭据或任意账号 |

### 2.2 主流程与鉴权分支

后台配置建议顺序：登记操作 → 建立权限组 → 分配用户/组织 → 注册应用并绑定授权 → 准备账号身份与令牌 → 应用发起校验 → 业务系统按授权结果执行 → 记录鉴权和业务结果。账号归属组织的配置入口是 Q-02 批准后必需的补充能力。

| 步骤 | 输入与检查 | 结果与后续 | 依据/状态 |
|---|---|---|---|
| 1 | 请求携带 AppKey；确认应用存在且非 frozen | 无效或冻结返回 HTTP 401；不进入委托 | S-01 原文要求；AppKey 之外的身份凭据见 Q-05 |
| 2 | 核验用户身份、令牌状态、账号状态及场景上下文 | 失败拒绝请求；不得信任客户端任意传入的 userId | 建议方案 BR-02，Q-05、Q-06 |
| 3 | 检查操作是否属于应用获准的操作集合 | 不属于则拒绝；委托也不能越过应用权限上限 | 建议方案 BR-03，Q-03 |
| 4 | 查找账号直接权限组和符合组织归属规则的权限组，判断是否包含 operation_code | 命中转步骤 5；未命中才转步骤 6 | S-01；组织继承细节 Q-02 |
| 5 | 根据应用的 SELF/DEPT/SPECIFIED 生成行级范围 | 返回静态操作许可与数据范围；本分支结束；不因某行不在范围内转委托 | S-01 原文顺序；单资源写操作执行方式见 BR-05 |
| 6 | 委托同时匹配被授权人、包含目标操作的权限组、资源类型、资源 ID 和有效时间；建议再检查 active 状态和应用归属 | 全部满足才允许指定资源；否则 HTTP 403 | 五项匹配来自 S-01；额外状态/应用检查见 Q-07 |
| 7 | 业务系统按结果过滤列表或验证单资源归属，再执行其自身业务动作 | 授权结果不能替代业务动作执行结果；业务失败另行记录 | 建议方案 BR-05、BR-21 |

### 2.3 鉴权决策表

下表保留“静态权限失败才进入委托”的原文规则。建议项批准前，依赖它的实现和验收不得放行。

| 应用身份 | 用户身份 | 应用操作许可 | 用户静态许可 | 委托 | 决策 |
|---|---|---|---|---|---|
| 无效/冻结 | 任意 | 任意 | 任意 | 任意 | HTTP 401，无许可（原文） |
| 有效 | 无效/冻结/令牌失效 | 任意 | 任意 | 任意 | 拒绝认证，无许可（建议） |
| 有效 | 有效 | 不包含操作 | 任意 | 即使匹配 | 拒绝，不进入委托（Q-03 建议） |
| 有效 | 有效 | 包含操作 | 有 | 不查询 | 返回 STATIC 与行级过滤条件；按钮是否可用仅取决于操作许可 |
| 有效 | 有效 | 包含操作 | 无 | 全部条件满足 | 返回 DELEGATION 与明确资源集合；不推导整个部门权限 |
| 有效 | 有效 | 包含操作 | 无 | 无、未生效、撤销、过期或任一条件不符 | HTTP 403，无许可 |
| 有效 | 有效 | 包含操作 | 有，但目标行超范围 | 即使有委托 | 目标行不能执行；不补查委托（保留原文，Q-04 确认其业务适用性） |

列表操作通常没有单个 resourceId，原文委托判定无法直接覆盖。Q-04 确认之前，不将缺少 resourceId 解释成匹配全部委托资源，也不将操作许可返回值解释成全量数据许可。

### 2.4 业务规则

| 编号 | 规则 | 来源状态/待决策 |
|---|---|---|
| BR-01 | AppKey 无效或应用 frozen 时返回 HTTP 401；任何委托都不能绕过该检查 | S-01 原文要求 |
| BR-02 | 用户身份应从可信认证上下文取得；冻结账号、撤销/过期令牌、错误 Scene 上下文不能用于访问；服务账号禁止密码登录且强制 IP 白名单 | 服务账号限制为 S-02；身份核验与冻结效果建议，Q-05、Q-06、Q-08 |
| BR-03 | 建议有效操作 = 应用获准操作集合 ∩（账号直接权限 ∪ 组织继承权限）；委托也受应用操作上限约束 | 原文未明确交集；Q-03 |
| BR-04 | 有静态操作权限时读取应用数据范围；无静态操作权限时才查询委托；按钮可见性不按数据范围决定 | S-01 原文要求 |
| BR-05 | SELF 限本人创建数据；DEPT 按批准的部门集合；SPECIFIED 按指定组织集合。列表、计数及单资源修改均需执行范围约束；空集合不得转为全量；业务服务负责将逻辑范围映射到实际字段 | 范围类型来自 S-01/S-03；DEPT 子级冲突及执行方式见 Q-02、Q-04 |
| BR-06 | 委托必须同时匹配 grantee、含目标 operation_code 的 permission_group、resource_type、resourceId∈resource_ids、valid_from≤now≤valid_until | S-01 原文要求；有效期保留闭区间，时区待 Q-11 |
| BR-07 | 建议只接受 active 委托，绑定当前应用，且授权人当前具备可授出的操作和资源权限；不得自批或再次转授，除非另行批准 | Q-07；当前 DDL 不能完整表达 |
| BR-08 | username、phone、email、group_code、operation_code、param_code、dict_code、app_code、app_key 的非空值按原 DDL 全局唯一；大小写、规范化和编码复用不能由客户端各自决定 | S-03；Q-01、Q-10 |
| BR-09 | 组织树不得自为父级或形成循环；父级变化应同步所有受影响 org_path；账号归属、主部门和多部门规则须明确 | 树形模型来自 S-03；补充规则建议，Q-02、Q-12 |
| BR-10 | 用户组是跨部门成员集合；当前鉴权来源没有用户组到权限组的关联，不赋予隐含操作权限 | S-01/S-02/S-03；若需参与授权另行决策 Q-02 |
| BR-11 | 权限组引用的操作必须存在；当前权限组无 name 唯一约束，不把同名自动当同一组；编辑操作集合需展示授予/撤回影响 | 数据事实 S-03；校验和影响提示建议 Q-03、Q-12 |
| BR-12 | 用户/组织与权限组的同一组合只能存在一条；关联编辑是替换目标组合并原子查重，编辑不存在记录不得转新增 | 组合唯一来自 S-03；编辑语义建议 Q-12 |
| BR-13 | 应用注册生成或登记唯一 AppKey；AppSecret 禁止进入列表、常规详情和日志；操作绑定不得修改其他应用或用户共用权限组而未提示影响 | 前半来自 S-02/S-03；密钥展示、组归属和绑定方案 Q-03、Q-05 |
| BR-14 | “应用授权刷新”与“令牌刷新”是不同动作；授权刷新是否重算授权、更新缓存或轮换凭据须明确，不能默认更换 AppSecret | Q-08 |
| BR-15 | Master-Token 用于正常登录，Scene-Token 用于场景登录；原文写有效期 1 小时，但未说明是否包括 refresh_token | S-02；具体令牌寿命及签发规则 Q-06 |
| BR-16 | 建议刷新令牌与账号、应用、会话、场景及访问令牌关联；一次性轮换刷新令牌，并原子处理并发刷新；失败不得签发额外会话 | Q-06、Q-12；DDL 缺配对字段 |
| BR-17 | 退出与注销令牌的作用范围必须分别确定；建议退出当前会话，管理员强制注销按明确范围；账号冻结/撤权应在批准时延内生效 | Q-06、Q-08 |
| BR-18 | 委托申请生成 pending 记录；申请成功不代表生效。批准、拒绝、撤销与自然过期分别定义主体和审计；时间判断不依赖定时任务已改 status | pending/状态来自 S-03；闭环动作 Q-07 |
| BR-19 | 所有删除在确定硬删除/停用/软删除、引用检查和审计保留规则后开放；界面展示影响，引用检查与执行原子一致 | 原文包含删除；目标语义待 Q-10、Q-12 |
| BR-20 | 参数和字典按编码查询；编辑/删除前检查被业务引用的规则；参数值类型、空值和生效时机不能从 TEXT 推断 | S-02/S-03；Q-14 |
| BR-21 | 审计保存实际执行人，委托场景为 grantee；建议另记 grantor、delegationId、权限来源、策略版本和动作阶段；鉴权允许与业务执行成功分别记录 | 实际执行人来自 S-03；扩展字段与阶段 Q-09 |
| BR-22 | 审计请求/响应体脱敏，凭据和令牌不入日志；普通用户不能任意新增、编辑、删除审计记录；无认证主体的拒绝也应留痕 | 脱敏来自 S-03；写入主体和拒绝记录设计 Q-09 |
| BR-23 | 自动归档必须有保留期、目标位置、完整性验证、查询/恢复方式和失败重试；分区创建不等同于已完成归档 | 自动归档来自 S-02；Q-09 |
| BR-24 | 开放令牌接口复用同一令牌生命周期；用户详情和权限输出须受调用应用、目标用户和字段授权限制 | 原文开放能力；范围 Q-01、Q-06、Q-15 |
| BR-25 | API 不直接序列化数据库实体；账号密码散列、AppSecret、完整令牌只能按特定签发流程返回给获准主体 | 建议方案 Q-05、Q-15 |
| BR-26 | 新增与编辑入口分离；新增不得携带用于选择既有记录的 id；编辑必须指定已有对象；不可写字段不能接受客户端覆盖 | 建议方案 Q-12、Q-15 |
| BR-27 | 权限、组织、应用、委托关键编辑建议使用读取版本进行原子比较；旧版本冲突保留表单并提示刷新，不静默覆盖 | Q-12；DDL 无 version 字段 |
| BR-28 | 所有时间点建议使用带偏移量的 API 表达和统一服务端时钟；原 TIMESTAMP 不包含时区，迁移前必须确定旧值时区；更新时间要由明确主体维护 | Q-11 |
| BR-29 | 身份/权限依赖异常时建议拒绝当前受保护操作并返回可诊断错误，不复用不确定的允许结果；审计失败是否阻断业务单独决策 | Q-08、Q-09 |
| BR-30 | 每次重试仍校验当前授权；唯一关联以组合键保证不重复；委托申请和凭据签发需要独立幂等策略，不能按“POST 可重试”笼统处理 | Q-06、Q-07、Q-12 |

### 2.5 管理操作权限矩阵（建议，Q-01）

下表中的“负责范围”尚未确认是全平台、组织、应用还是租户范围；不构成默认授予。所有管理主体也需按动作、对象和字段逐次授权，不能依靠隐藏按钮保护接口。

| 主体 | 动作与对象 | 对象/数据范围 | 可写/可读字段 | 状态与审计 |
|---|---|---|---|---|
| 账号管理员 | account 增改删查、冻结/解冻建议动作 | 已授予的账号范围 | 可写基础资料；凭据通过专用流程；无散列读取权 | 删除和冻结依 Q-10/Q-08；审计前后摘要 |
| 组织管理员 | organization 与成员关系增改删查 | 已授予的组织子树，层级规则待定 | 名称、类型、父级、排序、成员；路径由服务端维护 | 防环、引用检查与移动审计 |
| 配置管理员 | user_group、sys_param、sys_dict 增改删查 | 获准的配置范围 | 业务字段；敏感参数可见性待定 | 成员/引用变化审计 |
| 权限管理员 | operation 新增/查；权限组及关联增改删查 | 获准管理的操作集合与被授权主体 | 组内操作、关联目标；不能通过编辑给自己超额授权 | 当前权限检查与版本冲突处理 |
| 应用接入负责人 | 注册、绑定、明细、刷新 | 负责的应用 | 授权组/操作、数据范围；密钥按单独规则 | 绑定/刷新前后授权摘要 |
| 已认证用户 | 获取/刷新自身令牌、退出、申请委托 | 自己与被允许的场景/资源 | 不可指定审批结果或任意 grantee/grantor | 生命周期检查与拒绝审计 |
| 委托处理人 | 激活/拒绝/撤销建议动作 | 经批准可授出的应用、操作与资源 | 决策及理由；不能越权扩大申请范围 | pending/active 检查与独立处理记录 |
| 接入应用服务 | 请求鉴权、调用开放接口 | 当前应用和获准的账号上下文 | 只读获准用户字段；不能读密码/密钥 | 凭据、IP、令牌、动作及资源联合验证 |
| 审计人员 | 日志详情/列表 | 已授权审计范围 | 脱敏内容只读 | 查询审计；不得改写历史事件 |
| 可信系统写入者/归档任务 | 写入日志、归档 | 服务端确定的事件与分区 | 由事件生成；不允许客户端冒充操作人 | 追加记录、归档完整性与恢复记录 |

### 2.6 验收标准

以下均为待执行业务用例；含建议方案的行须先关闭对应 Q。Then 同时给出不能发生的效果。

| AC | 关联 US / BR | 场景 | Given | When | Then |
|---|---|---|---|---|---|
| AC-01 | US-11 / BR-01 | 应用身份拒绝 | AppKey 无效或应用 frozen | 验证应用授权 | 返回 HTTP 401；不查询委托放行，不执行业务动作 |
| AC-02 | US-01、US-04 / BR-02 | 服务账号认证 | 服务账号及批准的凭据/IP 配置 | 使用密码或白名单外 IP 登录 | 拒绝且不签发令牌；合法凭据和合法 IP 的对照组可进入后续认证 |
| AC-03 | US-09、US-11 / BR-03、BR-04 | 直接静态权限 | 应用和账号共同包含目标操作 | 发起校验 | 返回 STATIC 与数据范围；不查询委托 |
| AC-04 | US-02、US-10 / BR-03、BR-09 | 组织继承 | 账号归属及上下级规则已批准 | 在匹配/不匹配组织执行同一操作 | 仅符合归属规则者继承；同名组织不互相继承 |
| AC-05 | US-11 / BR-04、BR-05 | 三种数据范围 | 准备本人、其他人、当前部门、下级和指定组织数据 | 列表、计数、单资源写操作 | 各自仅使用批准范围；空集合不放大；行限制不决定按钮许可 |
| AC-06 | US-11、US-12 / BR-04、BR-06 | 委托兜底条件 | 无静态许可，有全部匹配的有效委托 | 请求委托资源，再逐一破坏五个条件 | 匹配允许且只允许指定资源；任一不符 HTTP 403 |
| AC-07 | US-12 / BR-07、BR-18 | 委托状态和越权 | pending/revoked/过期委托、跨应用委托及越权 grantor | 请求资源 | 按批准规则全部拒绝；不能借状态字段或客户端 ID 绕过检查 |
| AC-08 | US-11、US-12 / BR-04、BR-05 | 静态行权限不兜底 | 有静态操作权限、目标行超范围、另有委托 | 修改该行 | 按原文不进入委托；不产生修改；若业务需改变须先批准 Q-04 |
| AC-09 | US-01 / BR-08、BR-25、BR-26 | 账号维护 | 获准管理员及正常账号 | 新增、编辑、详情、列表；提交重复用户名或只读字段 | 正常流程成功；重复和只读字段拒绝；输出不含密码散列 |
| AC-10 | US-02 / BR-09、BR-27 | 组织树一致 | 有至少三层组织 | 新增、查详情/列表、移动父级、构造循环 | 合法树和路径一致；循环/旧版本写入失败，原树保持一致 |
| AC-11 | US-03 / BR-10、BR-12 | 跨部门用户组 | 不同部门账号与一个用户组 | 增改删查组、重复添加成员 | 成员组合唯一；加入用户组不会自动获得操作权限 |
| AC-12 | US-05、US-06 / BR-08、BR-20 | 参数字典维护 | 已批准值结构和引用规则 | 增改删查，提交重复编码、非法 JSON/空项、删除被引用值 | 合法流程可用；非法输入及禁止删除拒绝，原值保留 |
| AC-13 | US-07、US-08 / BR-08、BR-11 | 操作与权限组 | 已登记操作与引用它的组 | 操作新增/查；权限组增改查；引用不存在操作 | 合法引用保存；重复操作码/无效操作拒绝；无未批准操作编辑/删除入口 |
| AC-14 | US-09、US-10 / BR-12、BR-30 | 授权关联维护 | 账号、组织、权限组均存在 | 关联增改删查；两个请求同时建立同组合 | 最多一条同组合关联；修改原子完成；重复请求不额外授予 |
| AC-15 | US-11 / BR-03、BR-13 | 应用注册与绑定 | 两个应用与共享权限组场景 | 注册、绑定、获取明细；尝试绑定超额操作 | app_code/app_key 唯一；超额操作拒绝；不得无提示改变其他应用权限 |
| AC-16 | US-11 / BR-14、BR-17 | 授权刷新及撤权 | 多节点持有旧授权结果 | 按批准刷新语义撤回权限或冻结应用 | 在批准时限内所有节点拒绝旧权限；无额外密钥轮换 |
| AC-17 | US-04 / BR-02、BR-15 | 主/场景令牌 | 合法身份与场景 | 登录、进入正确场景、使用错误场景或过期令牌 | 正确场景有效；错误/过期拒绝；寿命符合批准 Q-06 |
| AC-18 | US-04、US-14 / BR-16、BR-30 | 并发刷新 | 同一有效刷新令牌 | 两个并发请求刷新，随后重放旧令牌 | 按批准轮换方案至多一次有效换发；旧令牌不能重复扩大会话 |
| AC-19 | US-04、US-14 / BR-17 | 退出与注销 | 同账号两个会话及场景令牌 | 退出一会话、再次注销、管理员强制注销 | 只影响批准范围；其他会话按规则保留或撤销；重复不恢复令牌 |
| AC-20 | US-12 / BR-06、BR-18、BR-30 | 委托申请与处理 | 有效资源、时间区间、批准的处理角色 | 申请、重复申请、批准/拒绝/撤销 | 申请仅 pending；同幂等键不新增；仅合法转换生效；不自动批准 |
| AC-21 | US-01、US-02、US-08 / BR-19 | 引用删除 | 账号/组织/权限组存在令牌、关联、应用或委托引用 | 删除该对象及一个无引用对照对象 | 按批准策略拒绝或完整处理；不能产生半删除、意外级联或丢失审计 |
| AC-22 | US-13 / BR-21、BR-22 | 日志追加与查询 | 静态、委托、认证失败和业务失败四种请求 | 系统写入，审计员详情/列表查询 | 主体/阶段/结果可区分且脱敏；无主体拒绝可记录；用户不能伪造/修改日志 |
| AC-23 | US-13 / BR-23 | 归档与恢复 | 已到保留期数据与模拟归档故障 | 自动归档、重试和抽样恢复 | 完整性验证后按策略处理原记录；故障不静默丢数据；恢复可查询 |
| AC-24 | US-14 / BR-24、BR-25 | 开放用户信息 | 已接入应用及多个账号 | 获取详情/权限；改目标 ID 或应用凭据 | 仅返回获准账号字段和当前应用权限；不返回散列、密钥、完整令牌 |
| AC-25 | US-08、US-11、US-12 / BR-26、BR-27 | 并发编辑 | 两人读取相同版本 | 先后提交不同权限/委托修改 | 首次成功后，旧版本冲突；保留输入供比较；不静默覆盖 |
| AC-26 | US-04、US-12 / BR-06、BR-28 | 时间边界 | 服务端统一时钟和带时区测试时间 | 测 valid_from 前/等于、valid_until 等于/后 | 委托遵循闭区间；过期判断不依赖定时任务；不同偏移表示同一时刻结果相同 |
| AC-27 | US-11、US-13 / BR-29 | 依赖故障 | 权限源、缓存或审计存储不可用 | 验证授权/执行高风险写入 | 按批准故障策略处理；不把异常变成许可；返回诊断标识 |
| AC-28 | US-01—US-14 / BR-25、BR-26 | 输入与读取权限 | 合法/非法字段、空值、大 ID、分页参数 | 各接口读写 | 遵守第三/五章；大 ID 不丢精度；非法排序不能拼接执行；越权不泄露对象详情 |
| AC-29 | US-01—US-14 / BR-08、BR-19、BR-28 | 数据库交付 | 已修订并批准的 DDL/迁移版本、隔离数据库 | 空库初始化、存量升级、无效数据写入、恢复演练 | 结构可建立、约束拒绝非法数据、序列不撞键、恢复结果可核对；本次未执行 |
| AC-30 | US-11、US-13 / BR-17、BR-23、BR-29 | 运行指标 | 已批准数据规模、环境、负载与目标 | 持续压测、撤权测量和归档监控 | 按第七章测量边界出报告；未填目标时不得声称达标 |

## 三、字段配置与数据规则

### 3.1 字段映射和空值约定

数据库列名和声明来自 DDL；API 名为建议，Java 属性仅在后端采用 Java 时适用，表中“同 API（候选）”不表示已有实体。BIGINT 对外建议十进制字符串以避免 JavaScript 大整数精度丢失；数据库仍保留 BIGINT。VARCHAR 长度按数据库字符数约束，前后端需用一致口径，不能用 UTF-8 字节数冒充字符数。

建议统一空值规则：R = 新增必填，缺失/null/空白拒绝；O = 新增省略使用明确默认或 null，编辑省略不变，显式 null 仅清空可空字段，纯文本空字符串规范为空值；S = 服务端生成或维护，客户端不可写；C = 条件必填。编辑采用字段白名单的局部更新建议（Q-12），若现有项目为全量更新须另行对齐。JSON 集合字段的 null 不等于 []；身份/授权相关空集合绝不能表示全部。参数值空字符串是否有效由 Q-14 单独决定，不套用 O。

### 3.2 公共字段

| 业务含义 | API | Java | 数据库 | 类型 | 请求必填 | DB 可空 | 默认来源 | 限制/缺失、null、空串 | 读写权限 |
|---|---|---|---|---|---|---|---|---|---|
| 内部主键 | id | id（候选） | 各表.id | BIGSERIAL → 字符串建议 | 新增否，编辑/详情/删除定位必填 | 否 | DB 序列 | S；正整数；客户端不决定新主键 | 获准读取；不可改 |
| 创建时间 | createdAt | 同 API（候选） | 各表.created_at | TIMESTAMP | 否 | 否 | CURRENT_TIMESTAMP | S；时区 Q-11 | 获准读取 |
| 更新时间 | updatedAt | 同 API（候选） | 有该列表.updated_at | TIMESTAMP | 否 | 否 | 插入默认当前时间 | S；默认值不自动跟随 UPDATE；维护方 Q-11 | 获准读取 |
| 创建/更新人 | createdBy、updatedBy | 同 API（候选） | 存在的 created_by、updated_by | BIGINT | 否 | 是 | 无默认 | S；由可信上下文填写；系统任务主体待定 | 受控可读，不可伪造 |
| 并发版本 | version | 同 API（候选） | 待新增或复用机制 | 整数候选 | 关键编辑/删除条件必填 | DDL 无此列 | 方案待 Q-12 | C；必须绑定上次读取值 | 随详情返回、写入时比较 |

permission_group_account、permission_group_org 只有 created_at、created_by；user_group_account 有 created_at、created_by、updated_by 但没有 updated_at；audit_log 只有 created_at。不要为映射对称而假称这些列都存在。

### 3.3 账号、组织和用户组

| 业务含义 | API | Java | 数据库 | 类型 | 请求必填 | DB 可空 | 默认来源 | 枚举/限制/空值语义 | 读写权限 |
|---|---|---|---|---|---|---|---|---|---|
| 账号全局标识 | uuid | uuid（候选） | account.uuid | UUID | 否 | 否 | uuid_generate_v4() | S；唯一 | 获准读取 |
| 用户名 | username | 同 API（候选） | account.username | VARCHAR(64) | R | 否 | 无 | 全局唯一；大小写/规范化 Q-10 | 账号管理员写；本人/获准应用读 |
| 登录密码输入/散列 | password（仅输入） | password（候选） | account.password | VARCHAR(128) | person 条件必填待 Q-05；service 不适用 | 否 | 无 | C；DDL 注释 bcrypt 应理解为散列；服务账号必填列冲突 | 专用认证/设置流程写；散列不输出 |
| 手机/邮箱 | phone、email | 同 API（候选） | account.phone、email | VARCHAR(20/128) | O | 是 | 无 | 各自唯一；格式、空值规范化 Q-10 | 按字段授权脱敏读取 |
| 头像/备注 | logo、remark | 同 API（候选） | account.logo、remark | VARCHAR(512) | O | 是 | 无 | URL 协议校验/纯文本；不得由服务端任意抓取 URL | 账号管理员写；按范围读 |
| 账号类型 | accountType | 同 API（候选） | account.account_type | VARCHAR(16) | 可省略 | 否 | person | person/service；显式 null、空串拒绝；类型可否转换 Q-05 | 管理员受控写 |
| 账号状态 | status | status（候选） | account.status | VARCHAR(16) | 可省略 | 否 | normal | normal/frozen；状态转换见第六章 | 管理员受控写 |
| IP 白名单 | ipWhitelist | 同 API（候选） | account.ip_whitelist | JSONB | service 为 C | 是 | [] | 服务账号建议非空 IP/CIDR 数组；null/[] 均不能代表全网 | 管理员写；敏感配置受限读 |
| 最近登录时间 | lastLoginAt | 同 API（候选） | account.last_login_at | TIMESTAMP | 否 | 是 | 无 | S；成功认证后的更新定义 Q-05 | 受限读取 |
| 父组织 | parentId | 同 API（候选） | organization.parent_id | BIGINT | 可省略 | 否 | 0 | 0 为根；非零需存在；不得成环 | 组织管理员写 |
| 组织路径 | orgPath | 同 API（候选） | organization.org_path | VARCHAR(512) | 否，建议服务端生成 | 否 | DDL 无默认 | S；与 parentId 一致；路径长度/深度限制 Q-02 | 只读 |
| 名称/类型 | orgName、orgType | 同 API（候选） | organization.org_name、org_type | VARCHAR(128/32) | R | 否 | 无 | company/department/team/post；未声明名称唯一 | 管理员写；授权范围内读 |
| 负责人/排序/备注 | leader、sortOrder、remark | 同 API（候选） | organization.leader、sort_order、remark | VARCHAR(64)、INT、VARCHAR(512) | O | 是 | sort_order=0；其他无 | leader 是姓名不是账号外键；排序范围待 Q-02 | 管理员写 |
| 用户组编码/名称 | groupCode、groupName | 同 API（候选） | user_group.group_code、group_name | VARCHAR(64/128) | R | 否 | 无 | group_code 唯一，group_name 未声明唯一 | 组管理员写 |
| 用户组描述 | description | 同 API（候选） | user_group.description | VARCHAR(512) | O | 是 | 无 | 纯文本 | 获准读写 |
| 用户组成员 | userGroupId、accountId | 同 API（候选） | user_group_account.user_group_id、account_id | BIGINT | R | 否 | 无 | 两个外键；组合唯一；null/空串拒绝 | 组管理员维护 |
| 账号组织归属 | accountId、orgId、isPrimary 等待设计 | 待定 | 缺失 | 待 Q-02 | 待定 | 无列/表 | 无 | 单/多组织与生效时间待决策 | 组织管理员候选 |

### 3.4 权限与应用字段

| 业务含义 | API | Java | 数据库 | 类型 | 请求必填 | DB 可空 | 默认来源 | 枚举/限制/空值语义 | 读写权限 |
|---|---|---|---|---|---|---|---|---|---|
| 操作码/名称 | operationCode、operationName | 同 API（候选） | operation.operation_code、operation_name | VARCHAR(128) | R | 否 | 无 | operation_code 全局唯一；Controller.method 为原文示例格式 | 权限管理员新增、获准读 |
| 操作描述/资源类型 | operationDesc、resourceType | 同 API（候选） | operation.operation_desc、resource_type | VARCHAR(512/64) | O；资源操作建议 C | 是 | 无 | 无资源操作如何鉴权待 Q-04；委托时必须可匹配类型 | 权限管理员写 |
| 权限组名称/描述 | name、description | 同 API（候选） | permission_group.name、description | VARCHAR(128/512) | 名称 R，描述 O | 名称否，描述是 | 无 | 名称没有唯一约束 | 权限管理员写 |
| 权限组操作集合 | operationIds | 同 API（候选） | permission_group.operation_ids | JSONB | 可省略 | 否 | [] | 正整数 ID 数组建议；去重、每项需存在；[] 为无操作；null 拒绝 | 权限管理员写；影响所有关联主体 |
| 权限组用户关联 | permissionGroupId、accountId | 同 API（候选） | permission_group_account 同义列 | BIGINT | R | 否 | 无 | 外键；组合唯一 | 权限管理员写 |
| 权限组组织关联 | permissionGroupId、orgId | 同 API（候选） | permission_group_org 同义列 | BIGINT | R | 否 | 无 | 外键；组合唯一 | 权限管理员写 |
| 应用编码/身份键 | appCode、appKey | 同 API（候选） | app_authorization.app_code、app_key | VARCHAR(64) | appCode R；appKey 建议 S | 否 | DDL 无默认 | 分别全局唯一；AppKey 不等同于用户认证 | 接入管理员受控配置 |
| 应用凭据 | appSecret | 同 API（候选） | app_authorization.app_secret | VARCHAR(128) | 建议 S | 否 | 无 | DDL 写“加密存储”，方式/长度待 Q-05 | 仅签发/轮换按批准规则返回；详情禁止 |
| 应用授权组 | permissionGroupId | 同 API（候选） | app_authorization.permission_group_id | BIGINT | R | 否 | 无 | 当前一应用一组、多个应用可引用同组；不能据此假设应用多组 | 接入与权限管理员协同 |
| 数据范围 | dataScopeType | 同 API（候选） | app_authorization.data_scope_type | VARCHAR(16) | 可省略 | 否 | SELF | SELF/DEPT/SPECIFIED；禁止未知值/空串/null | 获准管理员写；应用只读结果 |
| 指定组织 | specifiedOrgIds | 同 API（候选） | app_authorization.specified_org_ids | JSONB | SPECIFIED 时 C | 是 | [] | 建议 SPECIFIED 非空且引用有效；其他类型建议 []；null 不放宽范围 | 获准管理员写 |
| 应用状态 | status | status（候选） | app_authorization.status | VARCHAR(16) | 可省略 | 否 | active | active/frozen；无其他已定义状态 | 受控状态变更 |
| 密钥失效时间 | secretExpireAt | 同 API（候选） | app_authorization.secret_expire_at | TIMESTAMP | O | 是 | 无 | null 是否长期有效、到期处理及轮换 Q-05/Q-08 | 受控读写 |

### 3.5 令牌、委托、参数字典和审计

| 业务含义 | API | Java | 数据库 | 类型 | 请求必填 | DB 可空 | 默认来源 | 枚举/限制/空值语义 | 读写权限 |
|---|---|---|---|---|---|---|---|---|---|
| 令牌值 | accessToken/refreshToken（输出候选） | 待定 | token.token | VARCHAR(512) | 签发时 S，刷新时 C | 否 | 无 | 原文 JWT；可变长度上限和持久化明文风险 Q-06 | 仅签发返回及认证使用 |
| 账号/令牌类别 | accountId、tokenType、refreshType | 同 API（候选） | token.account_id、token_type、refresh_type | BIGINT、VARCHAR(16) | 账号建议 S，类别 C | 否 | 无 | Master-Token/Scene-Token 与 access_token/refresh_token 是两个独立维度 | 服务端决定，不信任任意主体 ID |
| 过期/撤销 | expiresAt、revoked | 同 API（候选） | token.expires_at、revoked | TIMESTAMP、BOOLEAN | S | expires 否；revoked 是 | expires 无；revoked=false | null revoked 的存量处理待 Q-06；不可当有效 | 服务端维护 |
| 场景/客户端 | sceneId、clientIp、userAgent | 同 API（候选） | token.scene_id、client_ip、user_agent | VARCHAR(64/64/256) | scene 条件必填，其他 S | 是 | 无 | Scene 建议绑定场景；IP 取可信代理策略，Q-05/Q-06 | 服务端记录、最小化返回 |
| 委托授予/接受者 | grantorId、granteeId | 同 API（候选） | delegation.grantor_id、grantee_id | BIGINT | R，来源由流程校验 | 否 | 无 | 均外键 account；客户端不能冒充处理人 | 申请可选范围/审批赋值待 Q-07 |
| 委托权限组/资源类型 | permissionGroupId、resourceType | 同 API（候选） | delegation.permission_group_id、resource_type | BIGINT、VARCHAR(64) | R | 否 | 无 | 组需存在、资源类型与操作匹配 | 获准申请/处理人写 |
| 委托资源集合 | resourceIds | 同 API（候选） | delegation.resource_ids | JSONB | R | 否 | 无 | 字符串 ID 数组建议；非空、去重、存在性及可授出范围检查；禁止把数字/字符串混同 | 资源清单受对象授权保护 |
| 委托有效期 | validFrom、validUntil | 同 API（候选） | delegation.valid_from、valid_until | TIMESTAMP | R | 否 | 无 | 建议 validFrom<validUntil；匹配按闭区间；时区 Q-11 | 获准申请/处理人写 |
| 委托状态/原因 | status、reason | 同 API（候选） | delegation.status、reason | VARCHAR(16/512) | 状态 S，原因 C/O | status 否；reason 是 | pending；原因无 | pending/active/expired/revoked；缺拒绝状态；申请理由与拒绝理由不能含混共用 | 状态受控；申请理由字段待补 |
| 参数编码/值/描述 | paramCode、paramValue、description | 同 API（候选） | sys_param.param_code、param_value、description | VARCHAR(64)、TEXT、VARCHAR(512) | 前二 R，描述 O | 前二否，描述是 | 无 | code 唯一；paramValue 类型/空串/长度上限待 Q-14 | 配置权限；敏感值专门规则 |
| 字典编码/项/描述 | dictCode、dictItems、description | 同 API（候选） | sys_dict.dict_code、dict_items、description | VARCHAR(64)、JSONB、VARCHAR(512) | 前二 R，描述 O | 前二否，描述是 | 无 | code 唯一；原例为字符串数组，键值/禁用/排序扩展待 Q-14 | 配置权限 |
| 审计关联标识 | traceId | traceId（候选） | audit_log.trace_id | UUID | S | 否 | 无 | 同一调用链可多条；不是日志主键 | 系统写、审计读 |
| 审计主体/应用/动作 | accountId、appCode、operationCode | 同 API（候选） | audit_log.account_id、app_code、operation_code | BIGINT、VARCHAR(64/128) | S | 否 | 无 | 无法认证时可能未知，当前非空列冲突 Q-09 | 系统确定，不信任任意客户端值 |
| 审计资源 | resourceId、resourceType | 同 API（候选） | audit_log.resource_id、resource_type | VARCHAR(128/64) | S/C | id 是；type 否 | 无 | 列表/登录可能无单资源；需约定事件类型，Q-09 | 系统写 |
| 审计结果/级别/原因 | result、logLevel、reason | 同 API（候选） | audit_log.result、log_level、reason | VARCHAR(16/16/512) | 前二 S，原因 C | 前二否，原因是 | level=info | success/failure/denied；info/warn/error；区分授权与执行业务阶段 | 系统写 |
| 审计请求/响应/耗时 | requestBody、responseBody、costMs | 同 API（候选） | audit_log.request_body、response_body、cost_ms | TEXT、TEXT、INT | S/O | 是 | 无 | 脱敏；大小与截断规则待定；耗时非负建议 | 系统写、受限读 |
| 审计客户端 | requestIp、userAgent | 同 API（候选） | audit_log.request_ip、user_agent | VARCHAR(64/512) | S/O | 是 | 无 | 可信来源、采集目的及保留期待 Q-09 | 受限读取 |

## 四、数据库设计与迁移

### 4.1 当前声明与关系

本章先保留对原输入SQL的静态评审，4.5起提供完整建表修订草案、注释、索引与验证对应；尚未执行数据库验证。原表名不带 tb_，JSON 使用 JSONB，时间使用 TIMESTAMP；不将技能模板中的 tb_、JPA、JSON TEXT 或 PostgreSQL 15+ 自动覆盖到本项目。实际数据库版本由 Q-16 决定。

| 关系 | 原 DDL 表达 | 对业务的影响 |
|---|---|---|
| 账号—用户组 | user_group_account 两个外键，组合唯一，均 CASCADE | 删除账号或用户组会删除成员关联 |
| 账号—令牌 | token.account_id 外键 CASCADE | 删除账号会物理删除令牌行 |
| 账号—权限组 | permission_group_account 两个外键 CASCADE，组合唯一 | 删除账号或权限组会撤掉该类关联 |
| 组织—权限组 | permission_group_org 两个外键 CASCADE，组合唯一 | 删除组织或权限组会删除授权关联 |
| 应用—权限组 | app_authorization.permission_group_id 非空外键 CASCADE | 删除组会删除引用它的应用授权行，包括 AppKey/AppSecret；是否允许待 Q-10 |
| 委托—主体/组 | delegation 引用 grantor、grantee、permission_group，未声明 CASCADE | 被引用的账号或组删除会受到外键约束，不能与其他 CASCADE 一概处理 |
| 权限组—操作 | operation_ids JSONB 数组 | 无逐项外键，删除/无效 ID 的完整性不能靠当前声明保证 |
| 账号—组织 | 未提供 | 组织授权继承和 DEPT 计算缺少数据来源 |
| 委托—应用/业务资源 | 无 app_id/app_code 外键；资源在 JSONB 中 | 跨应用隔离、资源存在性和归属需补充方案 |
| 审计—业务表 | account_id 等为普通字段，不建立实体外键 | 可设计为历史快照，但当前不能记录未知账号的非空 account_id |

### 4.2 DDL 差异与问题清单

证据行号基于原始 DDL.md 的本次读取；未复制其中的初始凭据或联系方式。严重度“阻断建库”指静态审查确定脚本存在建库障碍，并非实际执行错误记录。

| 编号 | 分类/严重度 | 文件证据 | 问题与影响 | 修订建议及关联 Q |
|---|---|---|---|---|
| DB-01 | 语法/阻断建库 | DDL.md 第 64、87、102、128、153、170、189、213、270、301 行 | 10 处 created_by BIGINT 后缺少逗号，下一行还有 updated_by | 修复这些列分隔符后再进行隔离库验证；Q-16 |
| DB-02 | 对象重名/阻断建库 | 第 133、134 行 | idx_token_account_id 连续创建两次 | 保留一份同名索引定义；Q-16 |
| DB-03 | 分区约束/阻断建库 | 第 318—335 行 | audit_log 按 created_at 分区，但只以 id 为主键，主键不含分区列 | 在复合主键 (id, created_at) 与其他已评审模型中决策；详情标识、引用和查询同步调整；Q-09、Q-16 |
| DB-04 | 关系缺失/阻断组织鉴权 | organization、account 及 14 表清单 | 无账号组织关联，无法据表计算“用户所在部门”与组织授权继承 | 明确数据来自本地关系还是权威外部组织源，再设计主/多部门和历史规则；Q-02 |
| DB-05 | 需求冲突/阻断服务认证 | account 第 23、28—30 行；app_authorization 第 260—267 行 | 服务账号仅凭据/证书登录，但 password 对所有账号非空；无服务账号与 AppKey/证书的绑定，白名单可空/空数组 | 定义服务账号凭据实体或绑定关系、密码条件必填及白名单校验；Q-05 |
| DB-06 | 权限组合未定/阻断应用鉴权 | app_code UNIQUE、permission_group_id 单列非空；permission_group.operation_ids | 当前一应用一组，原文“操作授权码绑定”未说明应用上限与用户组如何组合 | 明确一组/多组、组所有权和操作绑定是否变更共享组；Q-03 |
| DB-07 | 需求冲突/阻断数据范围 | PRD.md Step 3；DDL.md 第 280 行 | PRD 的 DEPT 为“用户所在部门”，DDL 注释为“本部门及以下” | 在 Q-02 选择准确集合并统一 PRD、实现、测试；Q-04 补资源字段映射 |
| DB-08 | 令牌模型缺失/阻断刷新注销 | token 第 115—130 行 | 无 app/session/family/parent 关联、无刷新轮换记录；token 明文持久化且限长 512；revoked 可 null | 按批准令牌方案补齐配对和撤销范围，评审是否存摘要、JWT 长度及敏感数据保护；Q-06 |
| DB-09 | 委托生命周期缺失/阻断委托上线 | delegation 第 288—312 行 | pending/active/expired/revoked 有声明，但无拒绝状态、处理人/处理时间、独立申请理由、应用归属和授出依据 | 先批准申请/批准/拒绝/撤销流程，再设计字段与审计；Q-07 |
| DB-10 | 数据完整性不足/高 | 多个 VARCHAR 枚举和 JSONB 字段 | 注释中的枚举不等于 CHECK；JSONB 不保证数组、元素类型、非空或所引用对象存在；缺有效期顺序校验 | 明确枚举、数组类型/元素/去重与引用检查；单表条件用约束，跨表完整性选关系表或原子服务逻辑；Q-03、Q-07、Q-14 |
| DB-11 | 时间/并发缺口/高 | 所有 TIMESTAMP、updated_at DEFAULT；全表无版本列 | 时区不明；默认时间不随更新自动改变；关键编辑没有并发版本机制 | 确定服务端时钟、迁移时区、updated_at 维护方和原子版本检查；Q-11、Q-12 |
| DB-12 | 组织树完整性/高 | organization.parent_id、org_path、leader | parent_id 无自引用约束，0 为根；未防环或验证路径；leader 为姓名而非账号关系 | 保留/调整根节点方案需统一，补防环与移动事务，不能把姓名视为已绑定负责人账号；Q-02 |
| DB-13 | 删除连带影响/高 | CASCADE 及 delegation 的默认外键动作 | 删除权限组可能连带删除应用凭据，又可能因委托引用失败；删除能力与保留策略未对齐 | 为每类对象定义引用矩阵、停用/删除策略、影响预览及原子执行；Q-10 |
| DB-14 | 初始化风险/高 | 第 360—387 行 | 固定管理员初始化与固定 ID 假设；显式插入组织/组 id=1 未同步序列；预设操作 ID 假设空库顺序 | 去除可复用默认凭据，采用安全初始化；按业务键取回实际 ID；校正显式 ID 对序列的影响；不要把示例当生产种子；Q-05、Q-16 |
| DB-15 | 索引说明不实/中 | 第 38—40、132、193、274—275、411 行 | 多个唯一列又建普通同列索引；“所有外键已建索引”缺依据，delegation.grantor_id 就无索引；存在索引不证明性能 | 按真实查询和执行计划去重/补充索引；物化路径前缀查询也需实际验证；Q-13、Q-16 |
| DB-16 | 审计表达不足/高 | audit_log 第 320—335 行 | 未登录/无效 AppKey 请求无法可靠填非空 account_id/app_code；无 delegationId/grantor/阶段/策略版本；不能区分允许与执行成功 | 设计可未知身份与明确事件阶段，补授权来源字段和脱敏规则；不得伪造“0 号账号”解决非空；Q-09 |
| DB-17 | 归档未实现/高 | 第 337—342、395—398 行 | 月分区和维护 SQL 都是注释示例，仅声明默认分区；没有归档程序、保留期、校验或恢复流程；令牌清理示例只清 revoked=true | 设计分区维护/归档/恢复，并明确未撤销但已过期令牌的保留策略；Q-06、Q-09 |
| DB-18 | 项目兼容未知/高 | DDL.md 使用说明与技能 project-profile.md | 本资料写 PostgreSQL 12+，技能背景写 15+/JPA/tb_；后端、迁移工具、租户、协议均未核实 | 以本项目实际技术和批准约束为准，不自动改表名、类型或响应协议；Q-01、Q-15、Q-16 |

DB-03 的数据库依据：PostgreSQL 分区表的唯一/主键约束须包含全部分区列。采用复合主键时，数据库保证的是组合唯一，不能声称单独 id 仍有全局唯一约束。[PostgreSQL 15 分区限制](https://www.postgresql.org/docs/15/ddl-partitioning.html#DDL-PARTITIONING-DECLARATIVE-LIMITATIONS)

DB-15 的索引依据：主键或唯一约束已经创建相应唯一索引，通常无须再创建同列普通索引。[PostgreSQL 15 唯一索引](https://www.postgresql.org/docs/15/indexes-unique.html)

DB-11 的时间依据：未限定的 TIMESTAMP 表示无时区时间类型；若目标使用 TIMESTAMPTZ，仍应另外明确原始业务时区是否需要保存。[PostgreSQL 15 日期时间类型](https://www.postgresql.org/docs/15/datatype-datetime.html)

### 4.3 数据约束建议

不在本轮直接写入或执行修订 SQL，避免把 Q 中未批准的数据关系固定为表结构。实施设计应至少提供：账号组织来源、应用权限组合、服务凭据绑定、令牌会话/刷新关联、委托审批与应用隔离、审计拒绝事件和归档信息。关系可来自既有服务，确认现有实现后再决定是否新增表。

| 约束对象 | 目标约束（建议） | 无效样例与预期 | 验证关联 |
|---|---|---|---|
| 业务编码/关联组合 | 唯一范围与 Q-01/Q-10 一致，数据库最终保证唯一 | 并发写同 username 或同组账号组合：最多一条生效 | AC-09、AC-14、TC-09、TC-14 |
| 账号和应用状态 | 仅允许批准枚举，状态非空 | status='unknown'：拒绝，不回退默认有效状态 | AC-28、TC-28 |
| 权限操作集合 | 合法数组、元素合法且引用存在 | operationIds 含不存在 ID：拒绝整个修改 | AC-13、TC-13 |
| 指定组织/白名单 | 按范围/账号类型条件必填 | SPECIFIED+[] 或 service+空白名单：拒绝 | AC-02、AC-05 |
| 委托 | 有效资源集合、合法状态、validFrom<validUntil、应用和主体可授出 | 结束早于开始、空资源、自批越权：拒绝 | AC-07、AC-20、TC-20 |
| 日志 | 分区约束合法、未知主体可表达、事件阶段明确、耗时合法 | 不存在主体的认证拒绝仍能记；负 costMs 拒绝或明确采集异常 | AC-22、AC-29 |

### 4.4 存量迁移与恢复计划（未执行）

当前未知是否存在存量库。若为新系统，使用批准后的初始化脚本在隔离空库验证；若已有数据，必须先收集结构、版本、行数、非法枚举、重复编码、JSON 结构、孤立引用、null 状态、时间分布和默认分区数据。不得假定只有空库，也不得用 IF NOT EXISTS 掩盖结构不一致。

1. 技术负责人和 DBA 确认 Q-16，取得结构快照与备份，记录可恢复点、可接受停机/锁等待和恢复目标。
2. 根据 Q-02/Q-03/Q-05/Q-06/Q-07/Q-09 设计新增关系和字段；优先选择可分阶段验证的兼容方案，不直接丢弃旧数据。
3. 处理重复/孤立/null/无效 JSON；涉及身份、权限和时间的值由业务确认，禁止用“全权限”“当前时间”填充未知事实。
4. 在隔离副本验证建表、约束、索引、序列、分区迁移、旧客户端读取、授权前后差异以及失败中断恢复。
5. 切换后核对授权结果、拒绝比例、撤权时延、审计完整性和默认分区增长。具体阈值待 Q-13。
6. 若新模型写入后无法安全反向迁移，采用已验证备份恢复或前滚修复；需要撤回凭据或权限时按批准安全规则处理，不以回滚恢复已撤销权限。

### 4.5 完整建表 SQL、表列注释与索引

以下脚本与《授权中心.schema.sql》逐字一致，覆盖14张原业务表及1张默认分区。它是**原模型的空库建表修订草案**，并非已批准目标模型或存量迁移。PostgreSQL 12+来自输入声明，实际版本、专用schema及扩展权限待Q-16；脚本不设置共享schema，也不执行初始化账号写入。

| 修改 | 来源/影响与批准状态 |
|---|---|
| 修复10处created_by后缺逗号、删除1条同名重复索引语句 | DB-01/DB-02，确定语法修复 |
| 去掉7个被列UNIQUE覆盖的普通索引 | 唯一性仍由原UNIQUE提供，实际查询计划待核对 |
| audit_log主键改为(id,created_at) | DB-03，候选方案；满足分区键要求，但id单列无唯一约束。Q-09/Q-16未批准，依赖id唯一性的调用方必须复核 |
| 补齐表/列数据库注释，外键显式ON UPDATE/DELETE | 保留原CASCADE与默认NO ACTION；不以语法修复批准级联删除业务 |
| 移除原初始化INSERT | 使用第九章合成夹具及批准装载适配，不沿用固定密码、手机号和主键假设 |
| 暂不添加业务CHECK、组织归属、服务凭据、令牌族、审批、版本列 | 原DB/Q仍有效；本脚本不支持这些目标能力的完整实现。第三章候选字段与TD-02/07仍是设计/测试上下文 |

原模型允许的枚举、JSON成员合法性、时间区间与组织树一致性尚未全部由数据库约束实现；应用层与数据库的负责范围须按4.3批准后追加目标迁移。不能将建表完成视为这些约束已落实。若分区复合主键方案不获批准，需在Q-09/Q-16评审非分区或另设全局唯一登记方案，不能自行切换。

```sql
-- 授权中心完整建表草案 0.3.0；来源DDL.md，原文件不修改。
-- PostgreSQL 12+为输入声明，实际部署版本/schema/search_path/扩展权限待Q-16。
-- 仅供批准隔离空库验证；本轮未执行SQL，不是存量库迁移脚本。
-- 保留原14张业务表、TIMESTAMP、JSONB、0根节点及原外键删除行为。
-- 修复10处缺逗号、重复索引；移除7个被UNIQUE覆盖的重复索引。
-- 候选：audit_log使用(id,created_at)主键，须Q-09/Q-16批准。
-- 不包含默认账号、密码、个人信息或假定ID的初始化INSERT。
-- 组织归属/会话/版本/委托应用关系及业务CHECK仍待决策，未虚构为现有列。
-- 在独立专用schema执行；部署方批准并设置search_path，本脚本不替调用方选择schema。

-- ============================================================
-- 安全生产智能体平台 - 授权中心 数据建模 DDL (PostgreSQL)
-- 版本: v1.0
-- 生成时间: 2026-09-07
-- ============================================================

-- 启用 UUID 扩展
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";


-- ============================================================
-- 1. 账号表
-- ============================================================
CREATE TABLE account (
    id                  BIGSERIAL PRIMARY KEY,              -- 主键，自增
    uuid                UUID DEFAULT uuid_generate_v4() NOT NULL UNIQUE, -- 唯一标识符，全局唯一
    username            VARCHAR(64) NOT NULL UNIQUE,        -- 用户名，全局唯一
    password            VARCHAR(128) NOT NULL,              -- bcrypt 加密
    phone               VARCHAR(20) UNIQUE,                  -- 手机号，全局唯一
    email               VARCHAR(128) UNIQUE,                  -- 邮箱，全局唯一
    logo                VARCHAR(512),                       -- 头像URL
    remark              VARCHAR(512),                        -- 备注
    account_type        VARCHAR(16) NOT NULL DEFAULT 'person', -- person / service
    status              VARCHAR(16) NOT NULL DEFAULT 'normal',  -- normal / frozen
    ip_whitelist        JSONB DEFAULT '[]',                 -- 服务账号IP白名单，JSON数组
    last_login_at       TIMESTAMP,                           -- 最后登录时间
    created_at          TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, -- 创建时间
    updated_at          TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, -- 更新时间
    created_by          BIGINT,                             -- 创建人ID
    updated_by          BIGINT                             -- 更新人ID
);

CREATE INDEX idx_account_type ON account(account_type);     -- 账号类型索引，用于快速查询
CREATE INDEX idx_account_status ON account(status);          -- 状态索引，用于快速查询

COMMENT ON TABLE account IS '账号表';
COMMENT ON COLUMN account.account_type IS 'person:自然人, service:服务账号';
COMMENT ON COLUMN account.status IS 'normal:正常, frozen:冻结';
COMMENT ON COLUMN account.ip_whitelist IS '服务账号IP白名单，JSON数组格式: ["192.168.1.1", "10.0.0.0/24"]';


-- ============================================================
-- 2. 组织结构表（树形结构）
-- ============================================================
CREATE TABLE organization (
    id                  BIGSERIAL PRIMARY KEY,              -- 主键，自增
    parent_id           BIGINT DEFAULT 0 NOT NULL,          -- 0表示根节点
    org_path            VARCHAR(512) NOT NULL,              -- 物化路径，如 /1/23/456
    org_name            VARCHAR(128) NOT NULL,              -- 组织名称
    org_type            VARCHAR(32) NOT NULL,               -- company:单位 / department:部门 / team:班组 / post:岗位
    leader              VARCHAR(64),                        -- 负责人姓名
    sort_order          INT DEFAULT 0,                      -- 排序顺序，默认0
    remark              VARCHAR(512),                        -- 备注
    created_at          TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, -- 创建时间
    updated_at          TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, -- 更新时间
    created_by          BIGINT,                             -- 创建人ID
    updated_by          BIGINT                             -- 更新人ID
);

CREATE INDEX idx_organization_parent_id ON organization(parent_id); -- 父节点索引，用于快速查询所有子节点
CREATE INDEX idx_organization_org_path ON organization(org_path);    -- 物化路径索引，用于快速查询所有子节点
CREATE INDEX idx_organization_type ON organization(org_type);      -- 组织类型索引，用于快速查询所有子节点

COMMENT ON TABLE organization IS '组织结构表（树形）';
COMMENT ON COLUMN organization.org_path IS '物化路径，用于快速查询所有子节点，如 /1/23/456';
COMMENT ON COLUMN organization.org_type IS 'company:单位, department:部门, team:班组, post:岗位';


-- ============================================================
-- 3. 用户组表
-- ============================================================
CREATE TABLE user_group (
    id                  BIGSERIAL PRIMARY KEY,              -- 主键，自增
    group_code          VARCHAR(64) NOT NULL UNIQUE,        -- 用户组编码，全局唯一
    group_name          VARCHAR(128) NOT NULL,              -- 用户组名称
    description         VARCHAR(512),                        -- 用户组描述
    created_at          TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, -- 创建时间
    updated_at          TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, -- 更新时间
    created_by          BIGINT,                             -- 创建人ID
    updated_by          BIGINT                             -- 更新人ID
);

COMMENT ON TABLE user_group IS '用户组表（跨部门虚拟小组）';     -- 跨部门虚拟小组，用于组织用户，不实际存储用户信息


-- ============================================================
-- 4. 用户组_用户关联表
-- ============================================================
CREATE TABLE user_group_account (
    id                  BIGSERIAL PRIMARY KEY,              -- 主键，自增
    user_group_id       BIGINT NOT NULL REFERENCES user_group(id) ON DELETE CASCADE ON UPDATE NO ACTION, -- 用户组ID，关联用户组表，级联删除
    account_id          BIGINT NOT NULL REFERENCES account(id) ON DELETE CASCADE ON UPDATE NO ACTION, -- 账号ID，关联账号表，级联删除
    created_at          TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, -- 创建时间
    created_by          BIGINT,                             -- 创建人ID
    updated_by          BIGINT                             -- 更新人ID
);

CREATE UNIQUE INDEX idx_user_group_account_unique ON user_group_account(user_group_id, account_id); -- 用户组-账号组合唯一索引，用于快速查询
CREATE INDEX idx_user_group_account_account_id ON user_group_account(account_id); -- 账号ID索引，用于快速查询

COMMENT ON TABLE user_group_account IS '用户组-用户关联表';


-- ============================================================
-- 5. 令牌管理表
-- ============================================================
CREATE TABLE token (
    id                  BIGSERIAL PRIMARY KEY,              -- 主键，自增
    token               VARCHAR(512) NOT NULL UNIQUE,       -- JWT Token，全局唯一
    account_id          BIGINT NOT NULL REFERENCES account(id) ON DELETE CASCADE ON UPDATE NO ACTION, -- 账号ID，关联账号表，级联删除
    token_type          VARCHAR(16) NOT NULL,               -- Master-Token / Scene-Token
    refresh_type        VARCHAR(16) NOT NULL,               -- access_token / refresh_token
    expires_at          TIMESTAMP NOT NULL,                   -- 过期时间
    scene_id            VARCHAR(64),                        -- Scene-Token 绑定的场景ID（如WebSocket连接ID）
    client_ip           VARCHAR(64),                        -- 客户端IP
    user_agent          VARCHAR(256),                       -- 用户代理
    revoked             BOOLEAN DEFAULT FALSE,                -- 是否已撤销，默认false
    created_at          TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, -- 创建时间
    updated_at          TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, -- 更新时间
    created_by          BIGINT,                             -- 创建人ID
    updated_by          BIGINT                             -- 更新人ID
);

CREATE INDEX idx_token_account_id ON token(account_id); -- 账号ID索引，用于快速查询
CREATE INDEX idx_token_expires_at ON token(expires_at); -- 过期时间索引，用于快速查询

COMMENT ON TABLE token IS '令牌管理表';
COMMENT ON COLUMN token.token_type IS 'Master-Token:主令牌, Scene-Token:场景令牌';
COMMENT ON COLUMN token.refresh_type IS 'access_token:访问令牌, refresh_token:刷新令牌';
COMMENT ON COLUMN token.scene_id IS 'Scene-Token绑定的场景ID，如音视频会话ID、WebSocket连接ID';


-- ============================================================
-- 6. 参数管理表
-- ============================================================
CREATE TABLE sys_param (
    id                  BIGSERIAL PRIMARY KEY,              -- 主键，自增
    param_code          VARCHAR(64) NOT NULL UNIQUE,        -- 参数编码，全局唯一
    param_value         TEXT NOT NULL,                      -- 参数值
    description         VARCHAR(512),                        -- 参数描述
    created_at          TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, -- 创建时间
    updated_at          TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, -- 更新时间
    created_by          BIGINT,                             -- 创建人ID
    updated_by          BIGINT                             -- 更新人ID
);

COMMENT ON TABLE sys_param IS '系统参数管理表';


-- ============================================================
-- 7. 字典管理表
-- ============================================================
CREATE TABLE sys_dict (
    id                  BIGSERIAL PRIMARY KEY,              -- 主键，自增
    dict_code           VARCHAR(64) NOT NULL UNIQUE,        -- 字典编码，全局唯一
    dict_items          JSONB NOT NULL,                      -- JSON数组，如 ["item1","item2","item3"]
    description         VARCHAR(512),                        -- 字典描述
    created_at          TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, -- 创建时间
    updated_at          TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, -- 更新时间
    created_by          BIGINT,                             -- 创建人ID
    updated_by          BIGINT                             -- 更新人ID
);

COMMENT ON TABLE sys_dict IS '系统字典管理表';
COMMENT ON COLUMN sys_dict.dict_items IS '字典项JSON数组，如 ["启用","禁用","待审核"]';


-- ============================================================
-- 8. 操作管理表
-- ============================================================
CREATE TABLE operation (
    id                  BIGSERIAL PRIMARY KEY,              -- 主键，自增
    operation_code      VARCHAR(128) NOT NULL UNIQUE,       -- 控制器名+方法名，如 DeviceController.delete
    operation_name      VARCHAR(128) NOT NULL,               -- 操作名称
    operation_desc      VARCHAR(512),                        -- 操作描述
    resource_type       VARCHAR(64),                        -- 所属资源类型，如 device / alarm / report
    created_at          TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, -- 创建时间
    updated_at          TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, -- 更新时间
    created_by          BIGINT,                             -- 创建人ID
    updated_by          BIGINT                             -- 更新人ID
);

CREATE INDEX idx_operation_resource_type ON operation(resource_type); -- 资源类型索引，用于快速查询

COMMENT ON TABLE operation IS '操作管理表（权限操作码字典）';
COMMENT ON COLUMN operation.operation_code IS '操作编码，格式：控制器名称+方法名，如 DeviceController.delete';
COMMENT ON COLUMN operation.operation_name IS '操作名称，如 deleteDevice';
COMMENT ON COLUMN operation.operation_desc IS '操作描述，如 删除设备';
COMMENT ON COLUMN operation.resource_type IS '所属资源类型，如 device / alarm / report';


-- ============================================================
-- 9. 权限组表
-- ============================================================
CREATE TABLE permission_group (
    id                  BIGSERIAL PRIMARY KEY,              -- 主键，自增
    name                VARCHAR(128) NOT NULL,               -- 权限组名称
    description         VARCHAR(512),                        -- 权限组描述
    operation_ids       JSONB NOT NULL DEFAULT '[]',        -- 操作ID JSON数组，如 [1,2,3]
    created_at          TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, -- 创建时间
    updated_at          TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, -- 更新时间
    created_by          BIGINT,                             -- 创建人ID
    updated_by          BIGINT                             -- 更新人ID
);

COMMENT ON TABLE permission_group IS '权限组表（权限操作码字典）';
COMMENT ON COLUMN permission_group.operation_ids IS '操作ID JSON数组，如 [1,2,3]';


-- ============================================================
-- 10. 权限组_用户关联表
-- ============================================================
CREATE TABLE permission_group_account (
    id                  BIGSERIAL PRIMARY KEY,              -- 主键，自增
    permission_group_id BIGINT NOT NULL REFERENCES permission_group(id) ON DELETE CASCADE ON UPDATE NO ACTION, -- 权限组ID，关联权限组表
    account_id          BIGINT NOT NULL REFERENCES account(id) ON DELETE CASCADE ON UPDATE NO ACTION, -- 用户ID，关联用户表
    created_at          TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, -- 创建时间
    created_by          BIGINT                             -- 创建人ID
);

CREATE UNIQUE INDEX idx_perm_group_account_unique ON permission_group_account(permission_group_id, account_id); -- 权限组-用户关联表，唯一索引，防止重复关联
CREATE INDEX idx_perm_group_account_account_id ON permission_group_account(account_id); -- 用户ID索引，用于快速查询

COMMENT ON TABLE permission_group_account IS '权限组-用户关联表（权限操作码字典）';


-- ============================================================
-- 11. 权限组_组织关联表
-- ============================================================
CREATE TABLE permission_group_org (
    id                  BIGSERIAL PRIMARY KEY,              -- 主键，自增
    permission_group_id BIGINT NOT NULL REFERENCES permission_group(id) ON DELETE CASCADE ON UPDATE NO ACTION, -- 权限组ID，关联权限组表
    org_id              BIGINT NOT NULL REFERENCES organization(id) ON DELETE CASCADE ON UPDATE NO ACTION, -- 组织ID，关联组织表
    created_at          TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, -- 创建时间
    created_by          BIGINT                             -- 创建人ID
);

CREATE UNIQUE INDEX idx_perm_group_org_unique ON permission_group_org(permission_group_id, org_id); -- 权限组-组织关联表，唯一索引，防止重复关联
CREATE INDEX idx_perm_group_org_org_id ON permission_group_org(org_id); -- 组织ID索引，用于快速查询

COMMENT ON TABLE permission_group_org IS '权限组-组织关联表（组织下所有用户自动继承权限）';


-- ============================================================
-- 12. 应用授权表
-- ============================================================
CREATE TABLE app_authorization (
    id                  BIGSERIAL PRIMARY KEY,              -- 主键，自增
    app_code            VARCHAR(64) NOT NULL UNIQUE,          -- 应用编码，唯一标识应用
    permission_group_id BIGINT NOT NULL REFERENCES permission_group(id) ON DELETE CASCADE ON UPDATE NO ACTION, -- 权限组ID，关联权限组表
    app_key             VARCHAR(64) NOT NULL UNIQUE,          -- 应用密钥，唯一标识应用
    app_secret          VARCHAR(128) NOT NULL,              -- 加密存储
    data_scope_type     VARCHAR(16) NOT NULL DEFAULT 'SELF', -- SELF / DEPT / SPECIFIED
    specified_org_ids   JSONB DEFAULT '[]',                 -- data_scope_type=SPECIFIED 时必填
    status              VARCHAR(16) NOT NULL DEFAULT 'active', -- active / frozen
    secret_expire_at    TIMESTAMP,                          -- AppSecret 过期时间
    created_at          TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, -- 创建时间
    updated_at          TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, -- 更新时间
    created_by          BIGINT,                             -- 创建人ID
    updated_by          BIGINT                             -- 更新人ID
);

CREATE INDEX idx_app_auth_status ON app_authorization(status); -- 状态索引，用于快速查询
CREATE INDEX idx_app_auth_permission_group_id ON app_authorization(permission_group_id); -- 权限组ID索引，用于快速查询

COMMENT ON TABLE app_authorization IS '应用授权表';
COMMENT ON COLUMN app_authorization.data_scope_type IS 'SELF:本人数据, DEPT:部门范围；是否含下级待Q-02, SPECIFIED:指定部门';
COMMENT ON COLUMN app_authorization.specified_org_ids IS '指定部门时存储组织ID列表，JSON数组格式如 [1,2,3]';
COMMENT ON COLUMN app_authorization.status IS 'active:生效, frozen:冻结';


-- ============================================================
-- 13. 委托授权表
-- ============================================================
CREATE TABLE delegation (
    id                  BIGSERIAL PRIMARY KEY,              -- 主键，自增
    grantor_id          BIGINT NOT NULL REFERENCES account(id) ON DELETE NO ACTION ON UPDATE NO ACTION, -- 授权人（管理员）
    grantee_id          BIGINT NOT NULL REFERENCES account(id) ON DELETE NO ACTION ON UPDATE NO ACTION, -- 被授权人（实际执行人）
    permission_group_id BIGINT NOT NULL REFERENCES permission_group(id) ON DELETE NO ACTION ON UPDATE NO ACTION,
    resource_type       VARCHAR(64) NOT NULL,                -- 资源类型，如 device / alarm
    resource_ids        JSONB NOT NULL,                      -- 资源ID列表，如 ["1","2","3"]
    valid_from          TIMESTAMP NOT NULL,                  -- 有效开始时间
    valid_until         TIMESTAMP NOT NULL,                  -- 有效结束时间
    status              VARCHAR(16) NOT NULL DEFAULT 'pending', -- pending / active / expired / revoked
    reason              VARCHAR(512),                        -- 拒绝原因或错误信息
    created_at          TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, -- 创建时间
    updated_at          TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, -- 更新时间
    created_by          BIGINT,                             -- 创建人ID
    updated_by          BIGINT                             -- 更新人ID
);

CREATE INDEX idx_delegation_grantee_id ON delegation(grantee_id); -- 被授权人ID索引，用于快速查询
CREATE INDEX idx_delegation_permission_group_id ON delegation(permission_group_id); -- 权限组ID索引，用于快速查询
CREATE INDEX idx_delegation_status ON delegation(status); -- 状态索引，用于快速查询
CREATE INDEX idx_delegation_valid_range ON delegation(valid_from, valid_until); -- 有效时间范围索引，用于快速查询

COMMENT ON TABLE delegation IS '委托授权表（动态临时授权）';
COMMENT ON COLUMN delegation.status IS 'pending:待审批, active:生效中, expired:已过期, revoked:已撤销';
COMMENT ON COLUMN delegation.resource_ids IS '资源ID列表JSON数组，如 ["device_001", "device_002"]';


-- ============================================================
-- 14. 日志中心表（按月分区建议）
-- ============================================================
CREATE TABLE audit_log (
    id                  BIGSERIAL NOT NULL,              -- 主键，自增
    trace_id            UUID NOT NULL,                       -- 全链路追踪ID
    account_id          BIGINT NOT NULL,                     -- 实际操作人（非委托授权人）
    app_code            VARCHAR(64) NOT NULL,                -- 应用编码
    operation_code      VARCHAR(128) NOT NULL,               -- 操作编码
    resource_id         VARCHAR(128),                       -- 操作的目标资源ID
    resource_type       VARCHAR(64) NOT NULL,                -- 资源类型，如 device / alarm
    request_ip          VARCHAR(64),                        -- 请求IP
    user_agent          VARCHAR(512),                       -- 用户代理
    result              VARCHAR(16) NOT NULL,               -- success / failure / denied
    reason              VARCHAR(512),                       -- 拒绝原因或错误信息
    log_level           VARCHAR(16) NOT NULL DEFAULT 'info', -- info / warn / error
    request_body        TEXT,                               -- 请求体（脱敏后）
    response_body       TEXT,                               -- 响应体（脱敏后）
    cost_ms             INT,                                -- 接口耗时
    created_at          TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT pk_audit_log PRIMARY KEY (id, created_at)
) PARTITION BY RANGE (created_at);

-- 创建默认分区（请根据实际需要按月创建）
CREATE TABLE audit_log_default PARTITION OF audit_log DEFAULT; -- 默认分区，所有数据都存储在默认分区中

-- 创建分区示例（以月为单位，需定期维护）
-- CREATE TABLE audit_log_2026_09 PARTITION OF audit_log
--     FOR VALUES FROM ('2026-09-01') TO ('2026-10-01');

CREATE INDEX idx_audit_log_trace_id ON audit_log(trace_id); -- 全链路追踪ID索引，用于快速查询
CREATE INDEX idx_audit_log_account_id ON audit_log(account_id); -- 实际操作人索引，用于快速查询
CREATE INDEX idx_audit_log_app_code ON audit_log(app_code); -- 应用编码索引，用于快速查询
CREATE INDEX idx_audit_log_operation_code ON audit_log(operation_code); -- 操作编码索引，用于快速查询
CREATE INDEX idx_audit_log_created_at ON audit_log(created_at); -- 创建时间索引，用于快速查询
CREATE INDEX idx_audit_log_result ON audit_log(result); -- 结果索引，用于快速查询

COMMENT ON TABLE audit_log IS '审计日志表（按 created_at 按月分区）';
COMMENT ON COLUMN audit_log.result IS 'success:成功, failure:业务失败, denied:权限拒绝';
COMMENT ON COLUMN audit_log.account_id IS '实际执行人，委托场景下为被授权人';

-- 补全数据库可存储注释。
COMMENT ON COLUMN account.id IS '主键，自增';
COMMENT ON COLUMN account.uuid IS '唯一标识符，全局唯一';
COMMENT ON COLUMN account.username IS '用户名，全局唯一';
COMMENT ON COLUMN account.password IS 'bcrypt 加密';
COMMENT ON COLUMN account.phone IS '手机号，全局唯一';
COMMENT ON COLUMN account.email IS '邮箱，全局唯一';
COMMENT ON COLUMN account.logo IS '头像URL';
COMMENT ON COLUMN account.remark IS '备注';
COMMENT ON COLUMN account.last_login_at IS '最后登录时间';
COMMENT ON COLUMN account.created_at IS '创建时间';
COMMENT ON COLUMN account.updated_at IS '更新时间；DEFAULT仅在插入时生效，更新维护方待Q-11/Q-12';
COMMENT ON COLUMN account.created_by IS '创建人ID；原模型未设外键，审计与保留策略待Q-09/Q-10';
COMMENT ON COLUMN account.updated_by IS '更新人ID；原模型未设外键，审计与保留策略待Q-09/Q-10';
COMMENT ON COLUMN organization.id IS '主键，自增';
COMMENT ON COLUMN organization.parent_id IS '0表示根节点';
COMMENT ON COLUMN organization.org_name IS '组织名称';
COMMENT ON COLUMN organization.leader IS '负责人姓名';
COMMENT ON COLUMN organization.sort_order IS '排序顺序，默认0';
COMMENT ON COLUMN organization.remark IS '备注';
COMMENT ON COLUMN organization.created_at IS '创建时间';
COMMENT ON COLUMN organization.updated_at IS '更新时间；DEFAULT仅在插入时生效，更新维护方待Q-11/Q-12';
COMMENT ON COLUMN organization.created_by IS '创建人ID；原模型未设外键，审计与保留策略待Q-09/Q-10';
COMMENT ON COLUMN organization.updated_by IS '更新人ID；原模型未设外键，审计与保留策略待Q-09/Q-10';
COMMENT ON COLUMN user_group.id IS '主键，自增';
COMMENT ON COLUMN user_group.group_code IS '用户组编码，全局唯一';
COMMENT ON COLUMN user_group.group_name IS '用户组名称';
COMMENT ON COLUMN user_group.description IS '用户组描述';
COMMENT ON COLUMN user_group.created_at IS '创建时间';
COMMENT ON COLUMN user_group.updated_at IS '更新时间；DEFAULT仅在插入时生效，更新维护方待Q-11/Q-12';
COMMENT ON COLUMN user_group.created_by IS '创建人ID；原模型未设外键，审计与保留策略待Q-09/Q-10';
COMMENT ON COLUMN user_group.updated_by IS '更新人ID；原模型未设外键，审计与保留策略待Q-09/Q-10';
COMMENT ON COLUMN user_group_account.id IS '主键，自增';
COMMENT ON COLUMN user_group_account.user_group_id IS '用户组ID，关联用户组表，级联删除';
COMMENT ON COLUMN user_group_account.account_id IS '账号ID，关联账号表，级联删除';
COMMENT ON COLUMN user_group_account.created_at IS '创建时间';
COMMENT ON COLUMN user_group_account.created_by IS '创建人ID；原模型未设外键，审计与保留策略待Q-09/Q-10';
COMMENT ON COLUMN user_group_account.updated_by IS '更新人ID；原模型未设外键，审计与保留策略待Q-09/Q-10';
COMMENT ON COLUMN token.id IS '主键，自增';
COMMENT ON COLUMN token.token IS 'JWT Token，全局唯一';
COMMENT ON COLUMN token.account_id IS '账号ID，关联账号表，级联删除';
COMMENT ON COLUMN token.expires_at IS '过期时间';
COMMENT ON COLUMN token.client_ip IS '客户端IP';
COMMENT ON COLUMN token.user_agent IS '用户代理';
COMMENT ON COLUMN token.revoked IS '是否已撤销，默认false';
COMMENT ON COLUMN token.created_at IS '创建时间';
COMMENT ON COLUMN token.updated_at IS '更新时间；DEFAULT仅在插入时生效，更新维护方待Q-11/Q-12';
COMMENT ON COLUMN token.created_by IS '创建人ID；原模型未设外键，审计与保留策略待Q-09/Q-10';
COMMENT ON COLUMN token.updated_by IS '更新人ID；原模型未设外键，审计与保留策略待Q-09/Q-10';
COMMENT ON COLUMN sys_param.id IS '主键，自增';
COMMENT ON COLUMN sys_param.param_code IS '参数编码，全局唯一';
COMMENT ON COLUMN sys_param.param_value IS '参数值';
COMMENT ON COLUMN sys_param.description IS '参数描述';
COMMENT ON COLUMN sys_param.created_at IS '创建时间';
COMMENT ON COLUMN sys_param.updated_at IS '更新时间；DEFAULT仅在插入时生效，更新维护方待Q-11/Q-12';
COMMENT ON COLUMN sys_param.created_by IS '创建人ID；原模型未设外键，审计与保留策略待Q-09/Q-10';
COMMENT ON COLUMN sys_param.updated_by IS '更新人ID；原模型未设外键，审计与保留策略待Q-09/Q-10';
COMMENT ON COLUMN sys_dict.id IS '主键，自增';
COMMENT ON COLUMN sys_dict.dict_code IS '字典编码，全局唯一';
COMMENT ON COLUMN sys_dict.description IS '字典描述';
COMMENT ON COLUMN sys_dict.created_at IS '创建时间';
COMMENT ON COLUMN sys_dict.updated_at IS '更新时间；DEFAULT仅在插入时生效，更新维护方待Q-11/Q-12';
COMMENT ON COLUMN sys_dict.created_by IS '创建人ID；原模型未设外键，审计与保留策略待Q-09/Q-10';
COMMENT ON COLUMN sys_dict.updated_by IS '更新人ID；原模型未设外键，审计与保留策略待Q-09/Q-10';
COMMENT ON COLUMN operation.id IS '主键，自增';
COMMENT ON COLUMN operation.created_at IS '创建时间';
COMMENT ON COLUMN operation.updated_at IS '更新时间；DEFAULT仅在插入时生效，更新维护方待Q-11/Q-12';
COMMENT ON COLUMN operation.created_by IS '创建人ID；原模型未设外键，审计与保留策略待Q-09/Q-10';
COMMENT ON COLUMN operation.updated_by IS '更新人ID；原模型未设外键，审计与保留策略待Q-09/Q-10';
COMMENT ON COLUMN permission_group.id IS '主键，自增';
COMMENT ON COLUMN permission_group.name IS '权限组名称';
COMMENT ON COLUMN permission_group.description IS '权限组描述';
COMMENT ON COLUMN permission_group.created_at IS '创建时间';
COMMENT ON COLUMN permission_group.updated_at IS '更新时间；DEFAULT仅在插入时生效，更新维护方待Q-11/Q-12';
COMMENT ON COLUMN permission_group.created_by IS '创建人ID；原模型未设外键，审计与保留策略待Q-09/Q-10';
COMMENT ON COLUMN permission_group.updated_by IS '更新人ID；原模型未设外键，审计与保留策略待Q-09/Q-10';
COMMENT ON COLUMN permission_group_account.id IS '主键，自增';
COMMENT ON COLUMN permission_group_account.permission_group_id IS '权限组ID，关联权限组表';
COMMENT ON COLUMN permission_group_account.account_id IS '用户ID，关联用户表';
COMMENT ON COLUMN permission_group_account.created_at IS '创建时间';
COMMENT ON COLUMN permission_group_account.created_by IS '创建人ID；原模型未设外键，审计与保留策略待Q-09/Q-10';
COMMENT ON COLUMN permission_group_org.id IS '主键，自增';
COMMENT ON COLUMN permission_group_org.permission_group_id IS '权限组ID，关联权限组表';
COMMENT ON COLUMN permission_group_org.org_id IS '组织ID，关联组织表';
COMMENT ON COLUMN permission_group_org.created_at IS '创建时间';
COMMENT ON COLUMN permission_group_org.created_by IS '创建人ID；原模型未设外键，审计与保留策略待Q-09/Q-10';
COMMENT ON COLUMN app_authorization.id IS '主键，自增';
COMMENT ON COLUMN app_authorization.app_code IS '应用编码，唯一标识应用';
COMMENT ON COLUMN app_authorization.permission_group_id IS '权限组ID，关联权限组表';
COMMENT ON COLUMN app_authorization.app_key IS '应用密钥，唯一标识应用';
COMMENT ON COLUMN app_authorization.app_secret IS '加密存储';
COMMENT ON COLUMN app_authorization.secret_expire_at IS 'AppSecret 过期时间';
COMMENT ON COLUMN app_authorization.created_at IS '创建时间';
COMMENT ON COLUMN app_authorization.updated_at IS '更新时间；DEFAULT仅在插入时生效，更新维护方待Q-11/Q-12';
COMMENT ON COLUMN app_authorization.created_by IS '创建人ID；原模型未设外键，审计与保留策略待Q-09/Q-10';
COMMENT ON COLUMN app_authorization.updated_by IS '更新人ID；原模型未设外键，审计与保留策略待Q-09/Q-10';
COMMENT ON COLUMN delegation.id IS '主键，自增';
COMMENT ON COLUMN delegation.grantor_id IS '授权人（管理员）';
COMMENT ON COLUMN delegation.grantee_id IS '被授权人（实际执行人）';
COMMENT ON COLUMN delegation.permission_group_id IS '权限组标识，引用permission_group.id';
COMMENT ON COLUMN delegation.resource_type IS '资源类型，如 device / alarm';
COMMENT ON COLUMN delegation.valid_from IS '有效开始时间';
COMMENT ON COLUMN delegation.valid_until IS '有效结束时间';
COMMENT ON COLUMN delegation.reason IS '拒绝原因或错误信息';
COMMENT ON COLUMN delegation.created_at IS '创建时间';
COMMENT ON COLUMN delegation.updated_at IS '更新时间；DEFAULT仅在插入时生效，更新维护方待Q-11/Q-12';
COMMENT ON COLUMN delegation.created_by IS '创建人ID；原模型未设外键，审计与保留策略待Q-09/Q-10';
COMMENT ON COLUMN delegation.updated_by IS '更新人ID；原模型未设外键，审计与保留策略待Q-09/Q-10';
COMMENT ON COLUMN audit_log.id IS '序列生成标识；与created_at共同组成分区主键，单列无唯一约束，待Q-09/Q-16';
COMMENT ON COLUMN audit_log.trace_id IS '全链路追踪ID';
COMMENT ON COLUMN audit_log.app_code IS '应用编码';
COMMENT ON COLUMN audit_log.operation_code IS '操作编码';
COMMENT ON COLUMN audit_log.resource_id IS '操作的目标资源ID';
COMMENT ON COLUMN audit_log.resource_type IS '资源类型，如 device / alarm';
COMMENT ON COLUMN audit_log.request_ip IS '请求IP';
COMMENT ON COLUMN audit_log.user_agent IS '用户代理';
COMMENT ON COLUMN audit_log.reason IS '拒绝原因或错误信息';
COMMENT ON COLUMN audit_log.log_level IS 'info / warn / error';
COMMENT ON COLUMN audit_log.request_body IS '请求体（脱敏后）';
COMMENT ON COLUMN audit_log.response_body IS '响应体（脱敏后）';
COMMENT ON COLUMN audit_log.cost_ms IS '接口耗时';
COMMENT ON COLUMN audit_log.created_at IS '创建时间；TIMESTAMP不含时区，解释规则待Q-11';
COMMENT ON TABLE audit_log_default IS '审计默认分区；月分区建立与默认分区数据迁移待Q-09/Q-16';
COMMENT ON COLUMN audit_log_default.id IS '审计默认分区字段；业务含义同audit_log.id';
COMMENT ON COLUMN audit_log_default.trace_id IS '审计默认分区字段；业务含义同audit_log.trace_id';
COMMENT ON COLUMN audit_log_default.account_id IS '审计默认分区字段；业务含义同audit_log.account_id';
COMMENT ON COLUMN audit_log_default.app_code IS '审计默认分区字段；业务含义同audit_log.app_code';
COMMENT ON COLUMN audit_log_default.operation_code IS '审计默认分区字段；业务含义同audit_log.operation_code';
COMMENT ON COLUMN audit_log_default.resource_id IS '审计默认分区字段；业务含义同audit_log.resource_id';
COMMENT ON COLUMN audit_log_default.resource_type IS '审计默认分区字段；业务含义同audit_log.resource_type';
COMMENT ON COLUMN audit_log_default.request_ip IS '审计默认分区字段；业务含义同audit_log.request_ip';
COMMENT ON COLUMN audit_log_default.user_agent IS '审计默认分区字段；业务含义同audit_log.user_agent';
COMMENT ON COLUMN audit_log_default.result IS '审计默认分区字段；业务含义同audit_log.result';
COMMENT ON COLUMN audit_log_default.reason IS '审计默认分区字段；业务含义同audit_log.reason';
COMMENT ON COLUMN audit_log_default.log_level IS '审计默认分区字段；业务含义同audit_log.log_level';
COMMENT ON COLUMN audit_log_default.request_body IS '审计默认分区字段；业务含义同audit_log.request_body';
COMMENT ON COLUMN audit_log_default.response_body IS '审计默认分区字段；业务含义同audit_log.response_body';
COMMENT ON COLUMN audit_log_default.cost_ms IS '审计默认分区字段；业务含义同audit_log.cost_ms';
COMMENT ON COLUMN audit_log_default.created_at IS '审计默认分区字段；业务含义同audit_log.created_at';
```

### 4.6 索引清单、查询依据与验证

保留原输入索引作为候选基线；下表关联逻辑查询，不能据此宣称性能有保障。所有索引都有写入/更新维护与存储成本，须使用批准规模TD-10和真实谓词在隔离环境执行EXPLAIN (ANALYZE, BUFFERS)后决定保留、合并或替换。

| 索引名 | 表 / 列顺序 | 类型 | 查询/约束依据 | 验证与代价 |
|---|---|---|---|---|
| idx_account_type | account / account_type | BTREE | API-01；按上述字段过滤/关联 | 写入维护与空间成本；核对真实计划和选择率 |
| idx_account_status | account / status | BTREE | API-01；按上述字段过滤/关联 | 写入维护与空间成本；核对真实计划和选择率 |
| idx_organization_parent_id | organization / parent_id | BTREE | API-02；按上述字段过滤/关联 | 写入维护与空间成本；核对真实计划和选择率 |
| idx_organization_org_path | organization / org_path | BTREE | API-02；按上述字段过滤/关联 | 写入维护与空间成本；核对真实计划和选择率 |
| idx_organization_type | organization / org_type | BTREE | API-02；按上述字段过滤/关联 | 写入维护与空间成本；核对真实计划和选择率 |
| idx_user_group_account_unique | user_group_account / user_group_id, account_id | UNIQUE | API-03 / Q-01；按上述字段过滤/关联；组合去重 | 写入维护与空间成本；核对真实计划和选择率 |
| idx_user_group_account_account_id | user_group_account / account_id | BTREE | API-03 / Q-01；按上述字段过滤/关联 | 写入维护与空间成本；核对真实计划和选择率 |
| idx_token_account_id | token / account_id | BTREE | API-15—API-17；按上述字段过滤/关联 | 写入维护与空间成本；核对真实计划和选择率 |
| idx_token_expires_at | token / expires_at | BTREE | API-15—API-17；按上述字段过滤/关联 | 写入维护与空间成本；核对真实计划和选择率 |
| idx_operation_resource_type | operation / resource_type | BTREE | API-06；按上述字段过滤/关联 | 写入维护与空间成本；核对真实计划和选择率 |
| idx_perm_group_account_unique | permission_group_account / permission_group_id, account_id | UNIQUE | API-08；按上述字段过滤/关联；组合去重 | 写入维护与空间成本；核对真实计划和选择率 |
| idx_perm_group_account_account_id | permission_group_account / account_id | BTREE | API-08；按上述字段过滤/关联 | 写入维护与空间成本；核对真实计划和选择率 |
| idx_perm_group_org_unique | permission_group_org / permission_group_id, org_id | UNIQUE | API-09；按上述字段过滤/关联；组合去重 | 写入维护与空间成本；核对真实计划和选择率 |
| idx_perm_group_org_org_id | permission_group_org / org_id | BTREE | API-09；按上述字段过滤/关联 | 写入维护与空间成本；核对真实计划和选择率 |
| idx_app_auth_status | app_authorization / status | BTREE | API-10 / 鉴权；按上述字段过滤/关联 | 写入维护与空间成本；核对真实计划和选择率 |
| idx_app_auth_permission_group_id | app_authorization / permission_group_id | BTREE | API-10 / 鉴权；按上述字段过滤/关联 | 写入维护与空间成本；核对真实计划和选择率 |
| idx_delegation_grantee_id | delegation / grantee_id | BTREE | API-11 / 鉴权；按上述字段过滤/关联 | 写入维护与空间成本；核对真实计划和选择率 |
| idx_delegation_permission_group_id | delegation / permission_group_id | BTREE | API-11 / 鉴权；按上述字段过滤/关联 | 写入维护与空间成本；核对真实计划和选择率 |
| idx_delegation_status | delegation / status | BTREE | API-11 / 鉴权；按上述字段过滤/关联 | 写入维护与空间成本；核对真实计划和选择率 |
| idx_delegation_valid_range | delegation / valid_from, valid_until | BTREE | API-11 / 鉴权；按上述字段过滤/关联 | 写入维护与空间成本；核对真实计划和选择率 |
| idx_audit_log_trace_id | audit_log / trace_id | BTREE | API-12—API-13；按上述字段过滤/关联 | 写入维护与空间成本；核对真实计划和选择率 |
| idx_audit_log_account_id | audit_log / account_id | BTREE | API-12—API-13；按上述字段过滤/关联 | 写入维护与空间成本；核对真实计划和选择率 |
| idx_audit_log_app_code | audit_log / app_code | BTREE | API-12—API-13；按上述字段过滤/关联 | 写入维护与空间成本；核对真实计划和选择率 |
| idx_audit_log_operation_code | audit_log / operation_code | BTREE | API-12—API-13；按上述字段过滤/关联 | 写入维护与空间成本；核对真实计划和选择率 |
| idx_audit_log_created_at | audit_log / created_at | BTREE | API-12—API-13；按上述字段过滤/关联 | 写入维护与空间成本；核对真实计划和选择率 |
| idx_audit_log_result | audit_log / result | BTREE | API-12—API-13；按上述字段过滤/关联 | 写入维护与空间成本；核对真实计划和选择率 |

主键及account.uuid/username/phone/email、user_group.group_code、token.token、sys_param.param_code、sys_dict.dict_code、operation.operation_code、app_authorization.app_code/app_key的UNIQUE隐式建立索引，不额外重复建索引。permission_group无额外索引，现阶段按主键关联；新增名称筛选须补查询证据。

`organization.org_path`的普通BTREE不保证所有排序规则下前缀LIKE走索引；`delegation(valid_from,valid_until)`不保证双范围谓词同时高效；status/result低选择率索引须按分布评估。原DDL没有delegation.grantor_id索引，也没有JSONB成员索引；相关查询和删除外键检查需求待Q-07/Q-10批准后选择，不能宣称所有外键均已有索引。

### 4.7 DDL验证、测试数据与验收对应

本轮只做静态检查：正文/SQL文件一致、14表与默认分区齐全、表/列注释覆盖、缺逗号修复、显式索引无重名、索引列存在和FK引用先建表。数据库初始化、约束拒绝、分区路由、执行计划、序列/迁移恢复均未执行。

| TC / AC | 数据与明确验收点 | 实际状态 |
|---|---|---|
| TC-29-001 / AC-29 | TD-01/TD-10；批准专用空库装载schema.sql，核对14表+默认分区、主键/唯一/FK、注释和索引；重复初始化应报对象存在且不重置数据 | 阻断Q-16，未执行 |
| TC-29-002 / AC-29 | TD-05/TD-10；检查重复用户名/组合、悬空FK、超长值拒绝；原模型缺少CHECK的枚举/JSON/时间断言不得伪记通过，批准补充后重验。显式ID装载后校正序列并验证下次ID不冲突 | 阻断Q-10/Q-11/Q-16，未执行 |
| TC-23组 / AC-23、AC-29 | TD-09/TD-10；默认/月分区路由、跨分区复合主键、归档恢复、数量/摘要核对；先提供真实旧库结构/快照再产生增量迁移SQL | 阻断Q-09/Q-16，未执行 |
| TC-30-001 / AC-30 | TD-10；逐项索引以真实API过滤和排序验证计划与批准性能目标；未知规模/阈值不能判通过 | 阻断Q-13/Q-15/Q-16，未执行 |

现有33条表字段样例不改名或添加未批准列，仍需映射实际ID，认证材料通过批准设施生成，UTC按Q-11转换后写入TIMESTAMP。没有提供真实旧库快照，4.4保留迁移步骤而不捏造可执行存量迁移脚本；完整建表SQL仅用于批准空库验证。

## 五、接口操作定义

### 5.1 协议核验状态与公共规则

当前资料仅定义操作名称及鉴权中的 HTTP 401/403，没有可核验的 URL、DTO、分页起点、统一响应或业务码。本章 API-01—API-17 均为接口操作契约草案；方法和路径统一写“待 Q-15”，不会把技能中的示例 URL 或业务码当成授权中心已有接口。同一 API 编号代表一组明确列出的操作，落地接口可增加稳定子编号，不能随意扩大操作集合。

| 事项 | 原文/当前声明 | 建议目标及未决问题 |
|---|---|---|
| 应用身份 | 请求头 AppKey；服务登录 AppKey+AppSecret 或证书 | 普通授权校验是否也验证 secret/签名、重放保护、可信代理 IP 待 Q-05；只把 AppKey 当索引不能自行证明调用者身份 |
| 用户身份 | PRD 使用 user_id，未定义来源 | 建议从已验证令牌得出；如服务端代用户调用，另行批准代调用权限，不接收任意 userId |
| HTTP 状态 | 无效应用 401、无权限 403 | 成功 200；参数错误 400、未找到 404、并发/唯一冲突 409、依赖不可用 503 为候选；是否采用全 200 业务响应待 Q-15 |
| 业务 code | 未提供 | 所有成功和失败 code 均待分配；HTTP 与业务 code 分列，不能把 HTTP 401 当“必填缺失码” |
| 响应字段 | 未提供 | 成功数据、业务 code、提示、traceId、字段错误、可重试性为候选；确切封装待 Q-15 |
| 分页 | 仅写列表 | 建议 pageNum/pageSize，起始页、默认/最大值待 Q-15；sortField 白名单、稳定次序和范围内 total 必须明确 |
| 编辑 | 原文写编辑 | 建议局部更新，缺失不改；新增/编辑分离，敏感只读字段拒绝；关键写入带读取版本，Q-12 |
| 错误与提示 | 未提供 | 建议包含可处理的原因和 traceId；未授权对象是否统一不可见待 Q-01/Q-15；提示不泄露用户存在性或密钥 |
| 故障副作用 | 未提供 | 建议写入原子完成；失败不改变业务对象，可追加失败审计；超时表示结果未知，先查状态再重试 |
| 幂等/重试 | 未提供 | 查询可重试；关联按组合键；授权申请/令牌签发按独立策略；幂等重放前仍重新授权，Q-12 |

下文用 H 表示：成功 HTTP 200（建议），失败采用本表批准后的映射；身份无效/无操作权限分别遵守 401/403 原文要求；业务 code 全部待分配。F 表示：失败不提交业务修改或不返回许可，保留可记录的失败审计；网络超时不能据此断言服务端未提交。R 表示：只读可重试、写操作仅按已批准幂等/版本策略重试。

### 5.2 管理与配置操作

每行分别列出新增、编辑、删除、详情、列表的请求和输出；字段含义及条件使用第三章作为唯一来源。返回“详情”只包含当前主体可读字段。

| API | 操作集合；方法/路径 | 主体/授权范围 | 输入 → 输出 | HTTP / 业务 code；失败与重试 | 关联 BR / AC |
|---|---|---|---|---|---|
| API-01 | 账号新增、编辑、删除、详情、列表；待 Q-15 | 账号管理员/已授予账号范围 | 新增：账号字段且无 id→id/安全详情；编辑：id+变化字段+版本→详情；删除：id+版本→结果；详情：id→安全详情；列表：账号/类型/状态筛选+分页→范围内列表/total | H / 待分配；F；唯一冲突不重试；删除按 Q-10；版本冲突先刷新 | BR-02、BR-08、BR-19、BR-25—BR-27 / AC-02、AC-09、AC-21、AC-28 |
| API-02 | 组织新增、编辑、删除、详情、列表；待 Q-15 | 组织管理员/批准组织范围 | 新增：parentId/名称/类型/排序→组织；编辑：id+字段+版本→组织；删除：id+版本→结果；详情：id→组织；列表：父级/类型/名称+分页或树请求→可见节点；列表/树协议待定 | H / 待分配；F；防环/引用冲突禁止盲重试；移动事务不半改 | BR-09、BR-19、BR-27 / AC-04、AC-10、AC-21 |
| API-03 | 用户组新增、编辑、删除、详情、列表；待 Q-15 | 用户组管理员/批准范围 | 新增：groupCode/groupName/description→组；编辑：id+字段+版本→组；删除：id→结果；详情：id→组及获准成员摘要；列表：编码/名称+分页→列表/total | H / 待分配；F；重复编码拒绝；删除成员连带影响待 Q-10 | BR-08、BR-10、BR-19 / AC-11、AC-21 |
| API-04 | 参数新增、编辑、删除、详情、列表；待 Q-15 | 配置管理员/参数读写范围 | 新增：paramCode/paramValue/description→参数；编辑：id+字段+版本→参数；删除：id→结果；详情：id或编码（协议待定）→授权字段；列表：编码+分页→脱敏列表 | H / 待分配；F；格式/引用失败修正后提交；是否允许存敏感值待 Q-14 | BR-08、BR-20、BR-25 / AC-12、AC-28 |
| API-05 | 字典新增、编辑、删除、详情、列表；待 Q-15 | 配置管理员/字典范围 | 新增：dictCode/dictItems/description→字典；编辑：id+变化项+版本→字典；删除：id→结果；详情：id或编码→字典；列表：编码+分页→列表 | H / 待分配；F；非法数组、重复编码、受保护引用拒绝；R | BR-08、BR-20 / AC-12、AC-28 |
| API-06 | 操作新增、详情、列表；待 Q-15 | 权限管理员登记；获准主体读取 | 新增：operationCode/operationName/operationDesc/resourceType→操作；详情：id→操作；列表：操作码/资源类型+分页→列表；本期没有编辑/删除 | H / 待分配；F；code 唯一；重复提交先按编码查询 | BR-08、BR-11 / AC-13 |
| API-07 | 权限组新增、编辑、删除、详情、列表；待 Q-15 | 权限管理员/可管理操作范围 | 新增：name/description/operationIds→组；编辑：id+变化字段+版本→组；删除：id+版本→结果；详情：id→组和操作集合；列表：名称/操作筛选+分页→列表 | H / 待分配；F；非法引用/越权授予/版本冲突拒绝；删除处理共享影响 | BR-11、BR-19、BR-27 / AC-13、AC-21、AC-25 |
| API-08 | 权限组用户关联新增、编辑、删除、详情、列表；待 Q-15 | 权限管理员/目标账号和可授组范围 | 新增：permissionGroupId/accountId→关联；编辑：关联 id+新组合+版本→关联；删除：关联 id→结果；详情：关联 id→关联；列表：账号/组+分页→关联列表 | H / 待分配；F；同组合唯一；重试不重复授予；替换需原子化 | BR-12、BR-27、BR-30 / AC-03、AC-14 |
| API-09 | 权限组组织关联新增、编辑、删除、详情、列表；待 Q-15 | 权限管理员/目标组织和可授组范围 | 新增：permissionGroupId/orgId→关联；编辑：关联 id+新组合+版本→关联；删除：关联 id→结果；详情：关联 id→关联；列表：组织/组+分页→关联列表 | H / 待分配；F；同组合唯一；子级继承不在客户端自行展开；R | BR-09、BR-12、BR-30 / AC-04、AC-14 |

### 5.3 身份、授权与开放操作

| API | 操作集合；方法/路径 | 主体/授权范围 | 输入 → 输出 | HTTP / 业务 code；失败与重试 | 关联 BR / AC |
|---|---|---|---|---|---|
| API-10 | 登录、退出、刷新令牌、注销令牌；待 Q-15 | 自身/批准管理员；应用和场景受限 | 登录：批准的身份凭据及场景上下文→令牌对/类型/有效期候选；退出：可信当前会话→结果；刷新：refreshToken+应用/场景上下文→新令牌对/有效期；注销：批准范围的令牌标识或会话→结果 | H / 待分配；F；签发/刷新不可盲重试，旧令牌重放按 Q-06；注销不恢复已失效状态 | BR-02、BR-15—BR-17、BR-30 / AC-02、AC-17—AC-19 |
| API-11 | 应用注册、操作授权码绑定、获取应用授权明细、验证应用授权、应用授权刷新；待 Q-15 | 接入管理员管理负责应用；可信应用校验当前用户 | 注册：appCode/组/数据范围→应用安全详情及凭据按 Q-05 签发；绑定：应用标识+目标操作码或组+版本→授权摘要；明细：应用标识→获准操作和范围；验证：见 5.4；刷新：应用标识+刷新意图/版本→结果及策略版本候选 | 原文应用无效 401/无权限 403；其余 H / 待分配；F；绑定按版本，刷新幂等范围 Q-08；查询 R | BR-01、BR-03—BR-07、BR-13、BR-14 / AC-01、AC-03—AC-08、AC-15、AC-16 |
| API-12 | 申请委托授权；待 Q-15 | 已认证申请人；目标人/应用/操作/资源范围须验证 | 目标应用（拟新增）、grantee、组、资源类型/ID 清单、有效期、申请理由、幂等键候选→申请 ID、pending、有效期及当前可见处理信息 | H / 待分配；F；同主体/应用/幂等键+相同参数不重复创建；不同参数冲突；保留期限 Q-12 | BR-06、BR-07、BR-18、BR-30 / AC-06、AC-07、AC-20、AC-26 |
| API-13 | 日志新增、详情、列表、自动归档；待 Q-15 | 可信写入方/受限审计员/归档任务 | 新增：可信事件→持久化确认；详情：日志标识（复合键待 Q-09）→脱敏日志；列表：trace/账号/应用/动作/结果/时间+分页→范围内日志；自动归档：调度策略→归档记录/结果，是否公开任务 API 待定 | H / 待分配；F 以批准审计事务语义为准；重试事件去重策略 Q-09；归档中断不得清除未验证数据 | BR-21—BR-23、BR-29 / AC-22、AC-23、AC-27 |
| API-14 | 开放获取/注销/刷新令牌、获取用户详情/权限；待 Q-15 | 已接入应用；当前账号或批准代调用对象 | 三种令牌动作复用 API-10 的实现与语义；用户详情：受控目标→字段白名单；用户权限：目标+应用上下文→当前应用内操作、范围、版本/委托概况（待 Q-15）；不另建令牌表 | H / 待分配；F；查询 R，令牌操作同 API-10；权限列表不能替代逐资源校验 | BR-24、BR-25 / AC-18、AC-19、AC-24 |

### 5.4 验证应用授权的输入输出建议

以下字段与 JSON 为建议协议示意，未定义线上 URL、HTTP 方法或既有 DTO。此操作只返回授权判断和约束，不执行设备、告警等业务动作。请求中的账号 ID 不作为普通客户端可任意填写字段；账号身份从验证后的令牌取得。资源自身的 creator/dept 等归属由可信业务数据提供，不能信任前端为通过 SELF/DEPT 而伪造的值。

| 方向/字段 | 类型与必填建议 | 语义 |
|---|---|---|
| 请求 AppKey 及证明材料 | AppKey 原文必需；其他凭据 Q-05 | 确认调用应用；AppSecret 不写入普通查询参数或审计体 |
| 请求用户令牌/可信身份 | 条件必需，Q-05/Q-06 | 确认执行账号、会话、应用和场景 |
| operationCode | 非空字符串，最长 128 字符 | 对应 operation.operation_code，不接收未登记操作默认为允许 |
| resourceType | 资源操作条件必需，最长 64 字符 | 必须和操作及委托语义匹配 |
| resourceId | 单资源操作必需，非空字符串，最长 128 字符建议 | 字符串比较；批量/列表缺 ID 场景待 Q-04 |
| sceneId | Scene-Token 条件必需，最长 64 字符 | 必须匹配令牌绑定场景 |
| 响应 allowed | BOOLEAN | false 无业务执行许可；true 仍需执行返回的数据限制 |
| permissionSource | STATIC/DELEGATION 候选 | 允许时解释授权来源；拒绝时不泄露他人委托存在性 |
| dataScope | 结构化逻辑条件对象 | SELF 使用受信账号；DEPT/SPECIFIED 使用批准组织集合；委托使用资源类型/ID 集合 |
| delegationId、validUntil | 委托允许时条件返回 | 标识当前授权依据及期限，是否对所有调用者可见待 Q-09/Q-15 |
| traceId、policyVersion | traceId 为 UUID 候选；版本机制待 Q-08 | 定位请求并检验撤权生效；不是可长时间复用的永久许可 |

合成请求示意；应用凭据和用户令牌由协议中的认证上下文提供，示例不含可用密钥。

```json
{
  "operationCode": "DeviceController.control",
  "resourceType": "device",
  "resourceId": "synthetic-device-001"
}
```

合成 STATIC 结果中的逻辑数据对象，不是完整 HTTP 响应封装。业务服务须将 SELF 映射为自己的创建者字段并执行对象检查；不把授权中心返回的 SQL 字符串直接拼接执行。

```json
{
  "allowed": true,
  "permissionSource": "STATIC",
  "dataScope": {
    "type": "SELF",
    "accountId": "101"
  },
  "traceId": "11111111-1111-4111-8111-111111111111"
}
```

合成 DELEGATION 结果中的逻辑数据对象；只能用于列出的资源及有效期内的操作，不能由此访问同类型其他资源。

```json
{
  "allowed": true,
  "permissionSource": "DELEGATION",
  "delegationId": "301",
  "dataScope": {
    "type": "RESOURCE_IDS",
    "resourceType": "device",
    "resourceIds": ["synthetic-device-001"]
  },
  "validUntil": "2026-09-09T18:00:00+08:00",
  "traceId": "22222222-2222-4222-8222-222222222222"
}
```

RESOURCE_IDS 是建议响应类型，不是偷偷增加 app_authorization.data_scope_type 的枚举值；该数据库列仍只有 SELF/DEPT/SPECIFIED。没有证据的业务 code 不放入示例。

### 5.5 为闭环补充的候选操作

| API | 候选操作；方法/路径 | 主体/范围 | 输入 → 输出 | HTTP/业务 code；失败/重试 | 放行前提/关联 |
|---|---|---|---|---|---|
| API-15 | 账号组织归属维护；用户组成员添加/移除/列表；待定 | 已授权组织/用户组管理员 | 账号/组织或组 ID、主组织标记候选、版本→关联/成员列表 | H / 待分配；F；组合唯一、原子更新；不能为方便同步改变权限 | Q-02 批准；BR-09、BR-10、BR-12 / AC-04、AC-11 |
| API-16 | 委托详情/列表、批准、拒绝、撤销；待定 | 申请人只读自己；处理人限可授出范围 | 委托 ID/筛选条件；处理动作+理由+版本→可见申请或新状态 | H / 待分配；F；冲突先刷新；重复终止不重新激活 | Q-07 批准；BR-07、BR-18、BR-27 / AC-07、AC-20、AC-25 |
| API-17 | 场景令牌签发/兑换；待定，也可并入 API-10 | 已认证主体及获准场景 | 主令牌或批准场景凭据+sceneId→Scene-Token/有效期 | H / 待分配；F；不能以 sceneId 字符串替代场景授权；签发重试依 Q-06 | Q-06 批准；BR-15、BR-16 / AC-17—AC-19 |

这些动作是明确标记的补充建议，没有增加账号批量操作、操作码编辑删除或日志人工改写功能。

## 六、业务状态机

本章先给 Mermaid 状态图，再给对应转移表。图中的状态标识与表中“当前状态/下一状态”逐字对应，边上的事件与表中“事件”逐字对应；失败但没有完成状态转换时保持原状态。图表是目标方案，其中注明建议或 Q 的内容仍待决策。配套 HTML 原位渲染图形并保留可展开源码。

### 6.1 账号与应用

DDL 提供状态值但没有独立冻结接口。是否通过受控编辑或专用动作执行、如何避免管理员自锁，由 Q-05/Q-08/Q-15 决定。

#### 6.1.1 账号状态

```mermaid
stateDiagram-v2
  [*] --> normal: 创建账号
  normal --> frozen: 冻结账号
  frozen --> normal: 解冻账号
```

| 当前状态 | 事件 | 前置条件 | 允许主体 | 副作用 | 失败处理 | 下一状态 |
|---|---|---|---|---|---|---|
| [*] | 创建账号 | 唯一字段、账号类型、凭据规则满足 | 获准账号管理员 | 创建账号；不自动授予管理员权限 | 原子失败，不留下半账号 | normal |
| normal | 冻结账号 | 版本匹配、冻结权限、自锁规则已批准 | 获准账号管理员 | 登录拒绝；既有会话效果按 Q-08 | 不伪报已冻结，刷新状态后重试 | frozen |
| frozen | 解冻账号 | 当前为 frozen、版本匹配 | 获准账号管理员 | 可重新认证；建议不恢复已撤销令牌 | 冲突保持原状态 | normal |

#### 6.1.2 应用状态

```mermaid
stateDiagram-v2
  [*] --> active: 注册应用
  active --> frozen: 冻结应用
  frozen --> active: 解冻应用
```

| 当前状态 | 事件 | 前置条件 | 允许主体 | 副作用 | 失败处理 | 下一状态 |
|---|---|---|---|---|---|---|
| [*] | 注册应用 | 应用唯一、有效授权和凭据规则 | 获准接入负责人 | 建立应用授权 | 失败不外泄或留下无主密钥 | active |
| active | 冻结应用 | 版本匹配且具有冻结权限 | 获准应用管理员 | 校验按原文返回 401；缓存/会话失效待 Q-08 | 记录未完成状态，不返回虚假成功 | frozen |
| frozen | 解冻应用 | 凭据仍满足批准有效条件、版本匹配 | 获准应用管理员 | 按当前授权恢复接入 | 不自动恢复过期凭据或扩大权限 | active |

### 6.2 令牌生命周期（建议，Q-06）

token 表未定义独立 status 列，“有效/过期/撤销”由 expires_at、revoked 与会话规则计算；token_type 与 refresh_type 不是生命周期状态。

图描述单个令牌的生命周期。有效、已消费、过期、撤销为逻辑状态，不是向 DDL 增加已批准的 status 枚举。刷新成功时，旧刷新令牌进入已消费，新令牌是另一个实例，其签发与旧令牌消费必须在同一原子操作中完成；图不把旧令牌画成重新有效。“已消费”是否复用 revoked 或另行表达待 Q-06。

```mermaid
stateDiagram-v2
  state "有效" as valid
  state "已消费（逻辑状态，存储待定）" as consumed
  state "过期" as expired
  state "撤销" as revoked
  [*] --> valid: 签发成功
  valid --> consumed: 刷新轮换成功
  valid --> expired: 到达过期阈值
  valid --> revoked: 退出或注销或冻结关联处理
  consumed --> consumed: 重放已消费令牌
  expired --> expired: 重复注销或刷新过期令牌
  revoked --> revoked: 重复注销或刷新撤销令牌
```

| 当前状态 | 事件 | 前置条件 | 允许主体 | 副作用 | 失败处理 | 下一状态 |
|---|---|---|---|---|---|---|
| [*] | 签发成功 | 身份、应用、IP、场景全部满足；刷新换发须满足原子轮换条件 | 可信签发服务 | 新实例生效并生成批准有效期；不凭账号存在就签发 | 不返回令牌，记录失败摘要 | valid |
| valid | 刷新轮换成功 | 本实例为刷新令牌，未过期/未撤销且配对正确 | 原持有者经可信签发服务处理 | 消费旧实例并原子签发新实例；新权限不大于批准范围 | 并发失败者不产生第二组有效令牌；旧实例状态按事务结果查询 | consumed |
| valid | 到达过期阈值 | 服务端时间满足批准的过期判断，阈值精度待 Q-06/Q-11 | 服务端时间判断 | 后续认证拒绝；不依赖清理任务先改记录 | 时钟异常告警并按批准策略拒绝 | expired |
| valid | 退出或注销或冻结关联处理 | 主体有权作用于该会话或令牌集合 | 本人或获准管理员/可信失效处理服务 | 撤销范围按 Q-06/Q-08；不自动波及未授权对象 | 超时查询状态，不签发替代令牌掩盖错误 | revoked |
| consumed | 重放已消费令牌 | 原刷新令牌已被成功使用 | 持有者请求，认证服务校验 | 拒绝再次刷新；不新增有效会话 | 返回拒绝或批准的幂等结果，不重新签发 | consumed |
| expired | 重复注销或刷新过期令牌 | 原令牌已过期 | 持有者或有权注销的主体 | 不能恢复有效；重复注销响应语义 Q-15 | 返回当前结果或拒绝，不新增会话 | expired |
| revoked | 重复注销或刷新撤销令牌 | 原令牌已撤销 | 持有者或有权注销的主体 | 不能恢复有效；重复注销响应语义 Q-15 | 返回当前结果或拒绝，不新增会话 | revoked |

### 6.3 委托生命周期

原状态是 pending/active/expired/revoked；rejected 为候选新增状态，必须经 Q-07 批准并更新 DDL 后才能使用。不得把拒绝含糊写成 revoked 而不说明业务差异。

```mermaid
stateDiagram-v2
  state "pending 待审批" as pending
  state "active 已批准，仍须检查有效时间" as active
  state "rejected 拒绝（拟新增）" as rejected
  state "revoked 已撤销" as revoked
  state "expired 已过期" as expired
  [*] --> pending: 提交申请
  pending --> active: 批准申请
  pending --> rejected: 拒绝申请
  active --> revoked: 撤销委托
  active --> expired: 超过有效结束时间
  pending --> pending: 过期申请尝试批准
  expired --> expired: 重试或重放终态申请
  revoked --> revoked: 重试或重放终态申请
  rejected --> rejected: 重试或重放终态申请
  note right of active
    仅在 validFrom 小于等于 now 且 now 小于等于 validUntil 时可用
    身份、应用、操作和资源匹配仍需满足 BR-01 至 BR-07
  end note
```

| 当前状态 | 事件 | 前置条件 | 允许主体 | 副作用 | 失败处理 | 下一状态 |
|---|---|---|---|---|---|---|
| [*] | 提交申请 | 身份有效，资源/操作/时间有效，幂等检查通过 | 获准申请人 | 记录申请；尚不授权 | 保留输入并显示具体问题 | pending |
| pending | 批准申请 | 当前有可授出权限，版本一致，未过有效结束时间；范围不超过申请和可授出集合 | 有权处理人 | 记录处理人/时间/批准范围；未来 validFrom 前仍不可用 | 冲突、过期或越权保持 pending | active |
| pending | 拒绝申请 | Q-07 批准拒绝流程；状态/版本一致，理由满足规则 | 有权处理人 | 记录拒绝，不授予权限 | 不伪报已拒绝，保持原状态 | rejected |
| active | 撤销委托 | 撤销范围和版本合法 | 有权撤销主体 | 后续校验拒绝；通知与缓存生效策略 Q-08 | 结果未知时查询当前状态 | revoked |
| active | 超过有效结束时间 | now>validUntil；比较时区待 Q-11 | 服务端时间判断 | 无论清理任务是否运行均失效；可异步更新展示状态 | 定时任务失败不能延长授权 | expired |
| pending | 过期申请尝试批准 | 未批准申请已过 validUntil | 处理人发起，系统校验 | 拒绝批准，不产生权限 | 提示有效期已结束；后续留存/自动终止策略待 Q-07 | pending |
| expired | 重试或重放终态申请 | 已过期 | 原请求方经系统校验 | 不恢复有效；重新申请生成新记录 | 提示重新申请或无权操作 | expired |
| revoked | 重试或重放终态申请 | 已撤销 | 原请求方经系统校验 | 不恢复有效；重新申请生成新记录 | 提示重新申请或无权操作 | revoked |
| rejected | 重试或重放终态申请 | 已拒绝，且拒绝流程已批准 | 原请求方经系统校验 | 不恢复有效；重新申请生成新记录 | 提示重新申请或无权操作 | rejected |

pending 超过 validUntil 后是否自动转 expired、是否保持待审批记录展示，仍由 Q-07 决定，故不绘制未经决定的自动转换。图中的 pending 自循环仅表示“过期申请尝试批准”被拒绝后的状态不变，不代表已经确定过期申请的后台处理方案。active 表示批准状态，不能单独证明当前可用；时间区间仍按 BR-06 保持两端包含。

当多个有效委托同时覆盖一个资源时，建议选择可解释的一条满足记录作为依据；是否合并不同委托资源、组变更是否影响已批准委托均待 Q-07。本期不默认引入转授链。

### 6.4 其他对象与归档

组织、用户组、参数、字典、操作码、权限组和关联表没有业务状态列，N/A：仅定义创建、编辑、删除及引用/版本条件，不凭空新增“启用/停用”。若 Q-10 选择停用代替物理删除，应补充状态与全部消费者规则。

日志归档以下为 Q-09 待批准的任务生命周期示意，当前 DDL 无任务表或归档程序，不声称已有持久化。归档完成须以数据完整性和可恢复性为准，不能以调度请求成功为准。任务状态名为阅读标识，不是已批准的数据库枚举；是否需要记录任务、重试单位和存储方案仍由 Q-09 决定。

```mermaid
stateDiagram-v2
  state "待归档（建议）" as queued
  state "处理中（建议）" as processing
  state "已校验（建议）" as verified
  state "归档完成（建议）" as completed
  state "失败可重试（建议）" as failed
  [*] --> queued: 创建归档任务
  queued --> processing: 启动归档
  processing --> verified: 复制与完整性校验通过
  processing --> failed: 复制或校验失败
  verified --> completed: 确认可恢复并完成策略处理
  verified --> failed: 完成确认失败
  failed --> processing: 核对进度后重试
```

| 当前状态 | 事件 | 前置条件 | 允许主体 | 副作用 | 失败处理 | 下一状态 |
|---|---|---|---|---|---|---|
| [*] | 创建归档任务 | 保留期、源数据范围与归档策略已批准 | 可信调度服务 | 登记待处理范围/批次候选信息 | 不生成虚假成功记录 | queued |
| queued | 启动归档 | 调度授权有效，同批次并发策略满足 Q-09 | 获准归档任务 | 开始读取源数据并复制 | 保留原副本，记录启动错误后按策略重试 | processing |
| processing | 复制与完整性校验通过 | 归档内容与源范围核对通过 | 可信归档任务 | 记录校验结果；尚不能仅据此删除原副本 | 未通过校验不能进入 verified | verified |
| processing | 复制或校验失败 | 复制中断或完整性不符 | 可信归档任务 | 保存失败原因与可恢复进度 | 不删除唯一有效副本；按批准幂等规则恢复 | failed |
| verified | 确认可恢复并完成策略处理 | 可恢复性和批准的保留处理均已完成 | 获准归档任务 | 记录可查询位置和完成结果；是否清理原数据依 Q-09 | 结果未知先核对实际副本，不宣称完成 | completed |
| verified | 完成确认失败 | 可恢复性或策略处理未完成 | 可信归档任务 | 留存失败和已完成阶段，保全有效副本 | 人工或任务核对副本后重试 | failed |
| failed | 核对进度后重试 | 失败原因已处理，已校验副本和处理进度明确 | 获准归档任务/运维触发 | 按进度续作或幂等重做；不重复清理或覆盖有效副本 | 继续失败时保留记录和副本 | processing |

## 七、非功能需求

### 7.1 安全与信息范围

必须分别验证应用身份、账号身份、动作、资源和字段权限。建议由业务后端执行最终数据过滤，覆盖详情、列表、计数、后台任务和单资源写入；客户端隐藏按钮仅用于体验。若存在租户，鉴权、缓存键、唯一约束、日志查询和归档必须一并隔离，实施前关闭 Q-01。

敏感字段包含密码输入/散列、AppSecret、证书私密材料、访问/刷新令牌及个人联系方式。建议凭据经保护通道传输，按最小范围返回和持久化，不进入普通日志/列表。证书校验、AppSecret 存储/轮换、IP/CIDR 校验、登录失败限流与重放保护由安全负责人在 Q-05/Q-06 中定稿，本文不假定已经实现。

纯文本按输出上下文编码；数据库值参数化，动态排序和可选列使用允许列表；JSON 类型/大小/元素长度在服务端验证。对外不可见对象是否返回统一错误须经 Q-15 确认，禁止在错误详情返回内部 SQL、堆栈、完整凭据或其他主体的权限。

### 7.2 性能、容量和可用性验收口径

原文没有性能基线或目标。下表定义如何测量，所有数值待 Q-13；不使用模板中的固定毫秒数作为项目承诺。索引存在不代表性能达标。

| 场景 | 数据规模/分布需记录 | 测量边界与负载 | 必须报告 | 基线/目标/环境/负责人 |
|---|---|---|---|---|
| 授权校验 | 应用、账号、组织层级、每人权限组、每组操作、委托总量及活跃比例 | 接入端发起到收到完整判断；分别冷/热缓存、静态/委托/拒绝、批准并发和持续时长 | p50/p95/p99、吞吐、超时/错误率、CPU/内存/DB 查询数 | 全部待 Q-13；技术/测试负责人 |
| 管理列表 | 账号/组织/权限组数量、筛选命中率、分页深度 | API 总耗时及数据库执行计划，含范围内 total | 延迟分位、扫描行数、排序开销 | 待 Q-13 |
| 撤权传播 | 节点数、缓存层、连接数、变更批量 | 撤权提交至每节点连续拒绝旧许可 | 最大传播时延、旧许可被接受次数、失败节点 | 待 Q-08/Q-13 |
| 审计写入/查询/归档 | 每日事件量、体积、分区数、保留期、归档量 | 写入确认、范围查询、归档可恢复完成分别计时 | 丢失/重复、延迟、积压、分区增长、恢复耗时 | 待 Q-09/Q-13 |
| 服务故障与恢复 | 依赖拓扑、故障类型、备份规模 | 依赖断开/恢复、进程重启、恢复演练 | 可用率、拒绝行为、RTO/RPO、恢复后权限一致性 | 数值和责任人待 Q-13/Q-16 |

### 7.3 审计与可观测性

建议记录请求 traceId、当前应用、受信主体、动作、资源、授权来源、策略版本、结果、原因分类与耗时。主体未知时使用明确的未知身份表达，不能为了写入非空字段伪造真实账号。鉴权允许、业务成功、业务失败、权限拒绝需通过阶段和结果共同区分。

建议监测认证失败突增、越权请求、撤权传播延迟、授权依赖错误、审计丢失/积压、默认分区增长及归档恢复失败。报警阈值、去重、处理人和审计保留期均待 Q-09/Q-13，不宣称现有“日志中心新增接口”已经满足审计可靠性。

### 7.4 管理界面体验建议

以账号与组织、权限配置、应用接入、委托、日志作为导航分组。列表提供明确空态、受权限限制的可见操作和筛选重置；表单显示字段错误并保留输入；关键修改展示影响及版本冲突；删除展示将受影响的关联而非笼统“确认删除”。委托页面区分已提交、尚未到生效时间、已生效和已终止。界面具备键盘焦点和可理解标签，日志/密钥等敏感内容不因复制或展开而越过字段权限。本轮不交付授权中心产品原型，HTML 是需求文档阅读工具。

## 八、边界、异常与恢复

### 8.1 请求、授权与数据异常

| 场景 | 用户/调用方反馈建议 | 必须保持的不变量 | 恢复方式/待决策 |
|---|---|---|---|
| AppKey 无效或应用冻结 | 认证失败，HTTP 401；提示联系应用管理员 | 不进入静态/委托放行路径 | 修正接入配置；冻结解除需授权 |
| 账号无组织或组织来源不可用 | 组织范围不可确定或无可用权限 | 不将 DEPT 解释成全部组织 | 无归属的处理待 Q-02；依赖故障见 Q-08 |
| SPECIFIED 空/无效组织 | 配置错误或空范围；不能返回无限制 | 数据范围不能因无值扩大 | 管理员修正范围；配置保存时尽早拒绝 |
| 有静态许可但目标行不在范围 | 无权访问该资源/资源不可见（统一提示待定） | 不使用委托绕过原文分支 | 由管理员调整静态范围或由业务决定 Q-04 |
| 只有委托但请求为列表、批量或资源 ID 缺失 | 参数不满足/该调用方式待支持 | 缺 ID 不等于所有资源 | Q-04 定义列表/批量合并和过滤协议 |
| 操作不存在或 resourceType 不符 | 操作不可用或无权限 | 不以空操作码/类型通配 | 接入方对齐登记操作 |
| 资源已删除、转移部门或改变创建者 | 资源不可见/需要重新校验 | 决策必须匹配操作执行时的可信资源属性 | 业务写入与校验一致性、有效窗口待 Q-04/Q-08 |
| 账号/权限组在鉴权后被撤销 | 按批准生效时延拒绝旧许可 | 不无限缓存“允许” | 版本/失效机制和重校验待 Q-08 |
| 委托 pending/revoked/过期 | 委托未生效或无权限 | 不因 validUntil 尚未过去就放行 pending/revoked | 查当前状态；新申请不能自动获批 |
| 无法确认授权人仍有可授出权限 | 授权来源不可用/无权限 | 不扩大委托权力 | 当前校验还是快照策略由 Q-07 决定 |
| 凭据过期/轮换中 | 重新认证或更新应用凭据 | 不能静默接受任意旧凭据 | 轮换重叠期及会话处理待 Q-05/Q-08 |

### 8.2 并发、删除、故障与恢复

| 场景 | 反馈建议 | 不应发生的效果 | 恢复/责任 |
|---|---|---|---|
| 两人编辑同一权限配置 | 数据已更新，请刷新并比较 | 后提交者静默覆盖已撤权结果 | 版本冲突保留本地输入，Q-12 |
| 重复委托申请/签发请求 | 返回原业务结果或明确冲突/处理中 | 因超时重试产生重复授权或多组有效令牌 | 幂等作用域、保留期、参数签名待 Q-12 |
| 删除前引用检查通过，提交前新增引用 | 对象被引用，删除未完成 | 孤立引用、部分级联或错误成功提示 | 原子引用检查、事务和冲突处理，Q-10/Q-12 |
| 组织移动跨越受限范围 | 无权移动或范围变化需处理 | 通过移动组织获得其他域权限 | 校验原/目标范围和所有受影响成员，Q-02 |
| 授权依赖超时 | 服务暂不可用，附 traceId | 异常返回 allowed=true | 安全失败策略与受控重试，Q-08 |
| 审计写入失败 | 按已批准阻断/补记策略反馈 | 宣称已审计、丢失高风险操作记录 | 事务、可靠补记和告警方案 Q-09 |
| 归档任务部分完成 | 归档失败/待重试，可查批次 | 未验证归档就删除唯一副本 | 完整性校验、幂等重试、恢复演练，Q-09 |
| SQL 迁移中途失败 | 迁移未完成，记录版本和证据 | 在不兼容结构上继续放行应用 | 已验证的恢复或前滚方案，Q-16 |

## 九、测试用例、测试数据与追溯

### 9.1 测试环境、编号与执行约定

沿用 TC-01—TC-30 作为测试组，以下展开为 141 条独立用例，编号 TC-组号-三位序号。用例逐条定义输入、操作和断言；所有业务用例均未执行，状态为阻断。生成测试数据与验证文档是本轮执行内容，不计入业务结果。

共同前提：测试负责人提供隔离环境、实现/DDL版本、已批准的 Q 结论和测试适配。API-编号[动作]指第五章明确列出的逻辑操作；现有 URL、HTTP 成功协议和业务码尚未提供，Q-15 关闭前不能拼造 curl 请求。实际路由映射、业务装载、时钟/故障注入与日志读取方式必须在执行记录中登记。

身份映射：TD-02.roles.administrator=101、staticUser=102、delegatedUser=103、service=104。这些是合成测试标签；101 这个编号并不自动具有平台管理权限，须按 Q-01 在测试环境配置每例需要的动作/对象/字段范围。无权对照身份必须确认不持有其他直接/组织许可；委托否定用例也不得残留另一条有效委托。

每例通用步骤：0. 恢复本例独立快照，按 TD 选择器构造请求，将合成 ID 映射到实际 ID；记录原值、状态/版本和适用日志起点。1. 执行该例操作。2. 检查响应、页面与持久值及日志/外部副作用。3. 保存证据后按 9.5 清理。并发用例使用同步屏障并等待全部请求结束，不用任意 sleep 假装并发。

P0 是权限、安全、数据完整性及可部署性风险；P1 是其他功能/运行验证建议优先级，仍需业务负责人排期。待定指标不会因标 P1 而豁免。每例的 HTTP/业务码分别记录：原文明确应用身份拒绝 401、五条件委托不匹配 403；其余使用 Q-15 批准结果，不假设全 HTTP 200。

证据记录统一包含环境/构建版本、数据库/策略版本、实际操作者、执行时间、请求（脱敏）、响应、前后快照及适用日志。建议证据目录 validation/business/<TC编号>/ 只是待执行业务记录位置，本轮未创建通过证据。

### 9.2 用例总表

| TC | 测试组/AC | 场景 | 层级/优先级 | TD | 状态 |
| --- | --- | --- | --- | --- | --- |
| TC-01-001 | TC-01 / AC-01 | 无效应用键拒绝 | 接口/集成 / P0 | TD-01、TD-04 | 阻断；Q-05、Q-15 |
| TC-01-002 | TC-01 / AC-01 | 冻结应用拒绝 | 接口/集成 / P0 | TD-01、TD-04 | 阻断；Q-05、Q-15 |
| TC-02-001 | TC-02 / AC-02 | 服务账号密码登录拒绝 | 认证端到端 / P0 | TD-01、TD-04 | 阻断；Q-05、Q-06、Q-15 |
| TC-02-002 | TC-02 / AC-02 | 服务凭据与白名单正例 | 认证端到端 / P0 | TD-01、TD-04 | 阻断；Q-05、Q-06、Q-15 |
| TC-02-003 | TC-02 / AC-02 | 服务凭据白名单外拒绝 | 认证端到端 / P0 | TD-01、TD-04 | 阻断；Q-05、Q-06、Q-15 |
| TC-02-004 | TC-02 / AC-02 | 服务证书正例与失效反例 | 认证端到端 / P0 | TD-01、TD-04 | 阻断；Q-05、Q-06、Q-15 |
| TC-02-005 | TC-02 / AC-02 | 服务账号空白名单 | 认证端到端 / P0 | TD-01、TD-04 | 阻断；Q-05、Q-06、Q-15 |
| TC-03-001 | TC-03 / AC-03 | 直接静态授权正例 | 接口/集成 / P0 | TD-01、TD-02 | 阻断；Q-03、Q-04、Q-15 |
| TC-03-002 | TC-03 / AC-03 | 应用操作上限拒绝 | 接口/集成 / P0 | TD-01、TD-02 | 阻断；Q-03、Q-04、Q-15 |
| TC-03-003 | TC-03 / AC-03 | 移除静态授权后不能缓存旧许可 | 接口/集成 / P0 | TD-01、TD-02 | 阻断；Q-03、Q-04、Q-15 |
| TC-04-001 | TC-04 / AC-04 | 所属与下级继承策略对照 | 接口/集成 / P0 | TD-01、TD-02 | 阻断；Q-02、Q-03、Q-15 |
| TC-04-002 | TC-04 / AC-04 | 移除归属及成员源失效 | 接口/集成 / P0 | TD-01、TD-02、TD-09 | 阻断；Q-02、Q-03、Q-15 |
| TC-05-001 | TC-05 / AC-05 | SELF 列表、计数及写入 | 业务端到端 / P0 | TD-01、TD-02、TD-03 | 阻断；Q-02、Q-04、Q-15 |
| TC-05-002 | TC-05 / AC-05 | DEPT 列表、计数及写入 | 业务端到端 / P0 | TD-01、TD-02、TD-03 | 阻断；Q-02、Q-04、Q-15 |
| TC-05-003 | TC-05 / AC-05 | SPECIFIED 列表、计数及写入 | 业务端到端 / P0 | TD-01、TD-02、TD-03 | 阻断；Q-02、Q-04、Q-15 |
| TC-05-004 | TC-05 / AC-05 | 空/未知指定组织拒绝扩权 | 接口/集成 / P0 | TD-01、TD-03、TD-05 | 阻断；Q-02、Q-04、Q-15 |
| TC-06-001 | TC-06 / AC-06 | 五条件全部匹配 | 接口/集成 / P0 | TD-01、TD-02、TD-03、TD-06 | 阻断；Q-03、Q-04、Q-07、Q-11、Q-15 |
| TC-06-002 | TC-06 / AC-06 | 被授权人不匹配 | 接口/集成 / P0 | TD-01、TD-02、TD-03、TD-06 | 阻断；Q-03、Q-04、Q-07、Q-11、Q-15 |
| TC-06-003 | TC-06 / AC-06 | 权限组不含操作 | 接口/集成 / P0 | TD-01、TD-02、TD-03、TD-06 | 阻断；Q-03、Q-04、Q-07、Q-11、Q-15 |
| TC-06-004 | TC-06 / AC-06 | 资源类型不匹配 | 接口/集成 / P0 | TD-01、TD-02、TD-03、TD-06 | 阻断；Q-03、Q-04、Q-07、Q-11、Q-15 |
| TC-06-005 | TC-06 / AC-06 | 资源ID不匹配 | 接口/集成 / P0 | TD-01、TD-02、TD-03、TD-06 | 阻断；Q-03、Q-04、Q-07、Q-11、Q-15 |
| TC-06-006 | TC-06 / AC-06 | 尚未开始 | 接口/集成 / P0 | TD-01、TD-02、TD-03、TD-06 | 阻断；Q-03、Q-04、Q-07、Q-11、Q-15 |
| TC-06-007 | TC-06 / AC-06 | 超过结束 | 接口/集成 / P0 | TD-01、TD-02、TD-03、TD-06 | 阻断；Q-03、Q-04、Q-07、Q-11、Q-15 |
| TC-07-001 | TC-07 / AC-07 | 未批准委托 | 接口/集成 / P0 | TD-01、TD-02、TD-06 | 阻断；Q-07、Q-08、Q-15 |
| TC-07-002 | TC-07 / AC-07 | 撤销委托 | 接口/集成 / P0 | TD-01、TD-02、TD-06 | 阻断；Q-07、Q-08、Q-15 |
| TC-07-003 | TC-07 / AC-07 | 过期委托 | 接口/集成 / P0 | TD-01、TD-02、TD-06 | 阻断；Q-07、Q-08、Q-15 |
| TC-07-004 | TC-07 / AC-07 | 跨应用委托 | 接口/集成 / P0 | TD-01、TD-02、TD-06 | 阻断；Q-07、Q-08、Q-15 |
| TC-07-005 | TC-07 / AC-07 | 越权授予人 | 接口/集成 / P0 | TD-01、TD-02、TD-06 | 阻断；Q-07、Q-08、Q-15 |
| TC-07-006 | TC-07 / AC-07 | 申请人自批 | 接口/集成 / P0 | TD-01、TD-02、TD-06 | 阻断；Q-07、Q-08、Q-15 |
| TC-08-001 | TC-08 / AC-08 | 静态超行范围不进入委托 | 业务端到端 / P0 | TD-01、TD-02、TD-03 | 阻断；Q-04、Q-15 |
| TC-09-001 | TC-09 / AC-09 | 账号新增 | 接口/集成 / P1 | TD-01、TD-02、TD-07 | 阻断；Q-01、Q-05、Q-10、Q-12、Q-15 |
| TC-09-002 | TC-09 / AC-09 | 账号编辑 | 接口/集成 / P1 | TD-01、TD-02、TD-07 | 阻断；Q-01、Q-05、Q-10、Q-12、Q-15 |
| TC-09-003 | TC-09 / AC-09 | 账号详情 | 接口/集成 / P1 | TD-01、TD-02、TD-07 | 阻断；Q-01、Q-05、Q-10、Q-12、Q-15 |
| TC-09-004 | TC-09 / AC-09 | 账号列表 | 接口/集成 / P1 | TD-01、TD-02、TD-07 | 阻断；Q-01、Q-05、Q-10、Q-12、Q-15 |
| TC-09-005 | TC-09 / AC-09 | 账号删除 | 接口/集成 / P1 | TD-01、TD-02、TD-07 | 阻断；Q-01、Q-05、Q-10、Q-12、Q-15 |
| TC-10-001 | TC-10 / AC-10 | 组织新增 | 接口/集成 / P1 | TD-01、TD-02、TD-07 | 阻断；Q-02、Q-12、Q-15 |
| TC-10-002 | TC-10 / AC-10 | 组织编辑 | 接口/集成 / P1 | TD-01、TD-02、TD-07 | 阻断；Q-02、Q-12、Q-15 |
| TC-10-003 | TC-10 / AC-10 | 组织详情 | 接口/集成 / P1 | TD-01、TD-02、TD-07 | 阻断；Q-02、Q-12、Q-15 |
| TC-10-004 | TC-10 / AC-10 | 组织列表 | 接口/集成 / P1 | TD-01、TD-02、TD-07 | 阻断；Q-02、Q-12、Q-15 |
| TC-10-005 | TC-10 / AC-10 | 组织删除 | 接口/集成 / P1 | TD-01、TD-02、TD-07 | 阻断；Q-02、Q-12、Q-15 |
| TC-11-001 | TC-11 / AC-11 | 用户组新增 | 接口/集成 / P1 | TD-01、TD-02、TD-07 | 阻断；Q-02、Q-10、Q-12、Q-15 |
| TC-11-002 | TC-11 / AC-11 | 用户组编辑 | 接口/集成 / P1 | TD-01、TD-02、TD-07 | 阻断；Q-02、Q-10、Q-12、Q-15 |
| TC-11-003 | TC-11 / AC-11 | 用户组详情 | 接口/集成 / P1 | TD-01、TD-02、TD-07 | 阻断；Q-02、Q-10、Q-12、Q-15 |
| TC-11-004 | TC-11 / AC-11 | 用户组列表 | 接口/集成 / P1 | TD-01、TD-02、TD-07 | 阻断；Q-02、Q-10、Q-12、Q-15 |
| TC-11-005 | TC-11 / AC-11 | 用户组删除 | 接口/集成 / P1 | TD-01、TD-02、TD-07 | 阻断；Q-02、Q-10、Q-12、Q-15 |
| TC-12-001 | TC-12 / AC-12 | 参数新增 | 接口/集成 / P1 | TD-01、TD-02、TD-07 | 阻断；Q-10、Q-14、Q-15 |
| TC-12-002 | TC-12 / AC-12 | 参数编辑 | 接口/集成 / P1 | TD-01、TD-02、TD-07 | 阻断；Q-10、Q-14、Q-15 |
| TC-12-003 | TC-12 / AC-12 | 参数详情 | 接口/集成 / P1 | TD-01、TD-02、TD-07 | 阻断；Q-10、Q-14、Q-15 |
| TC-12-004 | TC-12 / AC-12 | 参数列表 | 接口/集成 / P1 | TD-01、TD-02、TD-07 | 阻断；Q-10、Q-14、Q-15 |
| TC-12-005 | TC-12 / AC-12 | 参数删除 | 接口/集成 / P1 | TD-01、TD-02、TD-07 | 阻断；Q-10、Q-14、Q-15 |
| TC-12-006 | TC-12 / AC-12 | 字典新增 | 接口/集成 / P1 | TD-01、TD-02、TD-07 | 阻断；Q-10、Q-14、Q-15 |
| TC-12-007 | TC-12 / AC-12 | 字典编辑 | 接口/集成 / P1 | TD-01、TD-02、TD-07 | 阻断；Q-10、Q-14、Q-15 |
| TC-12-008 | TC-12 / AC-12 | 字典详情 | 接口/集成 / P1 | TD-01、TD-02、TD-07 | 阻断；Q-10、Q-14、Q-15 |
| TC-12-009 | TC-12 / AC-12 | 字典列表 | 接口/集成 / P1 | TD-01、TD-02、TD-07 | 阻断；Q-10、Q-14、Q-15 |
| TC-12-010 | TC-12 / AC-12 | 字典删除 | 接口/集成 / P1 | TD-01、TD-02、TD-07 | 阻断；Q-10、Q-14、Q-15 |
| TC-13-001 | TC-13 / AC-13 | 权限组新增 | 接口/集成 / P1 | TD-01、TD-02、TD-07 | 阻断；Q-03、Q-12、Q-15 |
| TC-13-002 | TC-13 / AC-13 | 权限组编辑 | 接口/集成 / P1 | TD-01、TD-02、TD-07 | 阻断；Q-03、Q-12、Q-15 |
| TC-13-003 | TC-13 / AC-13 | 权限组详情 | 接口/集成 / P1 | TD-01、TD-02、TD-07 | 阻断；Q-03、Q-12、Q-15 |
| TC-13-004 | TC-13 / AC-13 | 权限组列表 | 接口/集成 / P1 | TD-01、TD-02、TD-07 | 阻断；Q-03、Q-12、Q-15 |
| TC-13-005 | TC-13 / AC-13 | 权限组删除 | 接口/集成 / P1 | TD-01、TD-02、TD-07 | 阻断；Q-03、Q-12、Q-15 |
| TC-14-001 | TC-14 / AC-14 | 用户授权关联新增 | 接口/集成 / P0 | TD-01、TD-02、TD-07 | 阻断；Q-01、Q-12、Q-15 |
| TC-14-002 | TC-14 / AC-14 | 用户授权关联编辑 | 接口/集成 / P0 | TD-01、TD-02、TD-07 | 阻断；Q-01、Q-12、Q-15 |
| TC-14-003 | TC-14 / AC-14 | 用户授权关联详情 | 接口/集成 / P0 | TD-01、TD-02、TD-07 | 阻断；Q-01、Q-12、Q-15 |
| TC-14-004 | TC-14 / AC-14 | 用户授权关联列表 | 接口/集成 / P0 | TD-01、TD-02、TD-07 | 阻断；Q-01、Q-12、Q-15 |
| TC-14-005 | TC-14 / AC-14 | 用户授权关联删除 | 接口/集成 / P0 | TD-01、TD-02、TD-07 | 阻断；Q-01、Q-12、Q-15 |
| TC-14-006 | TC-14 / AC-14 | 组织授权关联新增 | 接口/集成 / P0 | TD-01、TD-02、TD-07 | 阻断；Q-01、Q-12、Q-15 |
| TC-14-007 | TC-14 / AC-14 | 组织授权关联编辑 | 接口/集成 / P0 | TD-01、TD-02、TD-07 | 阻断；Q-01、Q-12、Q-15 |
| TC-14-008 | TC-14 / AC-14 | 组织授权关联详情 | 接口/集成 / P0 | TD-01、TD-02、TD-07 | 阻断；Q-01、Q-12、Q-15 |
| TC-14-009 | TC-14 / AC-14 | 组织授权关联列表 | 接口/集成 / P0 | TD-01、TD-02、TD-07 | 阻断；Q-01、Q-12、Q-15 |
| TC-14-010 | TC-14 / AC-14 | 组织授权关联删除 | 接口/集成 / P0 | TD-01、TD-02、TD-07 | 阻断；Q-01、Q-12、Q-15 |
| TC-09-006 | TC-09 / AC-09 | 账号重复/只读字段/长度校验 | 接口/集成 / P1 | TD-01、TD-05 | 阻断；Q-01、Q-05、Q-10、Q-12、Q-15 |
| TC-10-006 | TC-10 / AC-10 | 移动子树与防环 | 接口/集成 / P1 | TD-01、TD-07 | 阻断；Q-02、Q-12、Q-15 |
| TC-11-006 | TC-11 / AC-11 | 跨部门成员及重复/移除 | 接口/集成 / P1 | TD-01、TD-02 | 阻断；Q-02、Q-10、Q-12、Q-15 |
| TC-12-011 | TC-12 / AC-12 | 配置结构与唯一引用校验 | 接口/集成 / P1 | TD-01、TD-05 | 阻断；Q-10、Q-14、Q-15 |
| TC-13-006 | TC-13 / AC-13 | 操作登记新增 | 接口/集成 / P1 | TD-01 | 阻断；Q-03、Q-12、Q-15 |
| TC-13-007 | TC-13 / AC-13 | 操作登记详情 | 接口/集成 / P1 | TD-01 | 阻断；Q-03、Q-12、Q-15 |
| TC-13-008 | TC-13 / AC-13 | 操作登记列表 | 接口/集成 / P1 | TD-01 | 阻断；Q-03、Q-12、Q-15 |
| TC-13-009 | TC-13 / AC-13 | 重复操作与无效权限引用 | 接口/集成 / P1 | TD-01、TD-05 | 阻断；Q-03、Q-12、Q-15 |
| TC-14-011 | TC-14 / AC-14 | 同组合并发建立与原子替换 | 事务/并发 / P0 | TD-01、TD-07 | 阻断；Q-01、Q-12、Q-15 |
| TC-15-001 | TC-15 / AC-15 | 应用注册 | 接口/集成 / P0 | TD-01、TD-02 | 阻断；Q-03、Q-05、Q-15 |
| TC-15-002 | TC-15 / AC-15 | 操作绑定及共享影响 | 接口/集成 / P0 | TD-01、TD-02 | 阻断；Q-03、Q-05、Q-15 |
| TC-15-003 | TC-15 / AC-15 | 授权明细 | 接口/集成 / P0 | TD-01、TD-02 | 阻断；Q-03、Q-05、Q-15 |
| TC-16-001 | TC-16 / AC-16 | 授权刷新与撤权传播 | 多节点运行验证 / P0 | TD-01、TD-07、TD-10 | 阻断；Q-08、Q-13、Q-15 |
| TC-17-001 | TC-17 / AC-17 | Master 与 Scene 登录签发 | 认证端到端 / P1 | TD-01、TD-02、TD-04 | 阻断；Q-05、Q-06、Q-11、Q-15 |
| TC-17-002 | TC-17 / AC-17 | 错误场景及过期拒绝 | 认证端到端 / P1 | TD-01、TD-02、TD-04、TD-06 | 阻断；Q-05、Q-06、Q-11、Q-15 |
| TC-18-001 | TC-18 / AC-18 | 并发刷新与旧令牌重放 | 事务/并发 / P0 | TD-01、TD-02、TD-07 | 阻断；Q-06、Q-12、Q-15 |
| TC-18-002 | TC-18 / AC-18 | 刷新响应丢失后的恢复 | 故障注入 / P0 | TD-01、TD-02、TD-09 | 阻断；Q-06、Q-12、Q-15 |
| TC-19-001 | TC-19 / AC-19 | 退出当前会话与注销范围 | 接口/集成 / P0 | TD-01、TD-02 | 阻断；Q-06、Q-08、Q-15 |
| TC-20-001 | TC-20 / AC-20 | 申请幂等与参数冲突 | 接口/集成 / P0 | TD-01、TD-02、TD-06、TD-07 | 阻断；Q-07、Q-12、Q-15 |
| TC-20-002 | TC-20 / AC-20 | 委托查询可见范围 | 接口/集成 / P0 | TD-01、TD-02 | 阻断；Q-07、Q-12、Q-15 |
| TC-21-001 | TC-21 / AC-21 | 账号101 被引用删除 | 事务/引用 / P0 | TD-01、TD-07 | 阻断；Q-10、Q-12、Q-15 |
| TC-21-002 | TC-21 / AC-21 | 组织11 被引用删除 | 事务/引用 / P0 | TD-01、TD-07 | 阻断；Q-10、Q-12、Q-15 |
| TC-21-003 | TC-21 / AC-21 | 权限组401 被引用删除 | 事务/引用 / P0 | TD-01、TD-07 | 阻断；Q-10、Q-12、Q-15 |
| TC-22-001 | TC-22 / AC-22 | 四类事件与脱敏追加 | 审计集成 / P0 | TD-01、TD-02、TD-09 | 阻断；Q-09、Q-15 |
| TC-22-002 | TC-22 / AC-22 | 审计读写越权 | 接口/集成 / P0 | TD-01、TD-02 | 阻断；Q-09、Q-15 |
| TC-23-001 | TC-23 / AC-23 | 归档恢复与重复批次 | 隔离恢复演练 / P1 | TD-01、TD-09、TD-10 | 阻断；Q-09、Q-13、Q-15 |
| TC-24-001 | TC-24 / AC-24 | 开放详情与权限限制 | 安全接口 / P0 | TD-01、TD-02 | 阻断；Q-01、Q-15 |
| TC-24-002 | TC-24 / AC-24 | 开放获取令牌复用签发 | 认证端到端 / P0 | TD-01、TD-02、TD-04 | 阻断；Q-01、Q-15 |
| TC-25-001 | TC-25 / AC-25 | 权限/应用/委托陈旧版本编辑 | 并发/界面 / P0 | TD-01、TD-07 | 阻断；Q-12、Q-15 |
| TC-26-001 | TC-26 / AC-26 | 委托时刻 beforeFrom | 可控时钟 / P1 | TD-01、TD-02、TD-06 | 阻断；Q-06、Q-11、Q-15 |
| TC-26-002 | TC-26 / AC-26 | 委托时刻 atFrom | 可控时钟 / P1 | TD-01、TD-02、TD-06 | 阻断；Q-06、Q-11、Q-15 |
| TC-26-003 | TC-26 / AC-26 | 委托时刻 atUntil | 可控时钟 / P1 | TD-01、TD-02、TD-06 | 阻断；Q-06、Q-11、Q-15 |
| TC-26-004 | TC-26 / AC-26 | 委托时刻 afterUntil | 可控时钟 / P1 | TD-01、TD-02、TD-06 | 阻断；Q-06、Q-11、Q-15 |
| TC-26-005 | TC-26 / AC-26 | 时区等价与逆序区间 | 可控时钟 / P1 | TD-01、TD-06 | 阻断；Q-06、Q-11、Q-15 |
| TC-27-001 | TC-27 / AC-27 | 依赖故障 permission-source-timeout | 故障注入 / P0 | TD-01、TD-09 | 阻断；Q-08、Q-09、Q-15 |
| TC-27-002 | TC-27 / AC-27 | 依赖故障 cache-unavailable | 故障注入 / P0 | TD-01、TD-09 | 阻断；Q-08、Q-09、Q-15 |
| TC-27-003 | TC-27 / AC-27 | 依赖故障 audit-write-failure | 故障注入 / P0 | TD-01、TD-09 | 阻断；Q-08、Q-09、Q-15 |
| TC-28-001 | TC-28 / AC-28 | 长度边界与字段空值 | 接口/集成 / P1 | TD-01、TD-05 | 阻断；Q-01、Q-12、Q-14、Q-15 |
| TC-28-002 | TC-28 / AC-28 | 大ID与排序/文本注入 | 安全/界面 / P1 | TD-01、TD-05 | 阻断；Q-01、Q-12、Q-14、Q-15 |
| TC-29-001 | TC-29 / AC-29 | DDL修订前置与空库初始化 | 隔离数据库 / P0 | TD-01、TD-10 | 阻断；Q-16 |
| TC-29-002 | TC-29 / AC-29 | 非法约束与序列/迁移恢复 | 隔离数据库 / P0 | TD-01、TD-05、TD-10 | 阻断；Q-16 |
| TC-30-001 | TC-30 / AC-30 | 性能与撤权/归档运行指标 | 性能/运行验证 / P1 | TD-03、TD-09、TD-10 | 阻断；Q-08、Q-09、Q-13、Q-15 |
| TC-09-007 | TC-09 / AC-09 | account：[*] —创建账号→ normal | 状态/集成 / P1 | TD-01、TD-02、TD-06、TD-08、TD-09 | 阻断；Q-05、Q-08、Q-12、Q-15 |
| TC-09-008 | TC-09 / AC-09 | account：normal —冻结账号→ frozen | 状态/集成 / P1 | TD-01、TD-02、TD-06、TD-08、TD-09 | 阻断；Q-05、Q-08、Q-12、Q-15 |
| TC-09-009 | TC-09 / AC-09 | account：frozen —解冻账号→ normal | 状态/集成 / P1 | TD-01、TD-02、TD-06、TD-08、TD-09 | 阻断；Q-05、Q-08、Q-12、Q-15 |
| TC-15-004 | TC-15 / AC-15 | app：[*] —注册应用→ active | 状态/集成 / P0 | TD-01、TD-02、TD-06、TD-08、TD-09 | 阻断；Q-05、Q-08、Q-12、Q-15 |
| TC-15-005 | TC-15 / AC-15 | app：active —冻结应用→ frozen | 状态/集成 / P0 | TD-01、TD-02、TD-06、TD-08、TD-09 | 阻断；Q-05、Q-08、Q-12、Q-15 |
| TC-15-006 | TC-15 / AC-15 | app：frozen —解冻应用→ active | 状态/集成 / P0 | TD-01、TD-02、TD-06、TD-08、TD-09 | 阻断；Q-05、Q-08、Q-12、Q-15 |
| TC-17-003 | TC-17 / AC-17 | token：[*] —签发成功→ valid | 状态/集成 / P1 | TD-01、TD-02、TD-06、TD-08、TD-09 | 阻断；Q-06、Q-11、Q-12、Q-15 |
| TC-18-003 | TC-18 / AC-18 | token：valid —刷新轮换成功→ consumed | 状态/集成 / P0 | TD-01、TD-02、TD-06、TD-08、TD-09 | 阻断；Q-06、Q-11、Q-12、Q-15 |
| TC-17-004 | TC-17 / AC-17 | token：valid —到达过期阈值→ expired | 状态/集成 / P1 | TD-01、TD-02、TD-06、TD-08、TD-09 | 阻断；Q-06、Q-11、Q-12、Q-15 |
| TC-19-002 | TC-19 / AC-19 | token：valid —退出或注销或冻结关联处理→ revoked | 状态/集成 / P0 | TD-01、TD-02、TD-06、TD-08、TD-09 | 阻断；Q-06、Q-11、Q-12、Q-15 |
| TC-18-004 | TC-18 / AC-18 | token：consumed —重放已消费令牌→ consumed | 状态/集成 / P0 | TD-01、TD-02、TD-06、TD-08、TD-09 | 阻断；Q-06、Q-11、Q-12、Q-15 |
| TC-17-005 | TC-17 / AC-17 | token：expired —重复注销或刷新过期令牌→ expired | 状态/集成 / P1 | TD-01、TD-02、TD-06、TD-08、TD-09 | 阻断；Q-06、Q-11、Q-12、Q-15 |
| TC-19-003 | TC-19 / AC-19 | token：revoked —重复注销或刷新撤销令牌→ revoked | 状态/集成 / P0 | TD-01、TD-02、TD-06、TD-08、TD-09 | 阻断；Q-06、Q-11、Q-12、Q-15 |
| TC-20-003 | TC-20 / AC-20 | delegation：[*] —提交申请→ pending | 状态/集成 / P0 | TD-01、TD-02、TD-06、TD-08、TD-09 | 阻断；Q-07、Q-11、Q-12、Q-15 |
| TC-20-004 | TC-20 / AC-20 | delegation：pending —批准申请→ active | 状态/集成 / P0 | TD-01、TD-02、TD-06、TD-08、TD-09 | 阻断；Q-07、Q-11、Q-12、Q-15 |
| TC-20-005 | TC-20 / AC-20 | delegation：pending —拒绝申请→ rejected | 状态/集成 / P0 | TD-01、TD-02、TD-06、TD-08、TD-09 | 阻断；Q-07、Q-11、Q-12、Q-15 |
| TC-20-006 | TC-20 / AC-20 | delegation：active —撤销委托→ revoked | 状态/集成 / P0 | TD-01、TD-02、TD-06、TD-08、TD-09 | 阻断；Q-07、Q-11、Q-12、Q-15 |
| TC-20-007 | TC-20 / AC-20 | delegation：active —超过有效结束时间→ expired | 状态/集成 / P0 | TD-01、TD-02、TD-06、TD-08、TD-09 | 阻断；Q-07、Q-11、Q-12、Q-15 |
| TC-20-008 | TC-20 / AC-20 | delegation：pending —过期申请尝试批准→ pending | 状态/集成 / P0 | TD-01、TD-02、TD-06、TD-08、TD-09 | 阻断；Q-07、Q-11、Q-12、Q-15 |
| TC-20-009 | TC-20 / AC-20 | delegation：expired —重试或重放终态申请→ expired | 状态/集成 / P0 | TD-01、TD-02、TD-06、TD-08、TD-09 | 阻断；Q-07、Q-11、Q-12、Q-15 |
| TC-20-010 | TC-20 / AC-20 | delegation：revoked —重试或重放终态申请→ revoked | 状态/集成 / P0 | TD-01、TD-02、TD-06、TD-08、TD-09 | 阻断；Q-07、Q-11、Q-12、Q-15 |
| TC-20-011 | TC-20 / AC-20 | delegation：rejected —重试或重放终态申请→ rejected | 状态/集成 / P0 | TD-01、TD-02、TD-06、TD-08、TD-09 | 阻断；Q-07、Q-11、Q-12、Q-15 |
| TC-23-002 | TC-23 / AC-23 | archive：[*] —创建归档任务→ queued | 状态/集成 / P1 | TD-01、TD-02、TD-06、TD-08、TD-09 | 阻断；Q-09、Q-13、Q-15 |
| TC-23-003 | TC-23 / AC-23 | archive：queued —启动归档→ processing | 状态/集成 / P1 | TD-01、TD-02、TD-06、TD-08、TD-09 | 阻断；Q-09、Q-13、Q-15 |
| TC-23-004 | TC-23 / AC-23 | archive：processing —复制与完整性校验通过→ verified | 状态/集成 / P1 | TD-01、TD-02、TD-06、TD-08、TD-09 | 阻断；Q-09、Q-13、Q-15 |
| TC-23-005 | TC-23 / AC-23 | archive：processing —复制或校验失败→ failed | 状态/集成 / P1 | TD-01、TD-02、TD-06、TD-08、TD-09 | 阻断；Q-09、Q-13、Q-15 |
| TC-23-006 | TC-23 / AC-23 | archive：verified —确认可恢复并完成策略处理→ completed | 状态/集成 / P1 | TD-01、TD-02、TD-06、TD-08、TD-09 | 阻断；Q-09、Q-13、Q-15 |
| TC-23-007 | TC-23 / AC-23 | archive：verified —完成确认失败→ failed | 状态/集成 / P1 | TD-01、TD-02、TD-06、TD-08、TD-09 | 阻断；Q-09、Q-13、Q-15 |
| TC-23-008 | TC-23 / AC-23 | archive：failed —核对进度后重试→ processing | 状态/集成 / P1 | TD-01、TD-02、TD-06、TD-08、TD-09 | 阻断；Q-09、Q-13、Q-15 |

### 9.3 逐条用例详情

#### TC-01-001：无效应用键拒绝

| 项目 | 执行定义 |
| --- | --- |
| 关联与角色 | AC-01；US-11 / BR-01；API-11 / 应用状态和唯一键；角色 TD-02.roles.delegatedUser |
| 前置条件 | 完成9.1通用前提；关闭 Q-05、Q-15；每个子场景独立还原，不能沿用上一子场景的修改 |
| 具体数据 | TD-01、TD-04；appKey=TD-04.appInvalid；operationCode=DeviceController.control |
| 操作步骤 | 调用 API-11[验证应用授权]；通过受控调用追踪检查后续校验是否发生 |
| 预期结果与禁止副作用 | HTTP 401；不查询委托进行放行，不执行业务动作，业务码仍待 Q-15。 HTTP/业务码依9.1分列；非本例目标对象、凭据与授权关系不得附带变化。 |
| 清理/重跑 | 保存脱敏证据，按ID映射只清理本例生成对象并恢复初始字段/版本；关系先子后父；不清共享审计；步骤见9.5 |
| 实际执行 | 阻断；实际结果/环境/构建版本/执行人/时间/证据均无；拟证据目录 validation/business/TC-01-001/ |

#### TC-01-002：冻结应用拒绝

| 项目 | 执行定义 |
| --- | --- |
| 关联与角色 | AC-01；US-11 / BR-01；API-11 / 应用状态和唯一键；角色 TD-02.roles.delegatedUser |
| 前置条件 | 完成9.1通用前提；关闭 Q-05、Q-15；每个子场景独立还原，不能沿用上一子场景的修改 |
| 具体数据 | TD-01、TD-04；app=503/frozen；grantee=103；存在 active 委托 601 |
| 操作步骤 | 以冻结应用请求 dev-001 的 control |
| 预期结果与禁止副作用 | HTTP 401；有效委托不能绕过应用冻结；资源不变。 HTTP/业务码依9.1分列；非本例目标对象、凭据与授权关系不得附带变化。 |
| 清理/重跑 | 保存脱敏证据，按ID映射只清理本例生成对象并恢复初始字段/版本；关系先子后父；不清共享审计；步骤见9.5 |
| 实际执行 | 阻断；实际结果/环境/构建版本/执行人/时间/证据均无；拟证据目录 validation/business/TC-01-002/ |

#### TC-02-001：服务账号密码登录拒绝

| 项目 | 执行定义 |
| --- | --- |
| 关联与角色 | AC-02；US-01、US-04 / BR-02；API-01、API-10 / DB-05；角色 TD-02.roles.service |
| 前置条件 | 完成9.1通用前提；关闭 Q-05、Q-06、Q-15；每个子场景独立还原，不能沿用上一子场景的修改 |
| 具体数据 | TD-01、TD-04；account=104；password=TD-04.passwordAttempt |
| 操作步骤 | 通过批准的 API-10[登录]分别提交；核对签发记录数及拒绝原因 |
| 预期结果与禁止副作用 | 拒绝且不签发访问或刷新令牌。 HTTP/业务码依9.1分列；非本例目标对象、凭据与授权关系不得附带变化。 |
| 清理/重跑 | 保存脱敏证据，按ID映射只清理本例生成对象并恢复初始字段/版本；关系先子后父；不清共享审计；步骤见9.5 |
| 实际执行 | 阻断；实际结果/环境/构建版本/执行人/时间/证据均无；拟证据目录 validation/business/TC-02-001/ |

#### TC-02-002：服务凭据与白名单正例

| 项目 | 执行定义 |
| --- | --- |
| 关联与角色 | AC-02；US-01、US-04 / BR-02；API-01、API-10 / DB-05；角色 TD-02.roles.service |
| 前置条件 | 完成9.1通用前提；关闭 Q-05、Q-06、Q-15；每个子场景独立还原，不能沿用上一子场景的修改 |
| 具体数据 | TD-01、TD-04；account=104；credentialRef=fixture:service-104；IP=192.0.2.10 |
| 操作步骤 | 通过批准的 API-10[登录]分别提交；核对签发记录数及拒绝原因 |
| 预期结果与禁止副作用 | 经已批准适配注入有效测试凭据后可进入后续认证；仅凭占位标签不能签发。 HTTP/业务码依9.1分列；非本例目标对象、凭据与授权关系不得附带变化。 |
| 清理/重跑 | 保存脱敏证据，按ID映射只清理本例生成对象并恢复初始字段/版本；关系先子后父；不清共享审计；步骤见9.5 |
| 实际执行 | 阻断；实际结果/环境/构建版本/执行人/时间/证据均无；拟证据目录 validation/business/TC-02-002/ |

#### TC-02-003：服务凭据白名单外拒绝

| 项目 | 执行定义 |
| --- | --- |
| 关联与角色 | AC-02；US-01、US-04 / BR-02；API-01、API-10 / DB-05；角色 TD-02.roles.service |
| 前置条件 | 完成9.1通用前提；关闭 Q-05、Q-06、Q-15；每个子场景独立还原，不能沿用上一子场景的修改 |
| 具体数据 | TD-01、TD-04；account=104；相同有效测试凭据；IP=198.51.100.10 |
| 操作步骤 | 通过批准的 API-10[登录]分别提交；核对签发记录数及拒绝原因 |
| 预期结果与禁止副作用 | 拒绝且不签发令牌；不能以客户端伪造的转发头覆盖可信源 IP。 HTTP/业务码依9.1分列；非本例目标对象、凭据与授权关系不得附带变化。 |
| 清理/重跑 | 保存脱敏证据，按ID映射只清理本例生成对象并恢复初始字段/版本；关系先子后父；不清共享审计；步骤见9.5 |
| 实际执行 | 阻断；实际结果/环境/构建版本/执行人/时间/证据均无；拟证据目录 validation/business/TC-02-003/ |

#### TC-02-004：服务证书正例与失效反例

| 项目 | 执行定义 |
| --- | --- |
| 关联与角色 | AC-02；US-01、US-04 / BR-02；API-01、API-10 / DB-05；角色 TD-02.roles.service |
| 前置条件 | 完成9.1通用前提；关闭 Q-05、Q-06、Q-15；每个子场景独立还原，不能沿用上一子场景的修改 |
| 具体数据 | TD-01、TD-04；certificateRef=fixture:certificate-104；IP=192.0.2.10；分别注入有效/过期/撤销证书 |
| 操作步骤 | 通过批准的 API-10[登录]分别提交；核对签发记录数及拒绝原因 |
| 预期结果与禁止副作用 | 只有有效证书且绑定主体/IP 正确者进入后续认证；过期或撤销均拒绝。 HTTP/业务码依9.1分列；非本例目标对象、凭据与授权关系不得附带变化。 |
| 清理/重跑 | 保存脱敏证据，按ID映射只清理本例生成对象并恢复初始字段/版本；关系先子后父；不清共享审计；步骤见9.5 |
| 实际执行 | 阻断；实际结果/环境/构建版本/执行人/时间/证据均无；拟证据目录 validation/business/TC-02-004/ |

#### TC-02-005：服务账号空白名单

| 项目 | 执行定义 |
| --- | --- |
| 关联与角色 | AC-02；US-01、US-04 / BR-02；API-01、API-10 / DB-05；角色 TD-02.roles.service |
| 前置条件 | 完成9.1通用前提；关闭 Q-05、Q-06、Q-15；每个子场景独立还原，不能沿用上一子场景的修改 |
| 具体数据 | TD-01、TD-04；account=104；分别 ipWhitelist=[]、null |
| 操作步骤 | 通过批准的 API-10[登录]分别提交；核对签发记录数及拒绝原因 |
| 预期结果与禁止副作用 | 两组均不得解释为全网；按批准规则拒绝保存或认证，不能取得令牌。 HTTP/业务码依9.1分列；非本例目标对象、凭据与授权关系不得附带变化。 |
| 清理/重跑 | 保存脱敏证据，按ID映射只清理本例生成对象并恢复初始字段/版本；关系先子后父；不清共享审计；步骤见9.5 |
| 实际执行 | 阻断；实际结果/环境/构建版本/执行人/时间/证据均无；拟证据目录 validation/business/TC-02-005/ |

#### TC-03-001：直接静态授权正例

| 项目 | 执行定义 |
| --- | --- |
| 关联与角色 | AC-03；US-09、US-11 / BR-03、BR-04；API-08、API-11 / 用户授权组合；角色 TD-02.roles.administrator |
| 前置条件 | 完成9.1通用前提；关闭 Q-03、Q-04、Q-15；每个子场景独立还原，不能沿用上一子场景的修改 |
| 具体数据 | TD-01、TD-02；app=501；account=101；operation=202；permission_group_account=411 |
| 操作步骤 | 验证 dev-001 控制权限并追踪委托查询次数 |
| 预期结果与禁止副作用 | 返回 STATIC 与 SELF 范围；不查询委托；业务写入还需执行行过滤。 HTTP/业务码依9.1分列；非本例目标对象、凭据与授权关系不得附带变化。 |
| 清理/重跑 | 保存脱敏证据，按ID映射只清理本例生成对象并恢复初始字段/版本；关系先子后父；不清共享审计；步骤见9.5 |
| 实际执行 | 阻断；实际结果/环境/构建版本/执行人/时间/证据均无；拟证据目录 validation/business/TC-03-001/ |

#### TC-03-002：应用操作上限拒绝

| 项目 | 执行定义 |
| --- | --- |
| 关联与角色 | AC-03；US-09、US-11 / BR-03、BR-04；API-08、API-11 / 用户授权组合；角色 TD-02.roles.administrator |
| 前置条件 | 完成9.1通用前提；关闭 Q-03、Q-04、Q-15；每个子场景独立还原，不能沿用上一子场景的修改 |
| 具体数据 | TD-01、TD-02；app=502 仅含 202；account=101；请求 operation=201 |
| 操作步骤 | 在应用上限采用交集的 Q-03 批准后验证列表操作 |
| 预期结果与禁止副作用 | 不因为用户具有 201 而突破应用上限；拒绝且无业务效果。 HTTP/业务码依9.1分列；非本例目标对象、凭据与授权关系不得附带变化。 |
| 清理/重跑 | 保存脱敏证据，按ID映射只清理本例生成对象并恢复初始字段/版本；关系先子后父；不清共享审计；步骤见9.5 |
| 实际执行 | 阻断；实际结果/环境/构建版本/执行人/时间/证据均无；拟证据目录 validation/business/TC-03-002/ |

#### TC-03-003：移除静态授权后不能缓存旧许可

| 项目 | 执行定义 |
| --- | --- |
| 关联与角色 | AC-03；US-09、US-11 / BR-03、BR-04；API-08、API-11 / 用户授权组合；角色 TD-02.roles.delegatedUser |
| 前置条件 | 完成9.1通用前提；关闭 Q-03、Q-04、Q-15；每个子场景独立还原，不能沿用上一子场景的修改 |
| 具体数据 | TD-01、TD-02；account=103 无直接/组织许可；group=402 空操作；禁用该例委托601 |
| 操作步骤 | 验证 operation=202；对照新增 group403/account103 关联后重查 |
| 预期结果与禁止副作用 | 无授权组拒绝；添加批准的直接关联后仅按当前应用上限得到 STATIC；无组不等于所有操作。 HTTP/业务码依9.1分列；非本例目标对象、凭据与授权关系不得附带变化。 |
| 清理/重跑 | 保存脱敏证据，按ID映射只清理本例生成对象并恢复初始字段/版本；关系先子后父；不清共享审计；步骤见9.5 |
| 实际执行 | 阻断；实际结果/环境/构建版本/执行人/时间/证据均无；拟证据目录 validation/business/TC-03-003/ |

#### TC-04-001：所属与下级继承策略对照

| 项目 | 执行定义 |
| --- | --- |
| 关联与角色 | AC-04；US-02、US-10 / BR-03、BR-09；API-02、API-09、API-15 / DB-04、DB-07；角色 TD-02.roles.staticUser |
| 前置条件 | 完成9.1通用前提；关闭 Q-02、Q-03、Q-15；每个子场景独立还原，不能沿用上一子场景的修改 |
| 具体数据 | TD-01、TD-02；account102→org11；授权org11；再改归属org12；account103→org21 同名不同树 |
| 操作步骤 | 分别验证 102/103；在 Q-02 精确归属/后代规则定稿后记录各组预期 |
| 预期结果与禁止副作用 | org11 对应主体可继承；org21 不能因同名继承；org12 按批准的后代策略单独判定。 HTTP/业务码依9.1分列；非本例目标对象、凭据与授权关系不得附带变化。 |
| 清理/重跑 | 保存脱敏证据，按ID映射只清理本例生成对象并恢复初始字段/版本；关系先子后父；不清共享审计；步骤见9.5 |
| 实际执行 | 阻断；实际结果/环境/构建版本/执行人/时间/证据均无；拟证据目录 validation/business/TC-04-001/ |

#### TC-04-002：移除归属及成员源失效

| 项目 | 执行定义 |
| --- | --- |
| 关联与角色 | AC-04；US-02、US-10 / BR-03、BR-09；API-02、API-09、API-15 / DB-04、DB-07；角色 TD-02.roles.staticUser |
| 前置条件 | 完成9.1通用前提；关闭 Q-02、Q-03、Q-15；每个子场景独立还原，不能沿用上一子场景的修改 |
| 具体数据 | TD-01、TD-02、TD-09；删除测试上下文中的 account102/org11；另组注入 permission-source-timeout |
| 操作步骤 | 重新请求 DEPT 范围与继承操作；检查无归属与依赖故障区别 |
| 预期结果与禁止副作用 | 无法确定组织集合时不返回全量范围、不使用不确定旧许可；诊断与无归属业务策略分别记录。 HTTP/业务码依9.1分列；非本例目标对象、凭据与授权关系不得附带变化。 |
| 清理/重跑 | 保存脱敏证据，按ID映射只清理本例生成对象并恢复初始字段/版本；关系先子后父；不清共享审计；步骤见9.5 |
| 实际执行 | 阻断；实际结果/环境/构建版本/执行人/时间/证据均无；拟证据目录 validation/business/TC-04-002/ |

#### TC-05-001：SELF 列表、计数及写入

| 项目 | 执行定义 |
| --- | --- |
| 关联与角色 | AC-05；US-11 / BR-04、BR-05；API-11 / 数据范围和资源映射；角色 TD-02.roles.staticUser |
| 前置条件 | 完成9.1通用前提；关闭 Q-02、Q-04、Q-15；每个子场景独立还原，不能沿用上一子场景的修改 |
| 具体数据 | TD-01、TD-02、TD-03；account=102；app501 的数据范围改为 SELF；SPECIFIED 时组织=[21]；资源为4条基线 |
| 操作步骤 | 1. 在独立快照设置范围并核对静态许可。2. 分别查询列表和计数。3. 对每条 dev-001～004 提交控制请求并核对副作用。 |
| 预期结果与禁止副作用 | 仅 dev-001；dev-002/003/004 不属于账号102创建；列表/计数/单资源写入范围一致；超范围不修改；按钮操作许可不随行范围变动。 HTTP/业务码依9.1分列；非本例目标对象、凭据与授权关系不得附带变化。 |
| 清理/重跑 | 保存脱敏证据，按ID映射只清理本例生成对象并恢复初始字段/版本；关系先子后父；不清共享审计；步骤见9.5 |
| 实际执行 | 阻断；实际结果/环境/构建版本/执行人/时间/证据均无；拟证据目录 validation/business/TC-05-001/ |

#### TC-05-002：DEPT 列表、计数及写入

| 项目 | 执行定义 |
| --- | --- |
| 关联与角色 | AC-05；US-11 / BR-04、BR-05；API-11 / 数据范围和资源映射；角色 TD-02.roles.staticUser |
| 前置条件 | 完成9.1通用前提；关闭 Q-02、Q-04、Q-15；每个子场景独立还原，不能沿用上一子场景的修改 |
| 具体数据 | TD-01、TD-02、TD-03；account=102；app501 的数据范围改为 DEPT；SPECIFIED 时组织=[21]；资源为4条基线 |
| 操作步骤 | 1. 在独立快照设置范围并核对静态许可。2. 分别查询列表和计数。3. 对每条 dev-001～004 提交控制请求并核对副作用。 |
| 预期结果与禁止副作用 | 精确部门时 dev-001/002；若批准含后代则再含 dev-003；dev-004 始终不在该部门集合；列表/计数/单资源写入范围一致；超范围不修改；按钮操作许可不随行范围变动。 HTTP/业务码依9.1分列；非本例目标对象、凭据与授权关系不得附带变化。 |
| 清理/重跑 | 保存脱敏证据，按ID映射只清理本例生成对象并恢复初始字段/版本；关系先子后父；不清共享审计；步骤见9.5 |
| 实际执行 | 阻断；实际结果/环境/构建版本/执行人/时间/证据均无；拟证据目录 validation/business/TC-05-002/ |

#### TC-05-003：SPECIFIED 列表、计数及写入

| 项目 | 执行定义 |
| --- | --- |
| 关联与角色 | AC-05；US-11 / BR-04、BR-05；API-11 / 数据范围和资源映射；角色 TD-02.roles.staticUser |
| 前置条件 | 完成9.1通用前提；关闭 Q-02、Q-04、Q-15；每个子场景独立还原，不能沿用上一子场景的修改 |
| 具体数据 | TD-01、TD-02、TD-03；account=102；app501 的数据范围改为 SPECIFIED；SPECIFIED 时组织=[21]；资源为4条基线 |
| 操作步骤 | 1. 在独立快照设置范围并核对静态许可。2. 分别查询列表和计数。3. 对每条 dev-001～004 提交控制请求并核对副作用。 |
| 预期结果与禁止副作用 | 指定 [21] 时仅 dev-004；列表/计数/单资源写入范围一致；超范围不修改；按钮操作许可不随行范围变动。 HTTP/业务码依9.1分列；非本例目标对象、凭据与授权关系不得附带变化。 |
| 清理/重跑 | 保存脱敏证据，按ID映射只清理本例生成对象并恢复初始字段/版本；关系先子后父；不清共享审计；步骤见9.5 |
| 实际执行 | 阻断；实际结果/环境/构建版本/执行人/时间/证据均无；拟证据目录 validation/business/TC-05-003/ |

#### TC-05-004：空/未知指定组织拒绝扩权

| 项目 | 执行定义 |
| --- | --- |
| 关联与角色 | AC-05；US-11 / BR-04、BR-05；API-11 / 数据范围和资源映射；角色 TD-02.roles.staticUser |
| 前置条件 | 完成9.1通用前提；关闭 Q-02、Q-04、Q-15；每个子场景独立还原，不能沿用上一子场景的修改 |
| 具体数据 | TD-01、TD-03、TD-05；SPECIFIED；specifiedOrgIds 分别 []、null、[999999] |
| 操作步骤 | 分别保存配置并在获准可构造存量脏数据的隔离环境验证 |
| 预期结果与禁止副作用 | 配置拒绝或空范围的最终行为按 Q-04；三组均不返回无限制集合、不修改资源。 HTTP/业务码依9.1分列；非本例目标对象、凭据与授权关系不得附带变化。 |
| 清理/重跑 | 保存脱敏证据，按ID映射只清理本例生成对象并恢复初始字段/版本；关系先子后父；不清共享审计；步骤见9.5 |
| 实际执行 | 阻断；实际结果/环境/构建版本/执行人/时间/证据均无；拟证据目录 validation/business/TC-05-004/ |

#### TC-06-001：五条件全部匹配

| 项目 | 执行定义 |
| --- | --- |
| 关联与角色 | AC-06；US-11、US-12 / BR-04、BR-06；API-11、API-12 / 委托资源与时间；角色 TD-02.roles.delegatedUser |
| 前置条件 | 完成9.1通用前提；关闭 Q-03、Q-04、Q-07、Q-11、Q-15；每个子场景独立还原，不能沿用上一子场景的修改 |
| 具体数据 | TD-01、TD-02、TD-03、TD-06；app501；account103；operation202；device/dev-001；委托601 active；now=00:30Z；无静态许可 |
| 操作步骤 | 执行 API-11[验证应用授权]，随后业务服务核对许可资源并执行一次操作 |
| 预期结果与禁止副作用 | 命中 DELEGATION，范围只含 dev-001；授权允许不等于业务执行成功，分阶段记录。 HTTP/业务码依9.1分列；非本例目标对象、凭据与授权关系不得附带变化。 |
| 清理/重跑 | 保存脱敏证据，按ID映射只清理本例生成对象并恢复初始字段/版本；关系先子后父；不清共享审计；步骤见9.5 |
| 实际执行 | 阻断；实际结果/环境/构建版本/执行人/时间/证据均无；拟证据目录 validation/business/TC-06-001/ |

#### TC-06-002：被授权人不匹配

| 项目 | 执行定义 |
| --- | --- |
| 关联与角色 | AC-06；US-11、US-12 / BR-04、BR-06；API-11、API-12 / 委托资源与时间；角色 TD-02.roles.delegatedUser |
| 前置条件 | 完成9.1通用前提；关闭 Q-03、Q-04、Q-07、Q-11、Q-15；每个子场景独立还原，不能沿用上一子场景的修改 |
| 具体数据 | TD-01、TD-02、TD-03、TD-06；grantee 从103改102；请求主体仍103；其余条件与 TC-06-001 完全相同 |
| 操作步骤 | 每组重新装载基线，只破坏所列一个条件，再执行校验 |
| 预期结果与禁止副作用 | HTTP 403；不能由其他条件抵消；不产生资源写入。 HTTP/业务码依9.1分列；非本例目标对象、凭据与授权关系不得附带变化。 |
| 清理/重跑 | 保存脱敏证据，按ID映射只清理本例生成对象并恢复初始字段/版本；关系先子后父；不清共享审计；步骤见9.5 |
| 实际执行 | 阻断；实际结果/环境/构建版本/执行人/时间/证据均无；拟证据目录 validation/business/TC-06-002/ |

#### TC-06-003：权限组不含操作

| 项目 | 执行定义 |
| --- | --- |
| 关联与角色 | AC-06；US-11、US-12 / BR-04、BR-06；API-11、API-12 / 委托资源与时间；角色 TD-02.roles.delegatedUser |
| 前置条件 | 完成9.1通用前提；关闭 Q-03、Q-04、Q-07、Q-11、Q-15；每个子场景独立还原，不能沿用上一子场景的修改 |
| 具体数据 | TD-01、TD-02、TD-03、TD-06；permission_group_id 从403改402；operation仍202；其余条件与 TC-06-001 完全相同 |
| 操作步骤 | 每组重新装载基线，只破坏所列一个条件，再执行校验 |
| 预期结果与禁止副作用 | HTTP 403；不能由其他条件抵消；不产生资源写入。 HTTP/业务码依9.1分列；非本例目标对象、凭据与授权关系不得附带变化。 |
| 清理/重跑 | 保存脱敏证据，按ID映射只清理本例生成对象并恢复初始字段/版本；关系先子后父；不清共享审计；步骤见9.5 |
| 实际执行 | 阻断；实际结果/环境/构建版本/执行人/时间/证据均无；拟证据目录 validation/business/TC-06-003/ |

#### TC-06-004：资源类型不匹配

| 项目 | 执行定义 |
| --- | --- |
| 关联与角色 | AC-06；US-11、US-12 / BR-04、BR-06；API-11、API-12 / 委托资源与时间；角色 TD-02.roles.delegatedUser |
| 前置条件 | 完成9.1通用前提；关闭 Q-03、Q-04、Q-07、Q-11、Q-15；每个子场景独立还原，不能沿用上一子场景的修改 |
| 具体数据 | TD-01、TD-02、TD-03、TD-06；请求 resourceType=alarm；委托仍device；其余条件与 TC-06-001 完全相同 |
| 操作步骤 | 每组重新装载基线，只破坏所列一个条件，再执行校验 |
| 预期结果与禁止副作用 | HTTP 403；不能由其他条件抵消；不产生资源写入。 HTTP/业务码依9.1分列；非本例目标对象、凭据与授权关系不得附带变化。 |
| 清理/重跑 | 保存脱敏证据，按ID映射只清理本例生成对象并恢复初始字段/版本；关系先子后父；不清共享审计；步骤见9.5 |
| 实际执行 | 阻断；实际结果/环境/构建版本/执行人/时间/证据均无；拟证据目录 validation/business/TC-06-004/ |

#### TC-06-005：资源ID不匹配

| 项目 | 执行定义 |
| --- | --- |
| 关联与角色 | AC-06；US-11、US-12 / BR-04、BR-06；API-11、API-12 / 委托资源与时间；角色 TD-02.roles.delegatedUser |
| 前置条件 | 完成9.1通用前提；关闭 Q-03、Q-04、Q-07、Q-11、Q-15；每个子场景独立还原，不能沿用上一子场景的修改 |
| 具体数据 | TD-01、TD-02、TD-03、TD-06；请求 resourceId=dev-002；委托只含dev-001；其余条件与 TC-06-001 完全相同 |
| 操作步骤 | 每组重新装载基线，只破坏所列一个条件，再执行校验 |
| 预期结果与禁止副作用 | HTTP 403；不能由其他条件抵消；不产生资源写入。 HTTP/业务码依9.1分列；非本例目标对象、凭据与授权关系不得附带变化。 |
| 清理/重跑 | 保存脱敏证据，按ID映射只清理本例生成对象并恢复初始字段/版本；关系先子后父；不清共享审计；步骤见9.5 |
| 实际执行 | 阻断；实际结果/环境/构建版本/执行人/时间/证据均无；拟证据目录 validation/business/TC-06-005/ |

#### TC-06-006：尚未开始

| 项目 | 执行定义 |
| --- | --- |
| 关联与角色 | AC-06；US-11、US-12 / BR-04、BR-06；API-11、API-12 / 委托资源与时间；角色 TD-02.roles.delegatedUser |
| 前置条件 | 完成9.1通用前提；关闭 Q-03、Q-04、Q-07、Q-11、Q-15；每个子场景独立还原，不能沿用上一子场景的修改 |
| 具体数据 | TD-01、TD-02、TD-03、TD-06；now=TD-06.beforeFrom；其余条件与 TC-06-001 完全相同 |
| 操作步骤 | 每组重新装载基线，只破坏所列一个条件，再执行校验 |
| 预期结果与禁止副作用 | HTTP 403；不能由其他条件抵消；不产生资源写入。 HTTP/业务码依9.1分列；非本例目标对象、凭据与授权关系不得附带变化。 |
| 清理/重跑 | 保存脱敏证据，按ID映射只清理本例生成对象并恢复初始字段/版本；关系先子后父；不清共享审计；步骤见9.5 |
| 实际执行 | 阻断；实际结果/环境/构建版本/执行人/时间/证据均无；拟证据目录 validation/business/TC-06-006/ |

#### TC-06-007：超过结束

| 项目 | 执行定义 |
| --- | --- |
| 关联与角色 | AC-06；US-11、US-12 / BR-04、BR-06；API-11、API-12 / 委托资源与时间；角色 TD-02.roles.delegatedUser |
| 前置条件 | 完成9.1通用前提；关闭 Q-03、Q-04、Q-07、Q-11、Q-15；每个子场景独立还原，不能沿用上一子场景的修改 |
| 具体数据 | TD-01、TD-02、TD-03、TD-06；now=TD-06.afterUntil；其余条件与 TC-06-001 完全相同 |
| 操作步骤 | 每组重新装载基线，只破坏所列一个条件，再执行校验 |
| 预期结果与禁止副作用 | HTTP 403；不能由其他条件抵消；不产生资源写入。 HTTP/业务码依9.1分列；非本例目标对象、凭据与授权关系不得附带变化。 |
| 清理/重跑 | 保存脱敏证据，按ID映射只清理本例生成对象并恢复初始字段/版本；关系先子后父；不清共享审计；步骤见9.5 |
| 实际执行 | 阻断；实际结果/环境/构建版本/执行人/时间/证据均无；拟证据目录 validation/business/TC-06-007/ |

#### TC-07-001：未批准委托

| 项目 | 执行定义 |
| --- | --- |
| 关联与角色 | AC-07；US-12 / BR-07、BR-18；API-11、API-16 / DB-09；角色 TD-02.roles.delegatedUser |
| 前置条件 | 完成9.1通用前提；关闭 Q-07、Q-08、Q-15；每个子场景独立还原，不能沿用上一子场景的修改 |
| 具体数据 | TD-01、TD-02、TD-06；601.status=pending |
| 操作步骤 | 按 Q-07 批准策略发起委托处理或资源鉴权并比对前后状态 |
| 预期结果与禁止副作用 | 不得通过未生效/越权来源获得许可；自批禁止方案批准后应拒绝且状态不变；不能伪造已批准。 HTTP/业务码依9.1分列；非本例目标对象、凭据与授权关系不得附带变化。 |
| 清理/重跑 | 保存脱敏证据，按ID映射只清理本例生成对象并恢复初始字段/版本；关系先子后父；不清共享审计；步骤见9.5 |
| 实际执行 | 阻断；实际结果/环境/构建版本/执行人/时间/证据均无；拟证据目录 validation/business/TC-07-001/ |

#### TC-07-002：撤销委托

| 项目 | 执行定义 |
| --- | --- |
| 关联与角色 | AC-07；US-12 / BR-07、BR-18；API-11、API-16 / DB-09；角色 TD-02.roles.delegatedUser |
| 前置条件 | 完成9.1通用前提；关闭 Q-07、Q-08、Q-15；每个子场景独立还原，不能沿用上一子场景的修改 |
| 具体数据 | TD-01、TD-02、TD-06；601.status=revoked |
| 操作步骤 | 按 Q-07 批准策略发起委托处理或资源鉴权并比对前后状态 |
| 预期结果与禁止副作用 | 不得通过未生效/越权来源获得许可；自批禁止方案批准后应拒绝且状态不变；不能伪造已批准。 HTTP/业务码依9.1分列；非本例目标对象、凭据与授权关系不得附带变化。 |
| 清理/重跑 | 保存脱敏证据，按ID映射只清理本例生成对象并恢复初始字段/版本；关系先子后父；不清共享审计；步骤见9.5 |
| 实际执行 | 阻断；实际结果/环境/构建版本/执行人/时间/证据均无；拟证据目录 validation/business/TC-07-002/ |

#### TC-07-003：过期委托

| 项目 | 执行定义 |
| --- | --- |
| 关联与角色 | AC-07；US-12 / BR-07、BR-18；API-11、API-16 / DB-09；角色 TD-02.roles.delegatedUser |
| 前置条件 | 完成9.1通用前提；关闭 Q-07、Q-08、Q-15；每个子场景独立还原，不能沿用上一子场景的修改 |
| 具体数据 | TD-01、TD-02、TD-06；601.status=expired；now=afterUntil |
| 操作步骤 | 按 Q-07 批准策略发起委托处理或资源鉴权并比对前后状态 |
| 预期结果与禁止副作用 | 不得通过未生效/越权来源获得许可；自批禁止方案批准后应拒绝且状态不变；不能伪造已批准。 HTTP/业务码依9.1分列；非本例目标对象、凭据与授权关系不得附带变化。 |
| 清理/重跑 | 保存脱敏证据，按ID映射只清理本例生成对象并恢复初始字段/版本；关系先子后父；不清共享审计；步骤见9.5 |
| 实际执行 | 阻断；实际结果/环境/构建版本/执行人/时间/证据均无；拟证据目录 validation/business/TC-07-003/ |

#### TC-07-004：跨应用委托

| 项目 | 执行定义 |
| --- | --- |
| 关联与角色 | AC-07；US-12 / BR-07、BR-18；API-11、API-16 / DB-09；角色 TD-02.roles.delegatedUser |
| 前置条件 | 完成9.1通用前提；关闭 Q-07、Q-08、Q-15；每个子场景独立还原，不能沿用上一子场景的修改 |
| 具体数据 | TD-01、TD-02、TD-06；TD-02.delegationApp[601]=502；请求app501 |
| 操作步骤 | 按 Q-07 批准策略发起委托处理或资源鉴权并比对前后状态 |
| 预期结果与禁止副作用 | 不得通过未生效/越权来源获得许可；自批禁止方案批准后应拒绝且状态不变；不能伪造已批准。 HTTP/业务码依9.1分列；非本例目标对象、凭据与授权关系不得附带变化。 |
| 清理/重跑 | 保存脱敏证据，按ID映射只清理本例生成对象并恢复初始字段/版本；关系先子后父；不清共享审计；步骤见9.5 |
| 实际执行 | 阻断；实际结果/环境/构建版本/执行人/时间/证据均无；拟证据目录 validation/business/TC-07-004/ |

#### TC-07-005：越权授予人

| 项目 | 执行定义 |
| --- | --- |
| 关联与角色 | AC-07；US-12 / BR-07、BR-18；API-11、API-16 / DB-09；角色 TD-02.roles.delegatedUser |
| 前置条件 | 完成9.1通用前提；关闭 Q-07、Q-08、Q-15；每个子场景独立还原，不能沿用上一子场景的修改 |
| 具体数据 | TD-01、TD-02、TD-06；grantor=103 且没有可授出操作/资源 |
| 操作步骤 | 按 Q-07 批准策略发起委托处理或资源鉴权并比对前后状态 |
| 预期结果与禁止副作用 | 不得通过未生效/越权来源获得许可；自批禁止方案批准后应拒绝且状态不变；不能伪造已批准。 HTTP/业务码依9.1分列；非本例目标对象、凭据与授权关系不得附带变化。 |
| 清理/重跑 | 保存脱敏证据，按ID映射只清理本例生成对象并恢复初始字段/版本；关系先子后父；不清共享审计；步骤见9.5 |
| 实际执行 | 阻断；实际结果/环境/构建版本/执行人/时间/证据均无；拟证据目录 validation/business/TC-07-005/ |

#### TC-07-006：申请人自批

| 项目 | 执行定义 |
| --- | --- |
| 关联与角色 | AC-07；US-12 / BR-07、BR-18；API-11、API-16 / DB-09；角色 TD-02.roles.delegatedUser |
| 前置条件 | 完成9.1通用前提；关闭 Q-07、Q-08、Q-15；每个子场景独立还原，不能沿用上一子场景的修改 |
| 具体数据 | TD-01、TD-02、TD-06；申请人与处理人均103 |
| 操作步骤 | 按 Q-07 批准策略发起委托处理或资源鉴权并比对前后状态 |
| 预期结果与禁止副作用 | 不得通过未生效/越权来源获得许可；自批禁止方案批准后应拒绝且状态不变；不能伪造已批准。 HTTP/业务码依9.1分列；非本例目标对象、凭据与授权关系不得附带变化。 |
| 清理/重跑 | 保存脱敏证据，按ID映射只清理本例生成对象并恢复初始字段/版本；关系先子后父；不清共享审计；步骤见9.5 |
| 实际执行 | 阻断；实际结果/环境/构建版本/执行人/时间/证据均无；拟证据目录 validation/business/TC-07-006/ |

#### TC-08-001：静态超行范围不进入委托

| 项目 | 执行定义 |
| --- | --- |
| 关联与角色 | AC-08；US-11、US-12 / BR-04、BR-05；API-11 / 目标资源归属；角色 TD-02.roles.staticUser |
| 前置条件 | 完成9.1通用前提；关闭 Q-04、Q-15；每个子场景独立还原，不能沿用上一子场景的修改 |
| 具体数据 | TD-01、TD-02、TD-03；account102 静态有202、SELF；给102另设对dev-004的有效委托 |
| 操作步骤 | 请求控制 dev-004 并检查路径追踪及资源快照 |
| 预期结果与禁止副作用 | 拒绝该行；委托路径未用于补救，资源未修改；错误公开口径待 Q-15。 HTTP/业务码依9.1分列；非本例目标对象、凭据与授权关系不得附带变化。 |
| 清理/重跑 | 保存脱敏证据，按ID映射只清理本例生成对象并恢复初始字段/版本；关系先子后父；不清共享审计；步骤见9.5 |
| 实际执行 | 阻断；实际结果/环境/构建版本/执行人/时间/证据均无；拟证据目录 validation/business/TC-08-001/ |

#### TC-09-001：账号新增

| 项目 | 执行定义 |
| --- | --- |
| 关联与角色 | AC-09；US-01 / BR-08、BR-25、BR-26；API-01 / 账号唯一约束；角色 TD-02.roles.administrator |
| 前置条件 | 完成9.1通用前提；关闭 Q-01、Q-05、Q-10、Q-12、Q-15；每个子场景独立还原，不能沿用上一子场景的修改 |
| 具体数据 | TD-01、TD-02、TD-07；TD-01.tables.account；username=auth-prd-new；accountType=person；凭据走批准测试流程 |
| 操作步骤 | 调用 API-01[新增]，由响应记录实际生成 ID；以该 ID 复查 |
| 预期结果与禁止副作用 | 只新增一条正确记录；ID 由服务端生成，不改写已有对象。 散列、AppSecret 与令牌不进入常规输出。 HTTP/业务码依9.1分列；非本例目标对象、凭据与授权关系不得附带变化。 |
| 清理/重跑 | 保存脱敏证据，按ID映射只清理本例生成对象并恢复初始字段/版本；关系先子后父；不清共享审计；步骤见9.5 |
| 实际执行 | 阻断；实际结果/环境/构建版本/执行人/时间/证据均无；拟证据目录 validation/business/TC-09-001/ |

#### TC-09-002：账号编辑

| 项目 | 执行定义 |
| --- | --- |
| 关联与角色 | AC-09；US-01 / BR-08、BR-25、BR-26；API-01 / 账号唯一约束；角色 TD-02.roles.administrator |
| 前置条件 | 完成9.1通用前提；关闭 Q-01、Q-05、Q-10、Q-12、Q-15；每个子场景独立还原，不能沿用上一子场景的修改 |
| 具体数据 | TD-01、TD-02、TD-07；TD-01.tables.account；remark=修改备注 |
| 操作步骤 | 准备本例无引用新对象并读取版本，调用 API-01[编辑]，重新读取 |
| 预期结果与禁止副作用 | 仅允许字段变化；版本按批准机制变化；未提交字段不被意外清空。 散列、AppSecret 与令牌不进入常规输出。 HTTP/业务码依9.1分列；非本例目标对象、凭据与授权关系不得附带变化。 |
| 清理/重跑 | 保存脱敏证据，按ID映射只清理本例生成对象并恢复初始字段/版本；关系先子后父；不清共享审计；步骤见9.5 |
| 实际执行 | 阻断；实际结果/环境/构建版本/执行人/时间/证据均无；拟证据目录 validation/business/TC-09-002/ |

#### TC-09-003：账号详情

| 项目 | 执行定义 |
| --- | --- |
| 关联与角色 | AC-09；US-01 / BR-08、BR-25、BR-26；API-01 / 账号唯一约束；角色 TD-02.roles.administrator |
| 前置条件 | 完成9.1通用前提；关闭 Q-01、Q-05、Q-10、Q-12、Q-15；每个子场景独立还原，不能沿用上一子场景的修改 |
| 具体数据 | TD-01、TD-02、TD-07；TD-01.tables.account；按本例新对象实际 ID 定位；另以未授权管理员/对象做对照 |
| 操作步骤 | 调用 API-01[详情]，比较允许字段与持久值 |
| 预期结果与禁止副作用 | 授权主体可读正确字段；越权拒绝且不泄露对象；读取不写数据。 散列、AppSecret 与令牌不进入常规输出。 HTTP/业务码依9.1分列；非本例目标对象、凭据与授权关系不得附带变化。 |
| 清理/重跑 | 保存脱敏证据，按ID映射只清理本例生成对象并恢复初始字段/版本；关系先子后父；不清共享审计；步骤见9.5 |
| 实际执行 | 阻断；实际结果/环境/构建版本/执行人/时间/证据均无；拟证据目录 validation/business/TC-09-003/ |

#### TC-09-004：账号列表

| 项目 | 执行定义 |
| --- | --- |
| 关联与角色 | AC-09；US-01 / BR-08、BR-25、BR-26；API-01 / 账号唯一约束；角色 TD-02.roles.administrator |
| 前置条件 | 完成9.1通用前提；关闭 Q-01、Q-05、Q-10、Q-12、Q-15；每个子场景独立还原，不能沿用上一子场景的修改 |
| 具体数据 | TD-01、TD-02、TD-07；TD-01.tables.account；使用本例编码/名称筛选；空匹配值=auth-prd-no-match |
| 操作步骤 | 调用 API-01[列表]并遍历分页；再查询空匹配 |
| 预期结果与禁止副作用 | 范围内可查询且无越权记录；空集合与分页口径一致；不写数据。 散列、AppSecret 与令牌不进入常规输出。 HTTP/业务码依9.1分列；非本例目标对象、凭据与授权关系不得附带变化。 |
| 清理/重跑 | 保存脱敏证据，按ID映射只清理本例生成对象并恢复初始字段/版本；关系先子后父；不清共享审计；步骤见9.5 |
| 实际执行 | 阻断；实际结果/环境/构建版本/执行人/时间/证据均无；拟证据目录 validation/business/TC-09-004/ |

#### TC-09-005：账号删除

| 项目 | 执行定义 |
| --- | --- |
| 关联与角色 | AC-09；US-01 / BR-08、BR-25、BR-26；API-01 / 账号唯一约束；角色 TD-02.roles.administrator |
| 前置条件 | 完成9.1通用前提；关闭 Q-01、Q-05、Q-10、Q-12、Q-15；每个子场景独立还原，不能沿用上一子场景的修改 |
| 具体数据 | TD-01、TD-02、TD-07；TD-01.tables.account；本例单独创建且无引用的对象；删除语义须先批准Q-10 |
| 操作步骤 | 调用 API-01[删除]，检查实体与关联及审计；再次读取 |
| 预期结果与禁止副作用 | 仅按批准硬删除/软删除/停用方案处理目标；不意外级联其他对象；读取结果符合删除策略。 散列、AppSecret 与令牌不进入常规输出。 HTTP/业务码依9.1分列；非本例目标对象、凭据与授权关系不得附带变化。 |
| 清理/重跑 | 保存脱敏证据，按ID映射只清理本例生成对象并恢复初始字段/版本；关系先子后父；不清共享审计；步骤见9.5 |
| 实际执行 | 阻断；实际结果/环境/构建版本/执行人/时间/证据均无；拟证据目录 validation/business/TC-09-005/ |

#### TC-10-001：组织新增

| 项目 | 执行定义 |
| --- | --- |
| 关联与角色 | AC-10；US-02 / BR-09、BR-27；API-02 / 组织树与版本；角色 TD-02.roles.administrator |
| 前置条件 | 完成9.1通用前提；关闭 Q-02、Q-12、Q-15；每个子场景独立还原，不能沿用上一子场景的修改 |
| 具体数据 | TD-01、TD-02、TD-07；TD-01.tables.organization；parentId=11；orgName=测试岗位；orgType=post |
| 操作步骤 | 调用 API-02[新增]，由响应记录实际生成 ID；以该 ID 复查 |
| 预期结果与禁止副作用 | 只新增一条正确记录；ID 由服务端生成，不改写已有对象。 散列、AppSecret 与令牌不进入常规输出。 HTTP/业务码依9.1分列；非本例目标对象、凭据与授权关系不得附带变化。 |
| 清理/重跑 | 保存脱敏证据，按ID映射只清理本例生成对象并恢复初始字段/版本；关系先子后父；不清共享审计；步骤见9.5 |
| 实际执行 | 阻断；实际结果/环境/构建版本/执行人/时间/证据均无；拟证据目录 validation/business/TC-10-001/ |

#### TC-10-002：组织编辑

| 项目 | 执行定义 |
| --- | --- |
| 关联与角色 | AC-10；US-02 / BR-09、BR-27；API-02 / 组织树与版本；角色 TD-02.roles.administrator |
| 前置条件 | 完成9.1通用前提；关闭 Q-02、Q-12、Q-15；每个子场景独立还原，不能沿用上一子场景的修改 |
| 具体数据 | TD-01、TD-02、TD-07；TD-01.tables.organization；orgName=调整后的岗位 |
| 操作步骤 | 准备本例无引用新对象并读取版本，调用 API-02[编辑]，重新读取 |
| 预期结果与禁止副作用 | 仅允许字段变化；版本按批准机制变化；未提交字段不被意外清空。 散列、AppSecret 与令牌不进入常规输出。 HTTP/业务码依9.1分列；非本例目标对象、凭据与授权关系不得附带变化。 |
| 清理/重跑 | 保存脱敏证据，按ID映射只清理本例生成对象并恢复初始字段/版本；关系先子后父；不清共享审计；步骤见9.5 |
| 实际执行 | 阻断；实际结果/环境/构建版本/执行人/时间/证据均无；拟证据目录 validation/business/TC-10-002/ |

#### TC-10-003：组织详情

| 项目 | 执行定义 |
| --- | --- |
| 关联与角色 | AC-10；US-02 / BR-09、BR-27；API-02 / 组织树与版本；角色 TD-02.roles.administrator |
| 前置条件 | 完成9.1通用前提；关闭 Q-02、Q-12、Q-15；每个子场景独立还原，不能沿用上一子场景的修改 |
| 具体数据 | TD-01、TD-02、TD-07；TD-01.tables.organization；按本例新对象实际 ID 定位；另以未授权管理员/对象做对照 |
| 操作步骤 | 调用 API-02[详情]，比较允许字段与持久值 |
| 预期结果与禁止副作用 | 授权主体可读正确字段；越权拒绝且不泄露对象；读取不写数据。 散列、AppSecret 与令牌不进入常规输出。 HTTP/业务码依9.1分列；非本例目标对象、凭据与授权关系不得附带变化。 |
| 清理/重跑 | 保存脱敏证据，按ID映射只清理本例生成对象并恢复初始字段/版本；关系先子后父；不清共享审计；步骤见9.5 |
| 实际执行 | 阻断；实际结果/环境/构建版本/执行人/时间/证据均无；拟证据目录 validation/business/TC-10-003/ |

#### TC-10-004：组织列表

| 项目 | 执行定义 |
| --- | --- |
| 关联与角色 | AC-10；US-02 / BR-09、BR-27；API-02 / 组织树与版本；角色 TD-02.roles.administrator |
| 前置条件 | 完成9.1通用前提；关闭 Q-02、Q-12、Q-15；每个子场景独立还原，不能沿用上一子场景的修改 |
| 具体数据 | TD-01、TD-02、TD-07；TD-01.tables.organization；使用本例编码/名称筛选；空匹配值=auth-prd-no-match |
| 操作步骤 | 调用 API-02[列表]并遍历分页；再查询空匹配 |
| 预期结果与禁止副作用 | 范围内可查询且无越权记录；空集合与分页口径一致；不写数据。 散列、AppSecret 与令牌不进入常规输出。 HTTP/业务码依9.1分列；非本例目标对象、凭据与授权关系不得附带变化。 |
| 清理/重跑 | 保存脱敏证据，按ID映射只清理本例生成对象并恢复初始字段/版本；关系先子后父；不清共享审计；步骤见9.5 |
| 实际执行 | 阻断；实际结果/环境/构建版本/执行人/时间/证据均无；拟证据目录 validation/business/TC-10-004/ |

#### TC-10-005：组织删除

| 项目 | 执行定义 |
| --- | --- |
| 关联与角色 | AC-10；US-02 / BR-09、BR-27；API-02 / 组织树与版本；角色 TD-02.roles.administrator |
| 前置条件 | 完成9.1通用前提；关闭 Q-02、Q-12、Q-15；每个子场景独立还原，不能沿用上一子场景的修改 |
| 具体数据 | TD-01、TD-02、TD-07；TD-01.tables.organization；本例单独创建且无引用的对象；删除语义须先批准Q-10 |
| 操作步骤 | 调用 API-02[删除]，检查实体与关联及审计；再次读取 |
| 预期结果与禁止副作用 | 仅按批准硬删除/软删除/停用方案处理目标；不意外级联其他对象；读取结果符合删除策略。 散列、AppSecret 与令牌不进入常规输出。 HTTP/业务码依9.1分列；非本例目标对象、凭据与授权关系不得附带变化。 |
| 清理/重跑 | 保存脱敏证据，按ID映射只清理本例生成对象并恢复初始字段/版本；关系先子后父；不清共享审计；步骤见9.5 |
| 实际执行 | 阻断；实际结果/环境/构建版本/执行人/时间/证据均无；拟证据目录 validation/business/TC-10-005/ |

#### TC-11-001：用户组新增

| 项目 | 执行定义 |
| --- | --- |
| 关联与角色 | AC-11；US-03 / BR-10、BR-12；API-03、API-15 / 成员组合唯一；角色 TD-02.roles.administrator |
| 前置条件 | 完成9.1通用前提；关闭 Q-02、Q-10、Q-12、Q-15；每个子场景独立还原，不能沿用上一子场景的修改 |
| 具体数据 | TD-01、TD-02、TD-07；TD-01.tables.user_group；groupCode=auth-prd-new-group；groupName=新用户组 |
| 操作步骤 | 调用 API-03[新增]，由响应记录实际生成 ID；以该 ID 复查 |
| 预期结果与禁止副作用 | 只新增一条正确记录；ID 由服务端生成，不改写已有对象。 散列、AppSecret 与令牌不进入常规输出。 HTTP/业务码依9.1分列；非本例目标对象、凭据与授权关系不得附带变化。 |
| 清理/重跑 | 保存脱敏证据，按ID映射只清理本例生成对象并恢复初始字段/版本；关系先子后父；不清共享审计；步骤见9.5 |
| 实际执行 | 阻断；实际结果/环境/构建版本/执行人/时间/证据均无；拟证据目录 validation/business/TC-11-001/ |

#### TC-11-002：用户组编辑

| 项目 | 执行定义 |
| --- | --- |
| 关联与角色 | AC-11；US-03 / BR-10、BR-12；API-03、API-15 / 成员组合唯一；角色 TD-02.roles.administrator |
| 前置条件 | 完成9.1通用前提；关闭 Q-02、Q-10、Q-12、Q-15；每个子场景独立还原，不能沿用上一子场景的修改 |
| 具体数据 | TD-01、TD-02、TD-07；TD-01.tables.user_group；groupName=调整后的用户组 |
| 操作步骤 | 准备本例无引用新对象并读取版本，调用 API-03[编辑]，重新读取 |
| 预期结果与禁止副作用 | 仅允许字段变化；版本按批准机制变化；未提交字段不被意外清空。 散列、AppSecret 与令牌不进入常规输出。 HTTP/业务码依9.1分列；非本例目标对象、凭据与授权关系不得附带变化。 |
| 清理/重跑 | 保存脱敏证据，按ID映射只清理本例生成对象并恢复初始字段/版本；关系先子后父；不清共享审计；步骤见9.5 |
| 实际执行 | 阻断；实际结果/环境/构建版本/执行人/时间/证据均无；拟证据目录 validation/business/TC-11-002/ |

#### TC-11-003：用户组详情

| 项目 | 执行定义 |
| --- | --- |
| 关联与角色 | AC-11；US-03 / BR-10、BR-12；API-03、API-15 / 成员组合唯一；角色 TD-02.roles.administrator |
| 前置条件 | 完成9.1通用前提；关闭 Q-02、Q-10、Q-12、Q-15；每个子场景独立还原，不能沿用上一子场景的修改 |
| 具体数据 | TD-01、TD-02、TD-07；TD-01.tables.user_group；按本例新对象实际 ID 定位；另以未授权管理员/对象做对照 |
| 操作步骤 | 调用 API-03[详情]，比较允许字段与持久值 |
| 预期结果与禁止副作用 | 授权主体可读正确字段；越权拒绝且不泄露对象；读取不写数据。 散列、AppSecret 与令牌不进入常规输出。 HTTP/业务码依9.1分列；非本例目标对象、凭据与授权关系不得附带变化。 |
| 清理/重跑 | 保存脱敏证据，按ID映射只清理本例生成对象并恢复初始字段/版本；关系先子后父；不清共享审计；步骤见9.5 |
| 实际执行 | 阻断；实际结果/环境/构建版本/执行人/时间/证据均无；拟证据目录 validation/business/TC-11-003/ |

#### TC-11-004：用户组列表

| 项目 | 执行定义 |
| --- | --- |
| 关联与角色 | AC-11；US-03 / BR-10、BR-12；API-03、API-15 / 成员组合唯一；角色 TD-02.roles.administrator |
| 前置条件 | 完成9.1通用前提；关闭 Q-02、Q-10、Q-12、Q-15；每个子场景独立还原，不能沿用上一子场景的修改 |
| 具体数据 | TD-01、TD-02、TD-07；TD-01.tables.user_group；使用本例编码/名称筛选；空匹配值=auth-prd-no-match |
| 操作步骤 | 调用 API-03[列表]并遍历分页；再查询空匹配 |
| 预期结果与禁止副作用 | 范围内可查询且无越权记录；空集合与分页口径一致；不写数据。 散列、AppSecret 与令牌不进入常规输出。 HTTP/业务码依9.1分列；非本例目标对象、凭据与授权关系不得附带变化。 |
| 清理/重跑 | 保存脱敏证据，按ID映射只清理本例生成对象并恢复初始字段/版本；关系先子后父；不清共享审计；步骤见9.5 |
| 实际执行 | 阻断；实际结果/环境/构建版本/执行人/时间/证据均无；拟证据目录 validation/business/TC-11-004/ |

#### TC-11-005：用户组删除

| 项目 | 执行定义 |
| --- | --- |
| 关联与角色 | AC-11；US-03 / BR-10、BR-12；API-03、API-15 / 成员组合唯一；角色 TD-02.roles.administrator |
| 前置条件 | 完成9.1通用前提；关闭 Q-02、Q-10、Q-12、Q-15；每个子场景独立还原，不能沿用上一子场景的修改 |
| 具体数据 | TD-01、TD-02、TD-07；TD-01.tables.user_group；本例单独创建且无引用的对象；删除语义须先批准Q-10 |
| 操作步骤 | 调用 API-03[删除]，检查实体与关联及审计；再次读取 |
| 预期结果与禁止副作用 | 仅按批准硬删除/软删除/停用方案处理目标；不意外级联其他对象；读取结果符合删除策略。 散列、AppSecret 与令牌不进入常规输出。 HTTP/业务码依9.1分列；非本例目标对象、凭据与授权关系不得附带变化。 |
| 清理/重跑 | 保存脱敏证据，按ID映射只清理本例生成对象并恢复初始字段/版本；关系先子后父；不清共享审计；步骤见9.5 |
| 实际执行 | 阻断；实际结果/环境/构建版本/执行人/时间/证据均无；拟证据目录 validation/business/TC-11-005/ |

#### TC-12-001：参数新增

| 项目 | 执行定义 |
| --- | --- |
| 关联与角色 | AC-12；US-05、US-06 / BR-08、BR-20；API-04、API-05 / 编码与 JSON；角色 TD-02.roles.administrator |
| 前置条件 | 完成9.1通用前提；关闭 Q-10、Q-14、Q-15；每个子场景独立还原，不能沿用上一子场景的修改 |
| 具体数据 | TD-01、TD-02、TD-07；TD-01.tables.sys_param；paramCode=auth-prd-new-param；paramValue=demo |
| 操作步骤 | 调用 API-04[新增]，由响应记录实际生成 ID；以该 ID 复查 |
| 预期结果与禁止副作用 | 只新增一条正确记录；ID 由服务端生成，不改写已有对象。 散列、AppSecret 与令牌不进入常规输出。 HTTP/业务码依9.1分列；非本例目标对象、凭据与授权关系不得附带变化。 |
| 清理/重跑 | 保存脱敏证据，按ID映射只清理本例生成对象并恢复初始字段/版本；关系先子后父；不清共享审计；步骤见9.5 |
| 实际执行 | 阻断；实际结果/环境/构建版本/执行人/时间/证据均无；拟证据目录 validation/business/TC-12-001/ |

#### TC-12-002：参数编辑

| 项目 | 执行定义 |
| --- | --- |
| 关联与角色 | AC-12；US-05、US-06 / BR-08、BR-20；API-04、API-05 / 编码与 JSON；角色 TD-02.roles.administrator |
| 前置条件 | 完成9.1通用前提；关闭 Q-10、Q-14、Q-15；每个子场景独立还原，不能沿用上一子场景的修改 |
| 具体数据 | TD-01、TD-02、TD-07；TD-01.tables.sys_param；paramValue=changed |
| 操作步骤 | 准备本例无引用新对象并读取版本，调用 API-04[编辑]，重新读取 |
| 预期结果与禁止副作用 | 仅允许字段变化；版本按批准机制变化；未提交字段不被意外清空。 散列、AppSecret 与令牌不进入常规输出。 HTTP/业务码依9.1分列；非本例目标对象、凭据与授权关系不得附带变化。 |
| 清理/重跑 | 保存脱敏证据，按ID映射只清理本例生成对象并恢复初始字段/版本；关系先子后父；不清共享审计；步骤见9.5 |
| 实际执行 | 阻断；实际结果/环境/构建版本/执行人/时间/证据均无；拟证据目录 validation/business/TC-12-002/ |

#### TC-12-003：参数详情

| 项目 | 执行定义 |
| --- | --- |
| 关联与角色 | AC-12；US-05、US-06 / BR-08、BR-20；API-04、API-05 / 编码与 JSON；角色 TD-02.roles.administrator |
| 前置条件 | 完成9.1通用前提；关闭 Q-10、Q-14、Q-15；每个子场景独立还原，不能沿用上一子场景的修改 |
| 具体数据 | TD-01、TD-02、TD-07；TD-01.tables.sys_param；按本例新对象实际 ID 定位；另以未授权管理员/对象做对照 |
| 操作步骤 | 调用 API-04[详情]，比较允许字段与持久值 |
| 预期结果与禁止副作用 | 授权主体可读正确字段；越权拒绝且不泄露对象；读取不写数据。 散列、AppSecret 与令牌不进入常规输出。 HTTP/业务码依9.1分列；非本例目标对象、凭据与授权关系不得附带变化。 |
| 清理/重跑 | 保存脱敏证据，按ID映射只清理本例生成对象并恢复初始字段/版本；关系先子后父；不清共享审计；步骤见9.5 |
| 实际执行 | 阻断；实际结果/环境/构建版本/执行人/时间/证据均无；拟证据目录 validation/business/TC-12-003/ |

#### TC-12-004：参数列表

| 项目 | 执行定义 |
| --- | --- |
| 关联与角色 | AC-12；US-05、US-06 / BR-08、BR-20；API-04、API-05 / 编码与 JSON；角色 TD-02.roles.administrator |
| 前置条件 | 完成9.1通用前提；关闭 Q-10、Q-14、Q-15；每个子场景独立还原，不能沿用上一子场景的修改 |
| 具体数据 | TD-01、TD-02、TD-07；TD-01.tables.sys_param；使用本例编码/名称筛选；空匹配值=auth-prd-no-match |
| 操作步骤 | 调用 API-04[列表]并遍历分页；再查询空匹配 |
| 预期结果与禁止副作用 | 范围内可查询且无越权记录；空集合与分页口径一致；不写数据。 散列、AppSecret 与令牌不进入常规输出。 HTTP/业务码依9.1分列；非本例目标对象、凭据与授权关系不得附带变化。 |
| 清理/重跑 | 保存脱敏证据，按ID映射只清理本例生成对象并恢复初始字段/版本；关系先子后父；不清共享审计；步骤见9.5 |
| 实际执行 | 阻断；实际结果/环境/构建版本/执行人/时间/证据均无；拟证据目录 validation/business/TC-12-004/ |

#### TC-12-005：参数删除

| 项目 | 执行定义 |
| --- | --- |
| 关联与角色 | AC-12；US-05、US-06 / BR-08、BR-20；API-04、API-05 / 编码与 JSON；角色 TD-02.roles.administrator |
| 前置条件 | 完成9.1通用前提；关闭 Q-10、Q-14、Q-15；每个子场景独立还原，不能沿用上一子场景的修改 |
| 具体数据 | TD-01、TD-02、TD-07；TD-01.tables.sys_param；本例单独创建且无引用的对象；删除语义须先批准Q-10 |
| 操作步骤 | 调用 API-04[删除]，检查实体与关联及审计；再次读取 |
| 预期结果与禁止副作用 | 仅按批准硬删除/软删除/停用方案处理目标；不意外级联其他对象；读取结果符合删除策略。 散列、AppSecret 与令牌不进入常规输出。 HTTP/业务码依9.1分列；非本例目标对象、凭据与授权关系不得附带变化。 |
| 清理/重跑 | 保存脱敏证据，按ID映射只清理本例生成对象并恢复初始字段/版本；关系先子后父；不清共享审计；步骤见9.5 |
| 实际执行 | 阻断；实际结果/环境/构建版本/执行人/时间/证据均无；拟证据目录 validation/business/TC-12-005/ |

#### TC-12-006：字典新增

| 项目 | 执行定义 |
| --- | --- |
| 关联与角色 | AC-12；US-05、US-06 / BR-08、BR-20；API-04、API-05 / 编码与 JSON；角色 TD-02.roles.administrator |
| 前置条件 | 完成9.1通用前提；关闭 Q-10、Q-14、Q-15；每个子场景独立还原，不能沿用上一子场景的修改 |
| 具体数据 | TD-01、TD-02、TD-07；TD-01.tables.sys_dict；dictCode=auth-prd-new-dict；dictItems=[启用,禁用] |
| 操作步骤 | 调用 API-05[新增]，由响应记录实际生成 ID；以该 ID 复查 |
| 预期结果与禁止副作用 | 只新增一条正确记录；ID 由服务端生成，不改写已有对象。 散列、AppSecret 与令牌不进入常规输出。 HTTP/业务码依9.1分列；非本例目标对象、凭据与授权关系不得附带变化。 |
| 清理/重跑 | 保存脱敏证据，按ID映射只清理本例生成对象并恢复初始字段/版本；关系先子后父；不清共享审计；步骤见9.5 |
| 实际执行 | 阻断；实际结果/环境/构建版本/执行人/时间/证据均无；拟证据目录 validation/business/TC-12-006/ |

#### TC-12-007：字典编辑

| 项目 | 执行定义 |
| --- | --- |
| 关联与角色 | AC-12；US-05、US-06 / BR-08、BR-20；API-04、API-05 / 编码与 JSON；角色 TD-02.roles.administrator |
| 前置条件 | 完成9.1通用前提；关闭 Q-10、Q-14、Q-15；每个子场景独立还原，不能沿用上一子场景的修改 |
| 具体数据 | TD-01、TD-02、TD-07；TD-01.tables.sys_dict；dictItems=[启用,停用] |
| 操作步骤 | 准备本例无引用新对象并读取版本，调用 API-05[编辑]，重新读取 |
| 预期结果与禁止副作用 | 仅允许字段变化；版本按批准机制变化；未提交字段不被意外清空。 散列、AppSecret 与令牌不进入常规输出。 HTTP/业务码依9.1分列；非本例目标对象、凭据与授权关系不得附带变化。 |
| 清理/重跑 | 保存脱敏证据，按ID映射只清理本例生成对象并恢复初始字段/版本；关系先子后父；不清共享审计；步骤见9.5 |
| 实际执行 | 阻断；实际结果/环境/构建版本/执行人/时间/证据均无；拟证据目录 validation/business/TC-12-007/ |

#### TC-12-008：字典详情

| 项目 | 执行定义 |
| --- | --- |
| 关联与角色 | AC-12；US-05、US-06 / BR-08、BR-20；API-04、API-05 / 编码与 JSON；角色 TD-02.roles.administrator |
| 前置条件 | 完成9.1通用前提；关闭 Q-10、Q-14、Q-15；每个子场景独立还原，不能沿用上一子场景的修改 |
| 具体数据 | TD-01、TD-02、TD-07；TD-01.tables.sys_dict；按本例新对象实际 ID 定位；另以未授权管理员/对象做对照 |
| 操作步骤 | 调用 API-05[详情]，比较允许字段与持久值 |
| 预期结果与禁止副作用 | 授权主体可读正确字段；越权拒绝且不泄露对象；读取不写数据。 散列、AppSecret 与令牌不进入常规输出。 HTTP/业务码依9.1分列；非本例目标对象、凭据与授权关系不得附带变化。 |
| 清理/重跑 | 保存脱敏证据，按ID映射只清理本例生成对象并恢复初始字段/版本；关系先子后父；不清共享审计；步骤见9.5 |
| 实际执行 | 阻断；实际结果/环境/构建版本/执行人/时间/证据均无；拟证据目录 validation/business/TC-12-008/ |

#### TC-12-009：字典列表

| 项目 | 执行定义 |
| --- | --- |
| 关联与角色 | AC-12；US-05、US-06 / BR-08、BR-20；API-04、API-05 / 编码与 JSON；角色 TD-02.roles.administrator |
| 前置条件 | 完成9.1通用前提；关闭 Q-10、Q-14、Q-15；每个子场景独立还原，不能沿用上一子场景的修改 |
| 具体数据 | TD-01、TD-02、TD-07；TD-01.tables.sys_dict；使用本例编码/名称筛选；空匹配值=auth-prd-no-match |
| 操作步骤 | 调用 API-05[列表]并遍历分页；再查询空匹配 |
| 预期结果与禁止副作用 | 范围内可查询且无越权记录；空集合与分页口径一致；不写数据。 散列、AppSecret 与令牌不进入常规输出。 HTTP/业务码依9.1分列；非本例目标对象、凭据与授权关系不得附带变化。 |
| 清理/重跑 | 保存脱敏证据，按ID映射只清理本例生成对象并恢复初始字段/版本；关系先子后父；不清共享审计；步骤见9.5 |
| 实际执行 | 阻断；实际结果/环境/构建版本/执行人/时间/证据均无；拟证据目录 validation/business/TC-12-009/ |

#### TC-12-010：字典删除

| 项目 | 执行定义 |
| --- | --- |
| 关联与角色 | AC-12；US-05、US-06 / BR-08、BR-20；API-04、API-05 / 编码与 JSON；角色 TD-02.roles.administrator |
| 前置条件 | 完成9.1通用前提；关闭 Q-10、Q-14、Q-15；每个子场景独立还原，不能沿用上一子场景的修改 |
| 具体数据 | TD-01、TD-02、TD-07；TD-01.tables.sys_dict；本例单独创建且无引用的对象；删除语义须先批准Q-10 |
| 操作步骤 | 调用 API-05[删除]，检查实体与关联及审计；再次读取 |
| 预期结果与禁止副作用 | 仅按批准硬删除/软删除/停用方案处理目标；不意外级联其他对象；读取结果符合删除策略。 散列、AppSecret 与令牌不进入常规输出。 HTTP/业务码依9.1分列；非本例目标对象、凭据与授权关系不得附带变化。 |
| 清理/重跑 | 保存脱敏证据，按ID映射只清理本例生成对象并恢复初始字段/版本；关系先子后父；不清共享审计；步骤见9.5 |
| 实际执行 | 阻断；实际结果/环境/构建版本/执行人/时间/证据均无；拟证据目录 validation/business/TC-12-010/ |

#### TC-13-001：权限组新增

| 项目 | 执行定义 |
| --- | --- |
| 关联与角色 | AC-13；US-07、US-08 / BR-08、BR-11；API-06、API-07 / 操作引用；角色 TD-02.roles.administrator |
| 前置条件 | 完成9.1通用前提；关闭 Q-03、Q-12、Q-15；每个子场景独立还原，不能沿用上一子场景的修改 |
| 具体数据 | TD-01、TD-02、TD-07；TD-01.tables.permission_group；name=新权限组；operationIds=[201] |
| 操作步骤 | 调用 API-07[新增]，由响应记录实际生成 ID；以该 ID 复查 |
| 预期结果与禁止副作用 | 只新增一条正确记录；ID 由服务端生成，不改写已有对象。 散列、AppSecret 与令牌不进入常规输出。 HTTP/业务码依9.1分列；非本例目标对象、凭据与授权关系不得附带变化。 |
| 清理/重跑 | 保存脱敏证据，按ID映射只清理本例生成对象并恢复初始字段/版本；关系先子后父；不清共享审计；步骤见9.5 |
| 实际执行 | 阻断；实际结果/环境/构建版本/执行人/时间/证据均无；拟证据目录 validation/business/TC-13-001/ |

#### TC-13-002：权限组编辑

| 项目 | 执行定义 |
| --- | --- |
| 关联与角色 | AC-13；US-07、US-08 / BR-08、BR-11；API-06、API-07 / 操作引用；角色 TD-02.roles.administrator |
| 前置条件 | 完成9.1通用前提；关闭 Q-03、Q-12、Q-15；每个子场景独立还原，不能沿用上一子场景的修改 |
| 具体数据 | TD-01、TD-02、TD-07；TD-01.tables.permission_group；operationIds=[201,203] |
| 操作步骤 | 准备本例无引用新对象并读取版本，调用 API-07[编辑]，重新读取 |
| 预期结果与禁止副作用 | 仅允许字段变化；版本按批准机制变化；未提交字段不被意外清空。 散列、AppSecret 与令牌不进入常规输出。 HTTP/业务码依9.1分列；非本例目标对象、凭据与授权关系不得附带变化。 |
| 清理/重跑 | 保存脱敏证据，按ID映射只清理本例生成对象并恢复初始字段/版本；关系先子后父；不清共享审计；步骤见9.5 |
| 实际执行 | 阻断；实际结果/环境/构建版本/执行人/时间/证据均无；拟证据目录 validation/business/TC-13-002/ |

#### TC-13-003：权限组详情

| 项目 | 执行定义 |
| --- | --- |
| 关联与角色 | AC-13；US-07、US-08 / BR-08、BR-11；API-06、API-07 / 操作引用；角色 TD-02.roles.administrator |
| 前置条件 | 完成9.1通用前提；关闭 Q-03、Q-12、Q-15；每个子场景独立还原，不能沿用上一子场景的修改 |
| 具体数据 | TD-01、TD-02、TD-07；TD-01.tables.permission_group；按本例新对象实际 ID 定位；另以未授权管理员/对象做对照 |
| 操作步骤 | 调用 API-07[详情]，比较允许字段与持久值 |
| 预期结果与禁止副作用 | 授权主体可读正确字段；越权拒绝且不泄露对象；读取不写数据。 散列、AppSecret 与令牌不进入常规输出。 HTTP/业务码依9.1分列；非本例目标对象、凭据与授权关系不得附带变化。 |
| 清理/重跑 | 保存脱敏证据，按ID映射只清理本例生成对象并恢复初始字段/版本；关系先子后父；不清共享审计；步骤见9.5 |
| 实际执行 | 阻断；实际结果/环境/构建版本/执行人/时间/证据均无；拟证据目录 validation/business/TC-13-003/ |

#### TC-13-004：权限组列表

| 项目 | 执行定义 |
| --- | --- |
| 关联与角色 | AC-13；US-07、US-08 / BR-08、BR-11；API-06、API-07 / 操作引用；角色 TD-02.roles.administrator |
| 前置条件 | 完成9.1通用前提；关闭 Q-03、Q-12、Q-15；每个子场景独立还原，不能沿用上一子场景的修改 |
| 具体数据 | TD-01、TD-02、TD-07；TD-01.tables.permission_group；使用本例编码/名称筛选；空匹配值=auth-prd-no-match |
| 操作步骤 | 调用 API-07[列表]并遍历分页；再查询空匹配 |
| 预期结果与禁止副作用 | 范围内可查询且无越权记录；空集合与分页口径一致；不写数据。 散列、AppSecret 与令牌不进入常规输出。 HTTP/业务码依9.1分列；非本例目标对象、凭据与授权关系不得附带变化。 |
| 清理/重跑 | 保存脱敏证据，按ID映射只清理本例生成对象并恢复初始字段/版本；关系先子后父；不清共享审计；步骤见9.5 |
| 实际执行 | 阻断；实际结果/环境/构建版本/执行人/时间/证据均无；拟证据目录 validation/business/TC-13-004/ |

#### TC-13-005：权限组删除

| 项目 | 执行定义 |
| --- | --- |
| 关联与角色 | AC-13；US-07、US-08 / BR-08、BR-11；API-06、API-07 / 操作引用；角色 TD-02.roles.administrator |
| 前置条件 | 完成9.1通用前提；关闭 Q-03、Q-12、Q-15；每个子场景独立还原，不能沿用上一子场景的修改 |
| 具体数据 | TD-01、TD-02、TD-07；TD-01.tables.permission_group；本例单独创建且无引用的对象；删除语义须先批准Q-10 |
| 操作步骤 | 调用 API-07[删除]，检查实体与关联及审计；再次读取 |
| 预期结果与禁止副作用 | 仅按批准硬删除/软删除/停用方案处理目标；不意外级联其他对象；读取结果符合删除策略。 散列、AppSecret 与令牌不进入常规输出。 HTTP/业务码依9.1分列；非本例目标对象、凭据与授权关系不得附带变化。 |
| 清理/重跑 | 保存脱敏证据，按ID映射只清理本例生成对象并恢复初始字段/版本；关系先子后父；不清共享审计；步骤见9.5 |
| 实际执行 | 阻断；实际结果/环境/构建版本/执行人/时间/证据均无；拟证据目录 validation/business/TC-13-005/ |

#### TC-14-001：用户授权关联新增

| 项目 | 执行定义 |
| --- | --- |
| 关联与角色 | AC-14；US-09、US-10 / BR-12、BR-30；API-08、API-09 / 组合唯一；角色 TD-02.roles.administrator |
| 前置条件 | 完成9.1通用前提；关闭 Q-01、Q-12、Q-15；每个子场景独立还原，不能沿用上一子场景的修改 |
| 具体数据 | TD-01、TD-02、TD-07；TD-07.uniqueAccountPair；permissionGroupId=403；accountId=103 |
| 操作步骤 | 调用 API-08[新增]，由响应记录实际生成 ID；以该 ID 复查 |
| 预期结果与禁止副作用 | 只新增一条正确记录；ID 由服务端生成，不改写已有对象。 散列、AppSecret 与令牌不进入常规输出。 HTTP/业务码依9.1分列；非本例目标对象、凭据与授权关系不得附带变化。 |
| 清理/重跑 | 保存脱敏证据，按ID映射只清理本例生成对象并恢复初始字段/版本；关系先子后父；不清共享审计；步骤见9.5 |
| 实际执行 | 阻断；实际结果/环境/构建版本/执行人/时间/证据均无；拟证据目录 validation/business/TC-14-001/ |

#### TC-14-002：用户授权关联编辑

| 项目 | 执行定义 |
| --- | --- |
| 关联与角色 | AC-14；US-09、US-10 / BR-12、BR-30；API-08、API-09 / 组合唯一；角色 TD-02.roles.administrator |
| 前置条件 | 完成9.1通用前提；关闭 Q-01、Q-12、Q-15；每个子场景独立还原，不能沿用上一子场景的修改 |
| 具体数据 | TD-01、TD-02、TD-07；TD-07.uniqueAccountPair；permissionGroupId=402；accountId=103 |
| 操作步骤 | 准备本例无引用新对象并读取版本，调用 API-08[编辑]，重新读取 |
| 预期结果与禁止副作用 | 仅允许字段变化；版本按批准机制变化；未提交字段不被意外清空。 散列、AppSecret 与令牌不进入常规输出。 HTTP/业务码依9.1分列；非本例目标对象、凭据与授权关系不得附带变化。 |
| 清理/重跑 | 保存脱敏证据，按ID映射只清理本例生成对象并恢复初始字段/版本；关系先子后父；不清共享审计；步骤见9.5 |
| 实际执行 | 阻断；实际结果/环境/构建版本/执行人/时间/证据均无；拟证据目录 validation/business/TC-14-002/ |

#### TC-14-003：用户授权关联详情

| 项目 | 执行定义 |
| --- | --- |
| 关联与角色 | AC-14；US-09、US-10 / BR-12、BR-30；API-08、API-09 / 组合唯一；角色 TD-02.roles.administrator |
| 前置条件 | 完成9.1通用前提；关闭 Q-01、Q-12、Q-15；每个子场景独立还原，不能沿用上一子场景的修改 |
| 具体数据 | TD-01、TD-02、TD-07；TD-07.uniqueAccountPair；按本例新对象实际 ID 定位；另以未授权管理员/对象做对照 |
| 操作步骤 | 调用 API-08[详情]，比较允许字段与持久值 |
| 预期结果与禁止副作用 | 授权主体可读正确字段；越权拒绝且不泄露对象；读取不写数据。 散列、AppSecret 与令牌不进入常规输出。 HTTP/业务码依9.1分列；非本例目标对象、凭据与授权关系不得附带变化。 |
| 清理/重跑 | 保存脱敏证据，按ID映射只清理本例生成对象并恢复初始字段/版本；关系先子后父；不清共享审计；步骤见9.5 |
| 实际执行 | 阻断；实际结果/环境/构建版本/执行人/时间/证据均无；拟证据目录 validation/business/TC-14-003/ |

#### TC-14-004：用户授权关联列表

| 项目 | 执行定义 |
| --- | --- |
| 关联与角色 | AC-14；US-09、US-10 / BR-12、BR-30；API-08、API-09 / 组合唯一；角色 TD-02.roles.administrator |
| 前置条件 | 完成9.1通用前提；关闭 Q-01、Q-12、Q-15；每个子场景独立还原，不能沿用上一子场景的修改 |
| 具体数据 | TD-01、TD-02、TD-07；TD-07.uniqueAccountPair；使用本例编码/名称筛选；空匹配值=auth-prd-no-match |
| 操作步骤 | 调用 API-08[列表]并遍历分页；再查询空匹配 |
| 预期结果与禁止副作用 | 范围内可查询且无越权记录；空集合与分页口径一致；不写数据。 散列、AppSecret 与令牌不进入常规输出。 HTTP/业务码依9.1分列；非本例目标对象、凭据与授权关系不得附带变化。 |
| 清理/重跑 | 保存脱敏证据，按ID映射只清理本例生成对象并恢复初始字段/版本；关系先子后父；不清共享审计；步骤见9.5 |
| 实际执行 | 阻断；实际结果/环境/构建版本/执行人/时间/证据均无；拟证据目录 validation/business/TC-14-004/ |

#### TC-14-005：用户授权关联删除

| 项目 | 执行定义 |
| --- | --- |
| 关联与角色 | AC-14；US-09、US-10 / BR-12、BR-30；API-08、API-09 / 组合唯一；角色 TD-02.roles.administrator |
| 前置条件 | 完成9.1通用前提；关闭 Q-01、Q-12、Q-15；每个子场景独立还原，不能沿用上一子场景的修改 |
| 具体数据 | TD-01、TD-02、TD-07；TD-07.uniqueAccountPair；本例单独创建且无引用的对象；删除语义须先批准Q-10 |
| 操作步骤 | 调用 API-08[删除]，检查实体与关联及审计；再次读取 |
| 预期结果与禁止副作用 | 仅按批准硬删除/软删除/停用方案处理目标；不意外级联其他对象；读取结果符合删除策略。 散列、AppSecret 与令牌不进入常规输出。 HTTP/业务码依9.1分列；非本例目标对象、凭据与授权关系不得附带变化。 |
| 清理/重跑 | 保存脱敏证据，按ID映射只清理本例生成对象并恢复初始字段/版本；关系先子后父；不清共享审计；步骤见9.5 |
| 实际执行 | 阻断；实际结果/环境/构建版本/执行人/时间/证据均无；拟证据目录 validation/business/TC-14-005/ |

#### TC-14-006：组织授权关联新增

| 项目 | 执行定义 |
| --- | --- |
| 关联与角色 | AC-14；US-09、US-10 / BR-12、BR-30；API-08、API-09 / 组合唯一；角色 TD-02.roles.administrator |
| 前置条件 | 完成9.1通用前提；关闭 Q-01、Q-12、Q-15；每个子场景独立还原，不能沿用上一子场景的修改 |
| 具体数据 | TD-01、TD-02、TD-07；TD-07.uniqueOrgPair；permissionGroupId=403；orgId=21 |
| 操作步骤 | 调用 API-09[新增]，由响应记录实际生成 ID；以该 ID 复查 |
| 预期结果与禁止副作用 | 只新增一条正确记录；ID 由服务端生成，不改写已有对象。 散列、AppSecret 与令牌不进入常规输出。 HTTP/业务码依9.1分列；非本例目标对象、凭据与授权关系不得附带变化。 |
| 清理/重跑 | 保存脱敏证据，按ID映射只清理本例生成对象并恢复初始字段/版本；关系先子后父；不清共享审计；步骤见9.5 |
| 实际执行 | 阻断；实际结果/环境/构建版本/执行人/时间/证据均无；拟证据目录 validation/business/TC-14-006/ |

#### TC-14-007：组织授权关联编辑

| 项目 | 执行定义 |
| --- | --- |
| 关联与角色 | AC-14；US-09、US-10 / BR-12、BR-30；API-08、API-09 / 组合唯一；角色 TD-02.roles.administrator |
| 前置条件 | 完成9.1通用前提；关闭 Q-01、Q-12、Q-15；每个子场景独立还原，不能沿用上一子场景的修改 |
| 具体数据 | TD-01、TD-02、TD-07；TD-07.uniqueOrgPair；permissionGroupId=402；orgId=21 |
| 操作步骤 | 准备本例无引用新对象并读取版本，调用 API-09[编辑]，重新读取 |
| 预期结果与禁止副作用 | 仅允许字段变化；版本按批准机制变化；未提交字段不被意外清空。 散列、AppSecret 与令牌不进入常规输出。 HTTP/业务码依9.1分列；非本例目标对象、凭据与授权关系不得附带变化。 |
| 清理/重跑 | 保存脱敏证据，按ID映射只清理本例生成对象并恢复初始字段/版本；关系先子后父；不清共享审计；步骤见9.5 |
| 实际执行 | 阻断；实际结果/环境/构建版本/执行人/时间/证据均无；拟证据目录 validation/business/TC-14-007/ |

#### TC-14-008：组织授权关联详情

| 项目 | 执行定义 |
| --- | --- |
| 关联与角色 | AC-14；US-09、US-10 / BR-12、BR-30；API-08、API-09 / 组合唯一；角色 TD-02.roles.administrator |
| 前置条件 | 完成9.1通用前提；关闭 Q-01、Q-12、Q-15；每个子场景独立还原，不能沿用上一子场景的修改 |
| 具体数据 | TD-01、TD-02、TD-07；TD-07.uniqueOrgPair；按本例新对象实际 ID 定位；另以未授权管理员/对象做对照 |
| 操作步骤 | 调用 API-09[详情]，比较允许字段与持久值 |
| 预期结果与禁止副作用 | 授权主体可读正确字段；越权拒绝且不泄露对象；读取不写数据。 散列、AppSecret 与令牌不进入常规输出。 HTTP/业务码依9.1分列；非本例目标对象、凭据与授权关系不得附带变化。 |
| 清理/重跑 | 保存脱敏证据，按ID映射只清理本例生成对象并恢复初始字段/版本；关系先子后父；不清共享审计；步骤见9.5 |
| 实际执行 | 阻断；实际结果/环境/构建版本/执行人/时间/证据均无；拟证据目录 validation/business/TC-14-008/ |

#### TC-14-009：组织授权关联列表

| 项目 | 执行定义 |
| --- | --- |
| 关联与角色 | AC-14；US-09、US-10 / BR-12、BR-30；API-08、API-09 / 组合唯一；角色 TD-02.roles.administrator |
| 前置条件 | 完成9.1通用前提；关闭 Q-01、Q-12、Q-15；每个子场景独立还原，不能沿用上一子场景的修改 |
| 具体数据 | TD-01、TD-02、TD-07；TD-07.uniqueOrgPair；使用本例编码/名称筛选；空匹配值=auth-prd-no-match |
| 操作步骤 | 调用 API-09[列表]并遍历分页；再查询空匹配 |
| 预期结果与禁止副作用 | 范围内可查询且无越权记录；空集合与分页口径一致；不写数据。 散列、AppSecret 与令牌不进入常规输出。 HTTP/业务码依9.1分列；非本例目标对象、凭据与授权关系不得附带变化。 |
| 清理/重跑 | 保存脱敏证据，按ID映射只清理本例生成对象并恢复初始字段/版本；关系先子后父；不清共享审计；步骤见9.5 |
| 实际执行 | 阻断；实际结果/环境/构建版本/执行人/时间/证据均无；拟证据目录 validation/business/TC-14-009/ |

#### TC-14-010：组织授权关联删除

| 项目 | 执行定义 |
| --- | --- |
| 关联与角色 | AC-14；US-09、US-10 / BR-12、BR-30；API-08、API-09 / 组合唯一；角色 TD-02.roles.administrator |
| 前置条件 | 完成9.1通用前提；关闭 Q-01、Q-12、Q-15；每个子场景独立还原，不能沿用上一子场景的修改 |
| 具体数据 | TD-01、TD-02、TD-07；TD-07.uniqueOrgPair；本例单独创建且无引用的对象；删除语义须先批准Q-10 |
| 操作步骤 | 调用 API-09[删除]，检查实体与关联及审计；再次读取 |
| 预期结果与禁止副作用 | 仅按批准硬删除/软删除/停用方案处理目标；不意外级联其他对象；读取结果符合删除策略。 散列、AppSecret 与令牌不进入常规输出。 HTTP/业务码依9.1分列；非本例目标对象、凭据与授权关系不得附带变化。 |
| 清理/重跑 | 保存脱敏证据，按ID映射只清理本例生成对象并恢复初始字段/版本；关系先子后父；不清共享审计；步骤见9.5 |
| 实际执行 | 阻断；实际结果/环境/构建版本/执行人/时间/证据均无；拟证据目录 validation/business/TC-14-010/ |

#### TC-09-006：账号重复/只读字段/长度校验

| 项目 | 执行定义 |
| --- | --- |
| 关联与角色 | AC-09；US-01 / BR-08、BR-25、BR-26；API-01 / 账号唯一约束；角色 TD-02.roles.administrator |
| 前置条件 | 完成9.1通用前提；关闭 Q-01、Q-05、Q-10、Q-12、Q-15；每个子场景独立还原，不能沿用上一子场景的修改 |
| 具体数据 | TD-01、TD-05；username=auth-prd-member 重复；新建传 id=102；编辑注入TD-05.readonly；username65 |
| 操作步骤 | 各组分别调用账号新增/编辑；检查新增数、账号102及服务端字段 |
| 预期结果与禁止副作用 | 重复、只读写入、65字符名称按规则拒绝；不存在编辑不转新增；原账号不变。 HTTP/业务码依9.1分列；非本例目标对象、凭据与授权关系不得附带变化。 |
| 清理/重跑 | 保存脱敏证据，按ID映射只清理本例生成对象并恢复初始字段/版本；关系先子后父；不清共享审计；步骤见9.5 |
| 实际执行 | 阻断；实际结果/环境/构建版本/执行人/时间/证据均无；拟证据目录 validation/business/TC-09-006/ |

#### TC-10-006：移动子树与防环

| 项目 | 执行定义 |
| --- | --- |
| 关联与角色 | AC-10；US-02 / BR-09、BR-27；API-02 / 组织树与版本；角色 TD-02.roles.administrator |
| 前置条件 | 完成9.1通用前提；关闭 Q-02、Q-12、Q-15；每个子场景独立还原，不能沿用上一子场景的修改 |
| 具体数据 | TD-01、TD-07；移动 org11 到org20；反例 parentId=12 或 parentId=11；版本初值7 |
| 操作步骤 | 核对 org11/12 路径；分别执行合法移动、自父、循环和陈旧版本更新 |
| 预期结果与禁止副作用 | 合法移动同时更新两条路径；自父/循环/旧版本拒绝并保留原树；目标范围未经授权不可移动。 HTTP/业务码依9.1分列；非本例目标对象、凭据与授权关系不得附带变化。 |
| 清理/重跑 | 保存脱敏证据，按ID映射只清理本例生成对象并恢复初始字段/版本；关系先子后父；不清共享审计；步骤见9.5 |
| 实际执行 | 阻断；实际结果/环境/构建版本/执行人/时间/证据均无；拟证据目录 validation/business/TC-10-006/ |

#### TC-11-006：跨部门成员及重复/移除

| 项目 | 执行定义 |
| --- | --- |
| 关联与角色 | AC-11；US-03 / BR-10、BR-12；API-03、API-15 / 成员组合唯一；角色 TD-02.roles.administrator |
| 前置条件 | 完成9.1通用前提；关闭 Q-02、Q-10、Q-12、Q-15；每个子场景独立还原，不能沿用上一子场景的修改 |
| 具体数据 | TD-01、TD-02；user_group301；成员102/103；重复添加103再移除103 |
| 操作步骤 | API-15[成员添加/列表/移除]；同时对照103在加入前后的操作202校验，禁用委托 |
| 预期结果与禁止副作用 | 成员组合唯一；移除只影响用户组成员；加入跨部门用户组不会隐式授予操作权限。 HTTP/业务码依9.1分列；非本例目标对象、凭据与授权关系不得附带变化。 |
| 清理/重跑 | 保存脱敏证据，按ID映射只清理本例生成对象并恢复初始字段/版本；关系先子后父；不清共享审计；步骤见9.5 |
| 实际执行 | 阻断；实际结果/环境/构建版本/执行人/时间/证据均无；拟证据目录 validation/business/TC-11-006/ |

#### TC-12-011：配置结构与唯一引用校验

| 项目 | 执行定义 |
| --- | --- |
| 关联与角色 | AC-12；US-05、US-06 / BR-08、BR-20；API-04、API-05 / 编码与 JSON；角色 TD-02.roles.administrator |
| 前置条件 | 完成9.1通用前提；关闭 Q-10、Q-14、Q-15；每个子场景独立还原，不能沿用上一子场景的修改 |
| 具体数据 | TD-01、TD-05；已有paramCode/dictCode；dictItems 分别错误对象/null/[]；paramValue分别缺失/null/空串；设置一个消费方引用 |
| 操作步骤 | 按 Q-14 确定每组合法性后逐组提交，另删除被引用参数/字典 |
| 预期结果与禁止副作用 | 重复编码拒绝；必填缺失/null拒绝；数组空与参数空串按批准规则独立判断；禁止删除引用时原值保留。 HTTP/业务码依9.1分列；非本例目标对象、凭据与授权关系不得附带变化。 |
| 清理/重跑 | 保存脱敏证据，按ID映射只清理本例生成对象并恢复初始字段/版本；关系先子后父；不清共享审计；步骤见9.5 |
| 实际执行 | 阻断；实际结果/环境/构建版本/执行人/时间/证据均无；拟证据目录 validation/business/TC-12-011/ |

#### TC-13-006：操作登记新增

| 项目 | 执行定义 |
| --- | --- |
| 关联与角色 | AC-13；US-07、US-08 / BR-08、BR-11；API-06、API-07 / 操作引用；角色 TD-02.roles.administrator |
| 前置条件 | 完成9.1通用前提；关闭 Q-03、Q-12、Q-15；每个子场景独立还原，不能沿用上一子场景的修改 |
| 具体数据 | TD-01；operationCode=DeviceController.detail；新增对照码=DeviceController.syntheticCheck；resourceType=device |
| 操作步骤 | 执行 API-06[新增]；新增使用对照码，查询使用既有203 |
| 预期结果与禁止副作用 | 新增只登记一次，详情/列表返回授权字段；不增加未批准的操作编辑/删除入口。 HTTP/业务码依9.1分列；非本例目标对象、凭据与授权关系不得附带变化。 |
| 清理/重跑 | 保存脱敏证据，按ID映射只清理本例生成对象并恢复初始字段/版本；关系先子后父；不清共享审计；步骤见9.5 |
| 实际执行 | 阻断；实际结果/环境/构建版本/执行人/时间/证据均无；拟证据目录 validation/business/TC-13-006/ |

#### TC-13-007：操作登记详情

| 项目 | 执行定义 |
| --- | --- |
| 关联与角色 | AC-13；US-07、US-08 / BR-08、BR-11；API-06、API-07 / 操作引用；角色 TD-02.roles.administrator |
| 前置条件 | 完成9.1通用前提；关闭 Q-03、Q-12、Q-15；每个子场景独立还原，不能沿用上一子场景的修改 |
| 具体数据 | TD-01；operationCode=DeviceController.detail；新增对照码=DeviceController.syntheticCheck；resourceType=device |
| 操作步骤 | 执行 API-06[详情]；新增使用对照码，查询使用既有203 |
| 预期结果与禁止副作用 | 新增只登记一次，详情/列表返回授权字段；不增加未批准的操作编辑/删除入口。 HTTP/业务码依9.1分列；非本例目标对象、凭据与授权关系不得附带变化。 |
| 清理/重跑 | 保存脱敏证据，按ID映射只清理本例生成对象并恢复初始字段/版本；关系先子后父；不清共享审计；步骤见9.5 |
| 实际执行 | 阻断；实际结果/环境/构建版本/执行人/时间/证据均无；拟证据目录 validation/business/TC-13-007/ |

#### TC-13-008：操作登记列表

| 项目 | 执行定义 |
| --- | --- |
| 关联与角色 | AC-13；US-07、US-08 / BR-08、BR-11；API-06、API-07 / 操作引用；角色 TD-02.roles.administrator |
| 前置条件 | 完成9.1通用前提；关闭 Q-03、Q-12、Q-15；每个子场景独立还原，不能沿用上一子场景的修改 |
| 具体数据 | TD-01；operationCode=DeviceController.detail；新增对照码=DeviceController.syntheticCheck；resourceType=device |
| 操作步骤 | 执行 API-06[列表]；新增使用对照码，查询使用既有203 |
| 预期结果与禁止副作用 | 新增只登记一次，详情/列表返回授权字段；不增加未批准的操作编辑/删除入口。 HTTP/业务码依9.1分列；非本例目标对象、凭据与授权关系不得附带变化。 |
| 清理/重跑 | 保存脱敏证据，按ID映射只清理本例生成对象并恢复初始字段/版本；关系先子后父；不清共享审计；步骤见9.5 |
| 实际执行 | 阻断；实际结果/环境/构建版本/执行人/时间/证据均无；拟证据目录 validation/business/TC-13-008/ |

#### TC-13-009：重复操作与无效权限引用

| 项目 | 执行定义 |
| --- | --- |
| 关联与角色 | AC-13；US-07、US-08 / BR-08、BR-11；API-06、API-07 / 操作引用；角色 TD-02.roles.administrator |
| 前置条件 | 完成9.1通用前提；关闭 Q-03、Q-12、Q-15；每个子场景独立还原，不能沿用上一子场景的修改 |
| 具体数据 | TD-01、TD-05；重复 operationCode=DeviceController.control；permissionGroup.operationIds=[999999] |
| 操作步骤 | 分别调用操作新增和权限组编辑；检查operation计数及组401 |
| 预期结果与禁止副作用 | 两组拒绝；既有操作与组操作集合不变；JSONB 语法正确不代表引用合法。 HTTP/业务码依9.1分列；非本例目标对象、凭据与授权关系不得附带变化。 |
| 清理/重跑 | 保存脱敏证据，按ID映射只清理本例生成对象并恢复初始字段/版本；关系先子后父；不清共享审计；步骤见9.5 |
| 实际执行 | 阻断；实际结果/环境/构建版本/执行人/时间/证据均无；拟证据目录 validation/business/TC-13-009/ |

#### TC-14-011：同组合并发建立与原子替换

| 项目 | 执行定义 |
| --- | --- |
| 关联与角色 | AC-14；US-09、US-10 / BR-12、BR-30；API-08、API-09 / 组合唯一；角色 TD-02.roles.administrator |
| 前置条件 | 完成9.1通用前提；关闭 Q-01、Q-12、Q-15；每个子场景独立还原，不能沿用上一子场景的修改 |
| 具体数据 | TD-01、TD-07；两个请求相同 uniqueAccountPair，再两个相同 uniqueOrgPair；将关联411替换为已存在组合 |
| 操作步骤 | 屏障同时释放两次新增并等待完成；然后测试冲突替换和重复删除 |
| 预期结果与禁止副作用 | 每个组合最多一条；冲突替换不能先删旧关系；重复删除不额外授予或恢复权限。 HTTP/业务码依9.1分列；非本例目标对象、凭据与授权关系不得附带变化。 |
| 清理/重跑 | 保存脱敏证据，按ID映射只清理本例生成对象并恢复初始字段/版本；关系先子后父；不清共享审计；步骤见9.5 |
| 实际执行 | 阻断；实际结果/环境/构建版本/执行人/时间/证据均无；拟证据目录 validation/business/TC-14-011/ |

#### TC-15-001：应用注册

| 项目 | 执行定义 |
| --- | --- |
| 关联与角色 | AC-15；US-11 / BR-03、BR-13；API-11 / 应用组和 app 唯一；角色 TD-02.roles.administrator |
| 前置条件 | 完成9.1通用前提；关闭 Q-03、Q-05、Q-15；每个子场景独立还原，不能沿用上一子场景的修改 |
| 具体数据 | TD-01、TD-02；appCode=auth-prd-new-app；group401；SELF |
| 操作步骤 | API-11[应用注册]，记录生成键，再重复编码注册 |
| 预期结果与禁止副作用 | 首次仅一个应用与受控凭据；重复拒绝；密钥仅按批准流程展示；实际公开响应协议待Q-15。 HTTP/业务码依9.1分列；非本例目标对象、凭据与授权关系不得附带变化。 |
| 清理/重跑 | 保存脱敏证据，按ID映射只清理本例生成对象并恢复初始字段/版本；关系先子后父；不清共享审计；步骤见9.5 |
| 实际执行 | 阻断；实际结果/环境/构建版本/执行人/时间/证据均无；拟证据目录 validation/business/TC-15-001/ |

#### TC-15-002：操作绑定及共享影响

| 项目 | 执行定义 |
| --- | --- |
| 关联与角色 | AC-15；US-11 / BR-03、BR-13；API-11 / 应用组和 app 唯一；角色 TD-02.roles.administrator |
| 前置条件 | 完成9.1通用前提；关闭 Q-03、Q-05、Q-15；每个子场景独立还原，不能沿用上一子场景的修改 |
| 具体数据 | TD-01、TD-02；app501与504共享group401；目标操作=[201] |
| 操作步骤 | API-11[操作授权码绑定]；核对两应用和其他用户的组 |
| 预期结果与禁止副作用 | 不得默改共享组造成他应用/用户权限变化；越权绑定拒绝；实际公开响应协议待Q-15。 HTTP/业务码依9.1分列；非本例目标对象、凭据与授权关系不得附带变化。 |
| 清理/重跑 | 保存脱敏证据，按ID映射只清理本例生成对象并恢复初始字段/版本；关系先子后父；不清共享审计；步骤见9.5 |
| 实际执行 | 阻断；实际结果/环境/构建版本/执行人/时间/证据均无；拟证据目录 validation/business/TC-15-002/ |

#### TC-15-003：授权明细

| 项目 | 执行定义 |
| --- | --- |
| 关联与角色 | AC-15；US-11 / BR-03、BR-13；API-11 / 应用组和 app 唯一；角色 TD-02.roles.administrator |
| 前置条件 | 完成9.1通用前提；关闭 Q-03、Q-05、Q-15；每个子场景独立还原，不能沿用上一子场景的修改 |
| 具体数据 | TD-01、TD-02；app501；同/非负责该应用的管理员 |
| 操作步骤 | API-11[获取应用授权明细] |
| 预期结果与禁止副作用 | 仅负责应用的获准主体读到操作与范围；没有AppSecret或其他应用详情；实际公开响应协议待Q-15。 HTTP/业务码依9.1分列；非本例目标对象、凭据与授权关系不得附带变化。 |
| 清理/重跑 | 保存脱敏证据，按ID映射只清理本例生成对象并恢复初始字段/版本；关系先子后父；不清共享审计；步骤见9.5 |
| 实际执行 | 阻断；实际结果/环境/构建版本/执行人/时间/证据均无；拟证据目录 validation/business/TC-15-003/ |

#### TC-16-001：授权刷新与撤权传播

| 项目 | 执行定义 |
| --- | --- |
| 关联与角色 | AC-16；US-11 / BR-14、BR-17；API-11 / 策略版本/缓存候选；角色 TD-02.roles.administrator |
| 前置条件 | 完成9.1通用前提；关闭 Q-08、Q-13、Q-15；每个子场景独立还原，不能沿用上一子场景的修改 |
| 具体数据 | TD-01、TD-07、TD-10；app501；至少两个隔离节点持有旧许可；撤回operation202；Q-13批准时限 |
| 操作步骤 | API-11[应用授权刷新]；从撤权提交时刻到各节点最后一次允许逐点记录；核对密钥前后值 |
| 预期结果与禁止副作用 | 批准时限内全部拒绝旧许可；授权刷新不自行轮换AppSecret；未批准时限不能写通过。 HTTP/业务码依9.1分列；非本例目标对象、凭据与授权关系不得附带变化。 |
| 清理/重跑 | 保存脱敏证据，按ID映射只清理本例生成对象并恢复初始字段/版本；关系先子后父；不清共享审计；步骤见9.5 |
| 实际执行 | 阻断；实际结果/环境/构建版本/执行人/时间/证据均无；拟证据目录 validation/business/TC-16-001/ |

#### TC-17-001：Master 与 Scene 登录签发

| 项目 | 执行定义 |
| --- | --- |
| 关联与角色 | AC-17；US-04 / BR-02、BR-15；API-10、API-17 / token 类型与 scene；角色 TD-02.roles.staticUser |
| 前置条件 | 完成9.1通用前提；关闭 Q-05、Q-06、Q-11、Q-15；每个子场景独立还原，不能沿用上一子场景的修改 |
| 具体数据 | TD-01、TD-02、TD-04；account102；session-a；scene-a；批准寿命；有效凭据通过测试适配注入 |
| 操作步骤 | API-10[登录]和API-17[场景签发/兑换]；读取有效期、类型及可信主体 |
| 预期结果与禁止副作用 | Master/Scene类别与场景正确；客户端不能伪造accountId；1小时适用范围依Q-06定稿，刷新寿命不自动等于1小时。 HTTP/业务码依9.1分列；非本例目标对象、凭据与授权关系不得附带变化。 |
| 清理/重跑 | 保存脱敏证据，按ID映射只清理本例生成对象并恢复初始字段/版本；关系先子后父；不清共享审计；步骤见9.5 |
| 实际执行 | 阻断；实际结果/环境/构建版本/执行人/时间/证据均无；拟证据目录 validation/business/TC-17-001/ |

#### TC-17-002：错误场景及过期拒绝

| 项目 | 执行定义 |
| --- | --- |
| 关联与角色 | AC-17；US-04 / BR-02、BR-15；API-10、API-17 / token 类型与 scene；角色 TD-02.roles.staticUser |
| 前置条件 | 完成9.1通用前提；关闭 Q-05、Q-06、Q-11、Q-15；每个子场景独立还原，不能沿用上一子场景的修改 |
| 具体数据 | TD-01、TD-02、TD-04、TD-06；Scene实例703；scene-b；另组 now=afterUntil |
| 操作步骤 | 分别带错误场景和已过期访问令牌请求受保护操作 |
| 预期结果与禁止副作用 | 均拒绝，不恢复令牌或执行业务；真实JWT由适配签发，fixture标签本身不能登录。 HTTP/业务码依9.1分列；非本例目标对象、凭据与授权关系不得附带变化。 |
| 清理/重跑 | 保存脱敏证据，按ID映射只清理本例生成对象并恢复初始字段/版本；关系先子后父；不清共享审计；步骤见9.5 |
| 实际执行 | 阻断；实际结果/环境/构建版本/执行人/时间/证据均无；拟证据目录 validation/business/TC-17-002/ |

#### TC-18-001：并发刷新与旧令牌重放

| 项目 | 执行定义 |
| --- | --- |
| 关联与角色 | AC-18；US-04、US-14 / BR-16、BR-30；API-10、API-14 / 轮换原子约束；角色 TD-02.roles.staticUser |
| 前置条件 | 完成9.1通用前提；关闭 Q-06、Q-12、Q-15；每个子场景独立还原，不能沿用上一子场景的修改 |
| 具体数据 | TD-01、TD-02、TD-07；刷新实例702；session-a；两个同一刷新请求 |
| 操作步骤 | 屏障同时调用 API-10[刷新令牌]，开放API-14同样复测；随后重放旧令牌 |
| 预期结果与禁止副作用 | 按批准轮换方案至多一组有效换发；旧刷新令牌不能新增会话；事务失败不能只消费旧令牌却谎称签发。 HTTP/业务码依9.1分列；非本例目标对象、凭据与授权关系不得附带变化。 |
| 清理/重跑 | 保存脱敏证据，按ID映射只清理本例生成对象并恢复初始字段/版本；关系先子后父；不清共享审计；步骤见9.5 |
| 实际执行 | 阻断；实际结果/环境/构建版本/执行人/时间/证据均无；拟证据目录 validation/business/TC-18-001/ |

#### TC-18-002：刷新响应丢失后的恢复

| 项目 | 执行定义 |
| --- | --- |
| 关联与角色 | AC-18；US-04、US-14 / BR-16、BR-30；API-10、API-14 / 轮换原子约束；角色 TD-02.roles.staticUser |
| 前置条件 | 完成9.1通用前提；关闭 Q-06、Q-12、Q-15；每个子场景独立还原，不能沿用上一子场景的修改 |
| 具体数据 | TD-01、TD-02、TD-09；702 已消费但响应被测试代理丢弃 |
| 操作步骤 | 按批准的结果查询/幂等恢复协议处理；不得盲目用旧令牌无限重试 |
| 预期结果与禁止副作用 | 最终只存在批准数量的有效会话；明确未知结果，不能默认已失败重新签发。 HTTP/业务码依9.1分列；非本例目标对象、凭据与授权关系不得附带变化。 |
| 清理/重跑 | 保存脱敏证据，按ID映射只清理本例生成对象并恢复初始字段/版本；关系先子后父；不清共享审计；步骤见9.5 |
| 实际执行 | 阻断；实际结果/环境/构建版本/执行人/时间/证据均无；拟证据目录 validation/business/TC-18-002/ |

#### TC-19-001：退出当前会话与注销范围

| 项目 | 执行定义 |
| --- | --- |
| 关联与角色 | AC-19；US-04、US-14 / BR-17；API-10、API-14 / 撤销集合；角色 TD-02.roles.staticUser |
| 前置条件 | 完成9.1通用前提；关闭 Q-06、Q-08、Q-15；每个子场景独立还原，不能沿用上一子场景的修改 |
| 具体数据 | TD-01、TD-02；session-a含701/702/703；另建session-b对照有效会话；注销704为已撤销对照 |
| 操作步骤 | 分别API-10[退出/注销]和API-14[注销]，重复请求；管理员尝试注销未授权会话 |
| 预期结果与禁止副作用 | 只影响批准的会话/场景范围；范围外会话保持原状；重复不恢复；管理员越权拒绝。 HTTP/业务码依9.1分列；非本例目标对象、凭据与授权关系不得附带变化。 |
| 清理/重跑 | 保存脱敏证据，按ID映射只清理本例生成对象并恢复初始字段/版本；关系先子后父；不清共享审计；步骤见9.5 |
| 实际执行 | 阻断；实际结果/环境/构建版本/执行人/时间/证据均无；拟证据目录 validation/business/TC-19-001/ |

#### TC-20-001：申请幂等与参数冲突

| 项目 | 执行定义 |
| --- | --- |
| 关联与角色 | AC-20；US-12 / BR-06、BR-18、BR-30；API-12、API-16 / 状态/幂等/时序；角色 TD-02.roles.delegatedUser |
| 前置条件 | 完成9.1通用前提；关闭 Q-07、Q-12、Q-15；每个子场景独立还原，不能沿用上一子场景的修改 |
| 具体数据 | TD-01、TD-02、TD-06、TD-07；grantee103；group403；device/dev-001；validFrom/Until；同idempotencyKey；反例改resourceIds=[dev-002] |
| 操作步骤 | API-12[申请]首次及同参数重试，再同键不同参数提交 |
| 预期结果与禁止副作用 | 首次pending不生效；同键同参数不新增；不同参数冲突且不改原申请；不能自动批准。 HTTP/业务码依9.1分列；非本例目标对象、凭据与授权关系不得附带变化。 |
| 清理/重跑 | 保存脱敏证据，按ID映射只清理本例生成对象并恢复初始字段/版本；关系先子后父；不清共享审计；步骤见9.5 |
| 实际执行 | 阻断；实际结果/环境/构建版本/执行人/时间/证据均无；拟证据目录 validation/business/TC-20-001/ |

#### TC-20-002：委托查询可见范围

| 项目 | 执行定义 |
| --- | --- |
| 关联与角色 | AC-20；US-12 / BR-06、BR-18、BR-30；API-12、API-16 / 状态/幂等/时序；角色 TD-02.roles.delegatedUser |
| 前置条件 | 完成9.1通用前提；关闭 Q-07、Q-12、Q-15；每个子场景独立还原，不能沿用上一子场景的修改 |
| 具体数据 | TD-01、TD-02；委托601；申请/处理/无关三种身份 |
| 操作步骤 | API-16[详情/列表]，切换主体并篡改委托ID |
| 预期结果与禁止副作用 | 仅批准范围内可读；无关主体不获取资源清单/理由；查询不触发批准。 HTTP/业务码依9.1分列；非本例目标对象、凭据与授权关系不得附带变化。 |
| 清理/重跑 | 保存脱敏证据，按ID映射只清理本例生成对象并恢复初始字段/版本；关系先子后父；不清共享审计；步骤见9.5 |
| 实际执行 | 阻断；实际结果/环境/构建版本/执行人/时间/证据均无；拟证据目录 validation/business/TC-20-002/ |

#### TC-21-001：账号101 被引用删除

| 项目 | 执行定义 |
| --- | --- |
| 关联与角色 | AC-21；US-01、US-02、US-08 / BR-19；API-01—API-09 / 全部引用与级联；角色 TD-02.roles.administrator |
| 前置条件 | 完成9.1通用前提；关闭 Q-10、Q-12、Q-15；每个子场景独立还原，不能沿用上一子场景的修改 |
| 具体数据 | TD-01、TD-07；账号101 存在当前关联；删除前检查后并发加入引用 |
| 操作步骤 | 在事务隔离测试中调用 API-01[删除]，对照无引用对象；核对应用、委托、令牌及审计 |
| 预期结果与禁止副作用 | 按批准策略拒绝或一致处理；无半删除/孤立引用；权限组删除不能意外删除应用凭据；审计按保留策略保留。 HTTP/业务码依9.1分列；非本例目标对象、凭据与授权关系不得附带变化。 |
| 清理/重跑 | 保存脱敏证据，按ID映射只清理本例生成对象并恢复初始字段/版本；关系先子后父；不清共享审计；步骤见9.5 |
| 实际执行 | 阻断；实际结果/环境/构建版本/执行人/时间/证据均无；拟证据目录 validation/business/TC-21-001/ |

#### TC-21-002：组织11 被引用删除

| 项目 | 执行定义 |
| --- | --- |
| 关联与角色 | AC-21；US-01、US-02、US-08 / BR-19；API-01—API-09 / 全部引用与级联；角色 TD-02.roles.administrator |
| 前置条件 | 完成9.1通用前提；关闭 Q-10、Q-12、Q-15；每个子场景独立还原，不能沿用上一子场景的修改 |
| 具体数据 | TD-01、TD-07；组织11 存在当前关联；删除前检查后并发加入引用 |
| 操作步骤 | 在事务隔离测试中调用 API-02[删除]，对照无引用对象；核对应用、委托、令牌及审计 |
| 预期结果与禁止副作用 | 按批准策略拒绝或一致处理；无半删除/孤立引用；权限组删除不能意外删除应用凭据；审计按保留策略保留。 HTTP/业务码依9.1分列；非本例目标对象、凭据与授权关系不得附带变化。 |
| 清理/重跑 | 保存脱敏证据，按ID映射只清理本例生成对象并恢复初始字段/版本；关系先子后父；不清共享审计；步骤见9.5 |
| 实际执行 | 阻断；实际结果/环境/构建版本/执行人/时间/证据均无；拟证据目录 validation/business/TC-21-002/ |

#### TC-21-003：权限组401 被引用删除

| 项目 | 执行定义 |
| --- | --- |
| 关联与角色 | AC-21；US-01、US-02、US-08 / BR-19；API-01—API-09 / 全部引用与级联；角色 TD-02.roles.administrator |
| 前置条件 | 完成9.1通用前提；关闭 Q-10、Q-12、Q-15；每个子场景独立还原，不能沿用上一子场景的修改 |
| 具体数据 | TD-01、TD-07；权限组401 存在当前关联；删除前检查后并发加入引用 |
| 操作步骤 | 在事务隔离测试中调用 API-07[删除]，对照无引用对象；核对应用、委托、令牌及审计 |
| 预期结果与禁止副作用 | 按批准策略拒绝或一致处理；无半删除/孤立引用；权限组删除不能意外删除应用凭据；审计按保留策略保留。 HTTP/业务码依9.1分列；非本例目标对象、凭据与授权关系不得附带变化。 |
| 清理/重跑 | 保存脱敏证据，按ID映射只清理本例生成对象并恢复初始字段/版本；关系先子后父；不清共享审计；步骤见9.5 |
| 实际执行 | 阻断；实际结果/环境/构建版本/执行人/时间/证据均无；拟证据目录 validation/business/TC-21-003/ |

#### TC-22-001：四类事件与脱敏追加

| 项目 | 执行定义 |
| --- | --- |
| 关联与角色 | AC-22；US-13 / BR-21、BR-22；API-13 / DB-03、DB-16；角色 TD-02.roles.administrator |
| 前置条件 | 完成9.1通用前提；关闭 Q-09、Q-15；每个子场景独立还原，不能沿用上一子场景的修改 |
| 具体数据 | TD-01、TD-02、TD-09；静态允许、委托执行、未认证拒绝、业务失败；auditTrace；TD-09.sensitiveMarkers |
| 操作步骤 | 通过可信写入方 API-13[新增]记录各阶段，按 trace 查询详情/列表 |
| 预期结果与禁止副作用 | 执行人为实际grantee103，grantor101单列候选；阶段与结果可区分；未知主体不伪造0号账号；敏感标记不在日志。 HTTP/业务码依9.1分列；非本例目标对象、凭据与授权关系不得附带变化。 |
| 清理/重跑 | 保存脱敏证据，按ID映射只清理本例生成对象并恢复初始字段/版本；关系先子后父；不清共享审计；步骤见9.5 |
| 实际执行 | 阻断；实际结果/环境/构建版本/执行人/时间/证据均无；拟证据目录 validation/business/TC-22-001/ |

#### TC-22-002：审计读写越权

| 项目 | 执行定义 |
| --- | --- |
| 关联与角色 | AC-22；US-13 / BR-21、BR-22；API-13 / DB-03、DB-16；角色 TD-02.roles.staticUser |
| 前置条件 | 完成9.1通用前提；关闭 Q-09、Q-15；每个子场景独立还原，不能沿用上一子场景的修改 |
| 具体数据 | TD-01、TD-02；普通成员102及未获该应用日志权限的审计员；日志1001 |
| 操作步骤 | 尝试伪造追加、查他应用日志、篡改/删除日志 |
| 预期结果与禁止副作用 | 拒绝未经授权行为；不存在普通用户编辑/删除日志入口；不改变原审计。 HTTP/业务码依9.1分列；非本例目标对象、凭据与授权关系不得附带变化。 |
| 清理/重跑 | 保存脱敏证据，按ID映射只清理本例生成对象并恢复初始字段/版本；关系先子后父；不清共享审计；步骤见9.5 |
| 实际执行 | 阻断；实际结果/环境/构建版本/执行人/时间/证据均无；拟证据目录 validation/business/TC-22-002/ |

#### TC-23-001：归档恢复与重复批次

| 项目 | 执行定义 |
| --- | --- |
| 关联与角色 | AC-23；US-13 / BR-23；API-13 / 分区/归档候选记录；角色 TD-02.roles.administrator |
| 前置条件 | 完成9.1通用前提；关闭 Q-09、Q-13、Q-15；每个子场景独立还原，不能沿用上一子场景的修改 |
| 具体数据 | TD-01、TD-09、TD-10；archiveBatch；批准保留期和隔离副本；按源记录id/时间/计数保存清单 |
| 操作步骤 | API-13[自动归档]调度同批次两次；抽样恢复并按ID/计数/内容哈希比对 |
| 预期结果与禁止副作用 | 完整性与可恢复性验证后才处理原数据；重复不重复删除或重复归档；默认分区存在不等于已归档。 HTTP/业务码依9.1分列；非本例目标对象、凭据与授权关系不得附带变化。 |
| 清理/重跑 | 保存脱敏证据，按ID映射只清理本例生成对象并恢复初始字段/版本；关系先子后父；不清共享审计；步骤见9.5 |
| 实际执行 | 阻断；实际结果/环境/构建版本/执行人/时间/证据均无；拟证据目录 validation/business/TC-23-001/ |

#### TC-24-001：开放详情与权限限制

| 项目 | 执行定义 |
| --- | --- |
| 关联与角色 | AC-24；US-14 / BR-24、BR-25；API-14 / 用户字段白名单；角色 TD-02.roles.staticUser |
| 前置条件 | 完成9.1通用前提；关闭 Q-01、Q-15；每个子场景独立还原，不能沿用上一子场景的修改 |
| 具体数据 | TD-01、TD-02；app501/app502；目标102/103；并尝试任意userId=999999 |
| 操作步骤 | 分别 API-14[获取用户详情/获取用户权限]；切换应用与目标 |
| 预期结果与禁止副作用 | 只返回批准目标及当前应用操作和字段；不包含密码散列/AppSecret/完整令牌；权限列表不是资源执行许可。 HTTP/业务码依9.1分列；非本例目标对象、凭据与授权关系不得附带变化。 |
| 清理/重跑 | 保存脱敏证据，按ID映射只清理本例生成对象并恢复初始字段/版本；关系先子后父；不清共享审计；步骤见9.5 |
| 实际执行 | 阻断；实际结果/环境/构建版本/执行人/时间/证据均无；拟证据目录 validation/business/TC-24-001/ |

#### TC-24-002：开放获取令牌复用签发

| 项目 | 执行定义 |
| --- | --- |
| 关联与角色 | AC-24；US-14 / BR-24、BR-25；API-14 / 用户字段白名单；角色 TD-02.roles.staticUser |
| 前置条件 | 完成9.1通用前提；关闭 Q-01、Q-15；每个子场景独立还原，不能沿用上一子场景的修改 |
| 具体数据 | TD-01、TD-02、TD-04；account102；app501；批准认证上下文 |
| 操作步骤 | API-14[获取令牌]与API-10[登录]对照，开放刷新/注销复用TC-18/TC-19 |
| 预期结果与禁止副作用 | 同一生命周期与主体/应用限制；不产生绕过服务账号限制或独立失效规则的令牌。 HTTP/业务码依9.1分列；非本例目标对象、凭据与授权关系不得附带变化。 |
| 清理/重跑 | 保存脱敏证据，按ID映射只清理本例生成对象并恢复初始字段/版本；关系先子后父；不清共享审计；步骤见9.5 |
| 实际执行 | 阻断；实际结果/环境/构建版本/执行人/时间/证据均无；拟证据目录 validation/business/TC-24-002/ |

#### TC-25-001：权限/应用/委托陈旧版本编辑

| 项目 | 执行定义 |
| --- | --- |
| 关联与角色 | AC-25；US-08、US-11、US-12 / BR-26、BR-27；API-07、API-11、API-16 / 版本机制；角色 TD-02.roles.administrator |
| 前置条件 | 完成9.1通用前提；关闭 Q-12、Q-15；每个子场景独立还原，不能沿用上一子场景的修改 |
| 具体数据 | TD-01、TD-07；组401、应用501、委托601 三组分别readVersion=7；requestA/B |
| 操作步骤 | 每组两个会话读取v7；A先提交，B提交旧v7；检查页面未提交输入和当前详情 |
| 预期结果与禁止副作用 | A成功后B冲突，B表单保留供比较；不静默覆盖A、不丢失其他字段；实际版本存储待Q-12。 HTTP/业务码依9.1分列；非本例目标对象、凭据与授权关系不得附带变化。 |
| 清理/重跑 | 保存脱敏证据，按ID映射只清理本例生成对象并恢复初始字段/版本；关系先子后父；不清共享审计；步骤见9.5 |
| 实际执行 | 阻断；实际结果/环境/构建版本/执行人/时间/证据均无；拟证据目录 validation/business/TC-25-001/ |

#### TC-26-001：委托时刻 beforeFrom

| 项目 | 执行定义 |
| --- | --- |
| 关联与角色 | AC-26；US-04、US-12 / BR-06、BR-28；API-10—API-12 / 时间约束；角色 TD-02.roles.delegatedUser |
| 前置条件 | 完成9.1通用前提；关闭 Q-06、Q-11、Q-15；每个子场景独立还原，不能沿用上一子场景的修改 |
| 具体数据 | TD-01、TD-02、TD-06；委托601 active；account103；无静态权限；now=TD-06.beforeFrom |
| 操作步骤 | 通过已批准测试时钟适配设置now；鉴权dev-001；暂停过期标记任务重复核对 |
| 预期结果与禁止副作用 | 拒绝；闭区间边界不变，不能依赖任务先把status改成expired；认证/资源等其他条件保持匹配。 HTTP/业务码依9.1分列；非本例目标对象、凭据与授权关系不得附带变化。 |
| 清理/重跑 | 保存脱敏证据，按ID映射只清理本例生成对象并恢复初始字段/版本；关系先子后父；不清共享审计；步骤见9.5 |
| 实际执行 | 阻断；实际结果/环境/构建版本/执行人/时间/证据均无；拟证据目录 validation/business/TC-26-001/ |

#### TC-26-002：委托时刻 atFrom

| 项目 | 执行定义 |
| --- | --- |
| 关联与角色 | AC-26；US-04、US-12 / BR-06、BR-28；API-10—API-12 / 时间约束；角色 TD-02.roles.delegatedUser |
| 前置条件 | 完成9.1通用前提；关闭 Q-06、Q-11、Q-15；每个子场景独立还原，不能沿用上一子场景的修改 |
| 具体数据 | TD-01、TD-02、TD-06；委托601 active；account103；无静态权限；now=TD-06.atFrom |
| 操作步骤 | 通过已批准测试时钟适配设置now；鉴权dev-001；暂停过期标记任务重复核对 |
| 预期结果与禁止副作用 | 允许；闭区间边界不变，不能依赖任务先把status改成expired；认证/资源等其他条件保持匹配。 HTTP/业务码依9.1分列；非本例目标对象、凭据与授权关系不得附带变化。 |
| 清理/重跑 | 保存脱敏证据，按ID映射只清理本例生成对象并恢复初始字段/版本；关系先子后父；不清共享审计；步骤见9.5 |
| 实际执行 | 阻断；实际结果/环境/构建版本/执行人/时间/证据均无；拟证据目录 validation/business/TC-26-002/ |

#### TC-26-003：委托时刻 atUntil

| 项目 | 执行定义 |
| --- | --- |
| 关联与角色 | AC-26；US-04、US-12 / BR-06、BR-28；API-10—API-12 / 时间约束；角色 TD-02.roles.delegatedUser |
| 前置条件 | 完成9.1通用前提；关闭 Q-06、Q-11、Q-15；每个子场景独立还原，不能沿用上一子场景的修改 |
| 具体数据 | TD-01、TD-02、TD-06；委托601 active；account103；无静态权限；now=TD-06.atUntil |
| 操作步骤 | 通过已批准测试时钟适配设置now；鉴权dev-001；暂停过期标记任务重复核对 |
| 预期结果与禁止副作用 | 允许；闭区间边界不变，不能依赖任务先把status改成expired；认证/资源等其他条件保持匹配。 HTTP/业务码依9.1分列；非本例目标对象、凭据与授权关系不得附带变化。 |
| 清理/重跑 | 保存脱敏证据，按ID映射只清理本例生成对象并恢复初始字段/版本；关系先子后父；不清共享审计；步骤见9.5 |
| 实际执行 | 阻断；实际结果/环境/构建版本/执行人/时间/证据均无；拟证据目录 validation/business/TC-26-003/ |

#### TC-26-004：委托时刻 afterUntil

| 项目 | 执行定义 |
| --- | --- |
| 关联与角色 | AC-26；US-04、US-12 / BR-06、BR-28；API-10—API-12 / 时间约束；角色 TD-02.roles.delegatedUser |
| 前置条件 | 完成9.1通用前提；关闭 Q-06、Q-11、Q-15；每个子场景独立还原，不能沿用上一子场景的修改 |
| 具体数据 | TD-01、TD-02、TD-06；委托601 active；account103；无静态权限；now=TD-06.afterUntil |
| 操作步骤 | 通过已批准测试时钟适配设置now；鉴权dev-001；暂停过期标记任务重复核对 |
| 预期结果与禁止副作用 | 拒绝；闭区间边界不变，不能依赖任务先把status改成expired；认证/资源等其他条件保持匹配。 HTTP/业务码依9.1分列；非本例目标对象、凭据与授权关系不得附带变化。 |
| 清理/重跑 | 保存脱敏证据，按ID映射只清理本例生成对象并恢复初始字段/版本；关系先子后父；不清共享审计；步骤见9.5 |
| 实际执行 | 阻断；实际结果/环境/构建版本/执行人/时间/证据均无；拟证据目录 validation/business/TC-26-004/ |

#### TC-26-005：时区等价与逆序区间

| 项目 | 执行定义 |
| --- | --- |
| 关联与角色 | AC-26；US-04、US-12 / BR-06、BR-28；API-10—API-12 / 时间约束；角色 TD-02.roles.delegatedUser |
| 前置条件 | 完成9.1通用前提；关闭 Q-06、Q-11、Q-15；每个子场景独立还原，不能沿用上一子场景的修改 |
| 具体数据 | TD-01、TD-06；00:30Z 与08:30+08:00；反例validFrom>end |
| 操作步骤 | 以等价时刻分别验证；另提交逆序有效期申请 |
| 预期结果与禁止副作用 | 等价时刻结论一致；逆序区间拒绝且不创建记录；TIMESTAMP装载时区由Q-11批准。 HTTP/业务码依9.1分列；非本例目标对象、凭据与授权关系不得附带变化。 |
| 清理/重跑 | 保存脱敏证据，按ID映射只清理本例生成对象并恢复初始字段/版本；关系先子后父；不清共享审计；步骤见9.5 |
| 实际执行 | 阻断；实际结果/环境/构建版本/执行人/时间/证据均无；拟证据目录 validation/business/TC-26-005/ |

#### TC-27-001：依赖故障 permission-source-timeout

| 项目 | 执行定义 |
| --- | --- |
| 关联与角色 | AC-27；US-11、US-13 / BR-29；API-11、API-13 / 故障策略；角色 TD-02.roles.administrator |
| 前置条件 | 完成9.1通用前提；关闭 Q-08、Q-09、Q-15；每个子场景独立还原，不能沿用上一子场景的修改 |
| 具体数据 | TD-01、TD-09；TD-09.faults 中 permission-source-timeout；保留已允许缓存对照 |
| 操作步骤 | 在受控测试适配注入单一故障，发起鉴权/高风险写，恢复后重试一次 |
| 预期结果与禁止副作用 | 权限不确定不放行；审计失败按批准阻断或可靠补记策略，不宣称已审计；恢复不能重复执行业务。 HTTP/业务码依9.1分列；非本例目标对象、凭据与授权关系不得附带变化。 |
| 清理/重跑 | 保存脱敏证据，按ID映射只清理本例生成对象并恢复初始字段/版本；关系先子后父；不清共享审计；步骤见9.5 |
| 实际执行 | 阻断；实际结果/环境/构建版本/执行人/时间/证据均无；拟证据目录 validation/business/TC-27-001/ |

#### TC-27-002：依赖故障 cache-unavailable

| 项目 | 执行定义 |
| --- | --- |
| 关联与角色 | AC-27；US-11、US-13 / BR-29；API-11、API-13 / 故障策略；角色 TD-02.roles.administrator |
| 前置条件 | 完成9.1通用前提；关闭 Q-08、Q-09、Q-15；每个子场景独立还原，不能沿用上一子场景的修改 |
| 具体数据 | TD-01、TD-09；TD-09.faults 中 cache-unavailable；保留已允许缓存对照 |
| 操作步骤 | 在受控测试适配注入单一故障，发起鉴权/高风险写，恢复后重试一次 |
| 预期结果与禁止副作用 | 权限不确定不放行；审计失败按批准阻断或可靠补记策略，不宣称已审计；恢复不能重复执行业务。 HTTP/业务码依9.1分列；非本例目标对象、凭据与授权关系不得附带变化。 |
| 清理/重跑 | 保存脱敏证据，按ID映射只清理本例生成对象并恢复初始字段/版本；关系先子后父；不清共享审计；步骤见9.5 |
| 实际执行 | 阻断；实际结果/环境/构建版本/执行人/时间/证据均无；拟证据目录 validation/business/TC-27-002/ |

#### TC-27-003：依赖故障 audit-write-failure

| 项目 | 执行定义 |
| --- | --- |
| 关联与角色 | AC-27；US-11、US-13 / BR-29；API-11、API-13 / 故障策略；角色 TD-02.roles.administrator |
| 前置条件 | 完成9.1通用前提；关闭 Q-08、Q-09、Q-15；每个子场景独立还原，不能沿用上一子场景的修改 |
| 具体数据 | TD-01、TD-09；TD-09.faults 中 audit-write-failure；保留已允许缓存对照 |
| 操作步骤 | 在受控测试适配注入单一故障，发起鉴权/高风险写，恢复后重试一次 |
| 预期结果与禁止副作用 | 权限不确定不放行；审计失败按批准阻断或可靠补记策略，不宣称已审计；恢复不能重复执行业务。 HTTP/业务码依9.1分列；非本例目标对象、凭据与授权关系不得附带变化。 |
| 清理/重跑 | 保存脱敏证据，按ID映射只清理本例生成对象并恢复初始字段/版本；关系先子后父；不清共享审计；步骤见9.5 |
| 实际执行 | 阻断；实际结果/环境/构建版本/执行人/时间/证据均无；拟证据目录 validation/business/TC-27-003/ |

#### TC-28-001：长度边界与字段空值

| 项目 | 执行定义 |
| --- | --- |
| 关联与角色 | AC-28；US-01—US-14 / BR-25、BR-26；API-01—API-17 / 全部适用字段约束；角色 TD-02.roles.administrator |
| 前置条件 | 完成9.1通用前提；关闭 Q-01、Q-12、Q-14、Q-15；每个子场景独立还原，不能沿用上一子场景的修改 |
| 具体数据 | TD-01、TD-05；username64/65；name128/129；text512/513；remark缺失/null/空串；JSON[]/null/错误对象 |
| 操作步骤 | 按第三章将每组投到适用字段；每次还原初始值，分别新增和编辑并核对字段结果 |
| 预期结果与禁止副作用 | 恰好声明长度允许、超限拒绝；不可空字段拒绝null；缺失是否保留按Q-12；参数值与字典结构按Q-14独立判定；失败原值不变。 HTTP/业务码依9.1分列；非本例目标对象、凭据与授权关系不得附带变化。 |
| 清理/重跑 | 保存脱敏证据，按ID映射只清理本例生成对象并恢复初始字段/版本；关系先子后父；不清共享审计；步骤见9.5 |
| 实际执行 | 阻断；实际结果/环境/构建版本/执行人/时间/证据均无；拟证据目录 validation/business/TC-28-001/ |

#### TC-28-002：大ID与排序/文本注入

| 项目 | 执行定义 |
| --- | --- |
| 关联与角色 | AC-28；US-01—US-14 / BR-25、BR-26；API-01—API-17 / 全部适用字段约束；角色 TD-02.roles.administrator |
| 前置条件 | 完成9.1通用前提；关闭 Q-01、Q-12、Q-14、Q-15；每个子场景独立还原，不能沿用上一子场景的修改 |
| 具体数据 | TD-01、TD-05；largeId=9007199254740993；invalidSort；htmlText；readonly |
| 操作步骤 | 检查请求/响应ID逐字往返；将非法排序作为值提交；将HTML文本通过获准字段显示；尝试覆盖服务端字段 |
| 预期结果与禁止副作用 | 大ID不转为有精度损失的JS数值；非法排序不执行SQL；纯文本不产生标签或外部请求；服务端字段不可覆盖。 HTTP/业务码依9.1分列；非本例目标对象、凭据与授权关系不得附带变化。 |
| 清理/重跑 | 保存脱敏证据，按ID映射只清理本例生成对象并恢复初始字段/版本；关系先子后父；不清共享审计；步骤见9.5 |
| 实际执行 | 阻断；实际结果/环境/构建版本/执行人/时间/证据均无；拟证据目录 validation/business/TC-28-002/ |

#### TC-29-001：DDL修订前置与空库初始化

| 项目 | 执行定义 |
| --- | --- |
| 关联与角色 | AC-29；US-01—US-14 / BR-08、BR-19、BR-28；适用全部 API / DB-01—DB-18；角色 TD-02.roles.administrator |
| 前置条件 | 完成9.1通用前提；关闭 Q-16；每个子场景独立还原，不能沿用上一子场景的修改 |
| 具体数据 | TD-01、TD-10；原DDL含10处缺逗号、重复idx_token_account_id、audit_log分区主键问题 |
| 操作步骤 | 先核对DB-01～03修订证据；DBA在批准版本隔离库执行修订DDL，再核对14表与约束 |
| 预期结果与禁止副作用 | 原稿不能直接当建库成功；修订版实际建立后方可通过；字段/外键/JSON/时区与批准方案一致。 HTTP/业务码依9.1分列；非本例目标对象、凭据与授权关系不得附带变化。 |
| 清理/重跑 | 保存脱敏证据，按ID映射只清理本例生成对象并恢复初始字段/版本；关系先子后父；不清共享审计；步骤见9.5 |
| 实际执行 | 阻断；实际结果/环境/构建版本/执行人/时间/证据均无；拟证据目录 validation/business/TC-29-001/ |

#### TC-29-002：非法约束与序列/迁移恢复

| 项目 | 执行定义 |
| --- | --- |
| 关联与角色 | AC-29；US-01—US-14 / BR-08、BR-19、BR-28；适用全部 API / DB-01—DB-18；角色 TD-02.roles.administrator |
| 前置条件 | 完成9.1通用前提；关闭 Q-16；每个子场景独立还原，不能沿用上一子场景的修改 |
| 具体数据 | TD-01、TD-05、TD-10；重复username；重复用户/组组合；无效外键999999；显式主键后再插入；批准旧库结构副本 |
| 操作步骤 | 隔离库逐项验证拒绝；再执行版本化迁移、中断恢复和记录/哈希对照 |
| 预期结果与禁止副作用 | 拒绝非法行、序列不撞键，存量/恢复计数与内容符合批准迁移；没有真实旧库快照时迁移项阻断。 HTTP/业务码依9.1分列；非本例目标对象、凭据与授权关系不得附带变化。 |
| 清理/重跑 | 保存脱敏证据，按ID映射只清理本例生成对象并恢复初始字段/版本；关系先子后父；不清共享审计；步骤见9.5 |
| 实际执行 | 阻断；实际结果/环境/构建版本/执行人/时间/证据均无；拟证据目录 validation/business/TC-29-002/ |

#### TC-30-001：性能与撤权/归档运行指标

| 项目 | 执行定义 |
| --- | --- |
| 关联与角色 | AC-30；US-11、US-13 / BR-17、BR-23、BR-29；API-11、API-13 / 索引与分区；角色 TD-02.roles.administrator |
| 前置条件 | 完成9.1通用前提；关闭 Q-08、Q-09、Q-13、Q-15；每个子场景独立还原，不能沿用上一子场景的修改 |
| 具体数据 | TD-03、TD-09、TD-10；resource-count可设10000；基线4条不代表负载；Q-13批准规模/分布/并发/阈值/RTO/RPO |
| 操作步骤 | 记录环境、预热、采样窗口；测鉴权P95/P99/错误率、撤权时延、归档延迟与恢复指标 |
| 预期结果与禁止副作用 | 每项与批准阈值比较；未定阈值/分布/环境时阻断；本地生成10000条数据不构成性能通过。 HTTP/业务码依9.1分列；非本例目标对象、凭据与授权关系不得附带变化。 |
| 清理/重跑 | 保存脱敏证据，按ID映射只清理本例生成对象并恢复初始字段/版本；关系先子后父；不清共享审计；步骤见9.5 |
| 实际执行 | 阻断；实际结果/环境/构建版本/执行人/时间/证据均无；拟证据目录 validation/business/TC-30-001/ |

#### TC-09-007：account：[*] —创建账号→ normal

| 项目 | 执行定义 |
| --- | --- |
| 关联与角色 | AC-09；US-01 / BR-08、BR-25、BR-26；API-01 / 账号唯一约束；角色 TD-02.roles.administrator |
| 前置条件 | 完成9.1通用前提；关闭 Q-05、Q-08、Q-12、Q-15；每个子场景独立还原，不能沿用上一子场景的修改 |
| 具体数据 | TD-01、TD-02、TD-06、TD-08、TD-09；TD-08.account[0]；恢复当前状态=[*]；版本/时间/授权前提按第六章对应行 |
| 操作步骤 | 1. 按对应状态表准备身份、初态和时间。2. 通过批准的事件入口触发 创建账号。3. 查询状态/关联对象及适用审计；失败分支另恢复初态后注入前提不满足。 |
| 预期结果与禁止副作用 | 目标状态为 normal，副作用/失败处理逐项符合第六章该行；失败不能谎称转换成功，自循环不得恢复终态有效。 HTTP/业务码依9.1分列；非本例目标对象、凭据与授权关系不得附带变化。 |
| 清理/重跑 | 保存脱敏证据，按ID映射只清理本例生成对象并恢复初始字段/版本；关系先子后父；不清共享审计；步骤见9.5 |
| 实际执行 | 阻断；实际结果/环境/构建版本/执行人/时间/证据均无；拟证据目录 validation/business/TC-09-007/ |

#### TC-09-008：account：normal —冻结账号→ frozen

| 项目 | 执行定义 |
| --- | --- |
| 关联与角色 | AC-09；US-01 / BR-08、BR-25、BR-26；API-01 / 账号唯一约束；角色 TD-02.roles.administrator |
| 前置条件 | 完成9.1通用前提；关闭 Q-05、Q-08、Q-12、Q-15；每个子场景独立还原，不能沿用上一子场景的修改 |
| 具体数据 | TD-01、TD-02、TD-06、TD-08、TD-09；TD-08.account[1]；恢复当前状态=normal；版本/时间/授权前提按第六章对应行 |
| 操作步骤 | 1. 按对应状态表准备身份、初态和时间。2. 通过批准的事件入口触发 冻结账号。3. 查询状态/关联对象及适用审计；失败分支另恢复初态后注入前提不满足。 |
| 预期结果与禁止副作用 | 目标状态为 frozen，副作用/失败处理逐项符合第六章该行；失败不能谎称转换成功，自循环不得恢复终态有效。 HTTP/业务码依9.1分列；非本例目标对象、凭据与授权关系不得附带变化。 |
| 清理/重跑 | 保存脱敏证据，按ID映射只清理本例生成对象并恢复初始字段/版本；关系先子后父；不清共享审计；步骤见9.5 |
| 实际执行 | 阻断；实际结果/环境/构建版本/执行人/时间/证据均无；拟证据目录 validation/business/TC-09-008/ |

#### TC-09-009：account：frozen —解冻账号→ normal

| 项目 | 执行定义 |
| --- | --- |
| 关联与角色 | AC-09；US-01 / BR-08、BR-25、BR-26；API-01 / 账号唯一约束；角色 TD-02.roles.administrator |
| 前置条件 | 完成9.1通用前提；关闭 Q-05、Q-08、Q-12、Q-15；每个子场景独立还原，不能沿用上一子场景的修改 |
| 具体数据 | TD-01、TD-02、TD-06、TD-08、TD-09；TD-08.account[2]；恢复当前状态=frozen；版本/时间/授权前提按第六章对应行 |
| 操作步骤 | 1. 按对应状态表准备身份、初态和时间。2. 通过批准的事件入口触发 解冻账号。3. 查询状态/关联对象及适用审计；失败分支另恢复初态后注入前提不满足。 |
| 预期结果与禁止副作用 | 目标状态为 normal，副作用/失败处理逐项符合第六章该行；失败不能谎称转换成功，自循环不得恢复终态有效。 HTTP/业务码依9.1分列；非本例目标对象、凭据与授权关系不得附带变化。 |
| 清理/重跑 | 保存脱敏证据，按ID映射只清理本例生成对象并恢复初始字段/版本；关系先子后父；不清共享审计；步骤见9.5 |
| 实际执行 | 阻断；实际结果/环境/构建版本/执行人/时间/证据均无；拟证据目录 validation/business/TC-09-009/ |

#### TC-15-004：app：[*] —注册应用→ active

| 项目 | 执行定义 |
| --- | --- |
| 关联与角色 | AC-15；US-11 / BR-03、BR-13；API-11 / 应用组和 app 唯一；角色 TD-02.roles.administrator |
| 前置条件 | 完成9.1通用前提；关闭 Q-05、Q-08、Q-12、Q-15；每个子场景独立还原，不能沿用上一子场景的修改 |
| 具体数据 | TD-01、TD-02、TD-06、TD-08、TD-09；TD-08.app[0]；恢复当前状态=[*]；版本/时间/授权前提按第六章对应行 |
| 操作步骤 | 1. 按对应状态表准备身份、初态和时间。2. 通过批准的事件入口触发 注册应用。3. 查询状态/关联对象及适用审计；失败分支另恢复初态后注入前提不满足。 |
| 预期结果与禁止副作用 | 目标状态为 active，副作用/失败处理逐项符合第六章该行；失败不能谎称转换成功，自循环不得恢复终态有效。 HTTP/业务码依9.1分列；非本例目标对象、凭据与授权关系不得附带变化。 |
| 清理/重跑 | 保存脱敏证据，按ID映射只清理本例生成对象并恢复初始字段/版本；关系先子后父；不清共享审计；步骤见9.5 |
| 实际执行 | 阻断；实际结果/环境/构建版本/执行人/时间/证据均无；拟证据目录 validation/business/TC-15-004/ |

#### TC-15-005：app：active —冻结应用→ frozen

| 项目 | 执行定义 |
| --- | --- |
| 关联与角色 | AC-15；US-11 / BR-03、BR-13；API-11 / 应用组和 app 唯一；角色 TD-02.roles.administrator |
| 前置条件 | 完成9.1通用前提；关闭 Q-05、Q-08、Q-12、Q-15；每个子场景独立还原，不能沿用上一子场景的修改 |
| 具体数据 | TD-01、TD-02、TD-06、TD-08、TD-09；TD-08.app[1]；恢复当前状态=active；版本/时间/授权前提按第六章对应行 |
| 操作步骤 | 1. 按对应状态表准备身份、初态和时间。2. 通过批准的事件入口触发 冻结应用。3. 查询状态/关联对象及适用审计；失败分支另恢复初态后注入前提不满足。 |
| 预期结果与禁止副作用 | 目标状态为 frozen，副作用/失败处理逐项符合第六章该行；失败不能谎称转换成功，自循环不得恢复终态有效。 HTTP/业务码依9.1分列；非本例目标对象、凭据与授权关系不得附带变化。 |
| 清理/重跑 | 保存脱敏证据，按ID映射只清理本例生成对象并恢复初始字段/版本；关系先子后父；不清共享审计；步骤见9.5 |
| 实际执行 | 阻断；实际结果/环境/构建版本/执行人/时间/证据均无；拟证据目录 validation/business/TC-15-005/ |

#### TC-15-006：app：frozen —解冻应用→ active

| 项目 | 执行定义 |
| --- | --- |
| 关联与角色 | AC-15；US-11 / BR-03、BR-13；API-11 / 应用组和 app 唯一；角色 TD-02.roles.administrator |
| 前置条件 | 完成9.1通用前提；关闭 Q-05、Q-08、Q-12、Q-15；每个子场景独立还原，不能沿用上一子场景的修改 |
| 具体数据 | TD-01、TD-02、TD-06、TD-08、TD-09；TD-08.app[2]；恢复当前状态=frozen；版本/时间/授权前提按第六章对应行 |
| 操作步骤 | 1. 按对应状态表准备身份、初态和时间。2. 通过批准的事件入口触发 解冻应用。3. 查询状态/关联对象及适用审计；失败分支另恢复初态后注入前提不满足。 |
| 预期结果与禁止副作用 | 目标状态为 active，副作用/失败处理逐项符合第六章该行；失败不能谎称转换成功，自循环不得恢复终态有效。 HTTP/业务码依9.1分列；非本例目标对象、凭据与授权关系不得附带变化。 |
| 清理/重跑 | 保存脱敏证据，按ID映射只清理本例生成对象并恢复初始字段/版本；关系先子后父；不清共享审计；步骤见9.5 |
| 实际执行 | 阻断；实际结果/环境/构建版本/执行人/时间/证据均无；拟证据目录 validation/business/TC-15-006/ |

#### TC-17-003：token：[*] —签发成功→ valid

| 项目 | 执行定义 |
| --- | --- |
| 关联与角色 | AC-17；US-04 / BR-02、BR-15；API-10、API-17 / token 类型与 scene；角色 TD-02.roles.administrator |
| 前置条件 | 完成9.1通用前提；关闭 Q-06、Q-11、Q-12、Q-15；每个子场景独立还原，不能沿用上一子场景的修改 |
| 具体数据 | TD-01、TD-02、TD-06、TD-08、TD-09；TD-08.token[0]；恢复当前状态=[*]；版本/时间/授权前提按第六章对应行 |
| 操作步骤 | 1. 按对应状态表准备身份、初态和时间。2. 通过批准的事件入口触发 签发成功。3. 查询状态/关联对象及适用审计；失败分支另恢复初态后注入前提不满足。 |
| 预期结果与禁止副作用 | 目标状态为 valid，副作用/失败处理逐项符合第六章该行；失败不能谎称转换成功，自循环不得恢复终态有效。 HTTP/业务码依9.1分列；非本例目标对象、凭据与授权关系不得附带变化。 |
| 清理/重跑 | 保存脱敏证据，按ID映射只清理本例生成对象并恢复初始字段/版本；关系先子后父；不清共享审计；步骤见9.5 |
| 实际执行 | 阻断；实际结果/环境/构建版本/执行人/时间/证据均无；拟证据目录 validation/business/TC-17-003/ |

#### TC-18-003：token：valid —刷新轮换成功→ consumed

| 项目 | 执行定义 |
| --- | --- |
| 关联与角色 | AC-18；US-04、US-14 / BR-16、BR-30；API-10、API-14 / 轮换原子约束；角色 TD-02.roles.administrator |
| 前置条件 | 完成9.1通用前提；关闭 Q-06、Q-11、Q-12、Q-15；每个子场景独立还原，不能沿用上一子场景的修改 |
| 具体数据 | TD-01、TD-02、TD-06、TD-08、TD-09；TD-08.token[1]；恢复当前状态=valid；版本/时间/授权前提按第六章对应行 |
| 操作步骤 | 1. 按对应状态表准备身份、初态和时间。2. 通过批准的事件入口触发 刷新轮换成功。3. 查询状态/关联对象及适用审计；失败分支另恢复初态后注入前提不满足。 |
| 预期结果与禁止副作用 | 目标状态为 consumed，副作用/失败处理逐项符合第六章该行；失败不能谎称转换成功，自循环不得恢复终态有效。 HTTP/业务码依9.1分列；非本例目标对象、凭据与授权关系不得附带变化。 |
| 清理/重跑 | 保存脱敏证据，按ID映射只清理本例生成对象并恢复初始字段/版本；关系先子后父；不清共享审计；步骤见9.5 |
| 实际执行 | 阻断；实际结果/环境/构建版本/执行人/时间/证据均无；拟证据目录 validation/business/TC-18-003/ |

#### TC-17-004：token：valid —到达过期阈值→ expired

| 项目 | 执行定义 |
| --- | --- |
| 关联与角色 | AC-17；US-04 / BR-02、BR-15；API-10、API-17 / token 类型与 scene；角色 TD-02.roles.administrator |
| 前置条件 | 完成9.1通用前提；关闭 Q-06、Q-11、Q-12、Q-15；每个子场景独立还原，不能沿用上一子场景的修改 |
| 具体数据 | TD-01、TD-02、TD-06、TD-08、TD-09；TD-08.token[2]；恢复当前状态=valid；版本/时间/授权前提按第六章对应行 |
| 操作步骤 | 1. 按对应状态表准备身份、初态和时间。2. 通过批准的事件入口触发 到达过期阈值。3. 查询状态/关联对象及适用审计；失败分支另恢复初态后注入前提不满足。 |
| 预期结果与禁止副作用 | 目标状态为 expired，副作用/失败处理逐项符合第六章该行；失败不能谎称转换成功，自循环不得恢复终态有效。 HTTP/业务码依9.1分列；非本例目标对象、凭据与授权关系不得附带变化。 |
| 清理/重跑 | 保存脱敏证据，按ID映射只清理本例生成对象并恢复初始字段/版本；关系先子后父；不清共享审计；步骤见9.5 |
| 实际执行 | 阻断；实际结果/环境/构建版本/执行人/时间/证据均无；拟证据目录 validation/business/TC-17-004/ |

#### TC-19-002：token：valid —退出或注销或冻结关联处理→ revoked

| 项目 | 执行定义 |
| --- | --- |
| 关联与角色 | AC-19；US-04、US-14 / BR-17；API-10、API-14 / 撤销集合；角色 TD-02.roles.administrator |
| 前置条件 | 完成9.1通用前提；关闭 Q-06、Q-11、Q-12、Q-15；每个子场景独立还原，不能沿用上一子场景的修改 |
| 具体数据 | TD-01、TD-02、TD-06、TD-08、TD-09；TD-08.token[3]；恢复当前状态=valid；版本/时间/授权前提按第六章对应行 |
| 操作步骤 | 1. 按对应状态表准备身份、初态和时间。2. 通过批准的事件入口触发 退出或注销或冻结关联处理。3. 查询状态/关联对象及适用审计；失败分支另恢复初态后注入前提不满足。 |
| 预期结果与禁止副作用 | 目标状态为 revoked，副作用/失败处理逐项符合第六章该行；失败不能谎称转换成功，自循环不得恢复终态有效。 HTTP/业务码依9.1分列；非本例目标对象、凭据与授权关系不得附带变化。 |
| 清理/重跑 | 保存脱敏证据，按ID映射只清理本例生成对象并恢复初始字段/版本；关系先子后父；不清共享审计；步骤见9.5 |
| 实际执行 | 阻断；实际结果/环境/构建版本/执行人/时间/证据均无；拟证据目录 validation/business/TC-19-002/ |

#### TC-18-004：token：consumed —重放已消费令牌→ consumed

| 项目 | 执行定义 |
| --- | --- |
| 关联与角色 | AC-18；US-04、US-14 / BR-16、BR-30；API-10、API-14 / 轮换原子约束；角色 TD-02.roles.administrator |
| 前置条件 | 完成9.1通用前提；关闭 Q-06、Q-11、Q-12、Q-15；每个子场景独立还原，不能沿用上一子场景的修改 |
| 具体数据 | TD-01、TD-02、TD-06、TD-08、TD-09；TD-08.token[4]；恢复当前状态=consumed；版本/时间/授权前提按第六章对应行 |
| 操作步骤 | 1. 按对应状态表准备身份、初态和时间。2. 通过批准的事件入口触发 重放已消费令牌。3. 查询状态/关联对象及适用审计；失败分支另恢复初态后注入前提不满足。 |
| 预期结果与禁止副作用 | 目标状态为 consumed，副作用/失败处理逐项符合第六章该行；失败不能谎称转换成功，自循环不得恢复终态有效。 HTTP/业务码依9.1分列；非本例目标对象、凭据与授权关系不得附带变化。 |
| 清理/重跑 | 保存脱敏证据，按ID映射只清理本例生成对象并恢复初始字段/版本；关系先子后父；不清共享审计；步骤见9.5 |
| 实际执行 | 阻断；实际结果/环境/构建版本/执行人/时间/证据均无；拟证据目录 validation/business/TC-18-004/ |

#### TC-17-005：token：expired —重复注销或刷新过期令牌→ expired

| 项目 | 执行定义 |
| --- | --- |
| 关联与角色 | AC-17；US-04 / BR-02、BR-15；API-10、API-17 / token 类型与 scene；角色 TD-02.roles.administrator |
| 前置条件 | 完成9.1通用前提；关闭 Q-06、Q-11、Q-12、Q-15；每个子场景独立还原，不能沿用上一子场景的修改 |
| 具体数据 | TD-01、TD-02、TD-06、TD-08、TD-09；TD-08.token[5]；恢复当前状态=expired；版本/时间/授权前提按第六章对应行 |
| 操作步骤 | 1. 按对应状态表准备身份、初态和时间。2. 通过批准的事件入口触发 重复注销或刷新过期令牌。3. 查询状态/关联对象及适用审计；失败分支另恢复初态后注入前提不满足。 |
| 预期结果与禁止副作用 | 目标状态为 expired，副作用/失败处理逐项符合第六章该行；失败不能谎称转换成功，自循环不得恢复终态有效。 HTTP/业务码依9.1分列；非本例目标对象、凭据与授权关系不得附带变化。 |
| 清理/重跑 | 保存脱敏证据，按ID映射只清理本例生成对象并恢复初始字段/版本；关系先子后父；不清共享审计；步骤见9.5 |
| 实际执行 | 阻断；实际结果/环境/构建版本/执行人/时间/证据均无；拟证据目录 validation/business/TC-17-005/ |

#### TC-19-003：token：revoked —重复注销或刷新撤销令牌→ revoked

| 项目 | 执行定义 |
| --- | --- |
| 关联与角色 | AC-19；US-04、US-14 / BR-17；API-10、API-14 / 撤销集合；角色 TD-02.roles.administrator |
| 前置条件 | 完成9.1通用前提；关闭 Q-06、Q-11、Q-12、Q-15；每个子场景独立还原，不能沿用上一子场景的修改 |
| 具体数据 | TD-01、TD-02、TD-06、TD-08、TD-09；TD-08.token[6]；恢复当前状态=revoked；版本/时间/授权前提按第六章对应行 |
| 操作步骤 | 1. 按对应状态表准备身份、初态和时间。2. 通过批准的事件入口触发 重复注销或刷新撤销令牌。3. 查询状态/关联对象及适用审计；失败分支另恢复初态后注入前提不满足。 |
| 预期结果与禁止副作用 | 目标状态为 revoked，副作用/失败处理逐项符合第六章该行；失败不能谎称转换成功，自循环不得恢复终态有效。 HTTP/业务码依9.1分列；非本例目标对象、凭据与授权关系不得附带变化。 |
| 清理/重跑 | 保存脱敏证据，按ID映射只清理本例生成对象并恢复初始字段/版本；关系先子后父；不清共享审计；步骤见9.5 |
| 实际执行 | 阻断；实际结果/环境/构建版本/执行人/时间/证据均无；拟证据目录 validation/business/TC-19-003/ |

#### TC-20-003：delegation：[*] —提交申请→ pending

| 项目 | 执行定义 |
| --- | --- |
| 关联与角色 | AC-20；US-12 / BR-06、BR-18、BR-30；API-12、API-16 / 状态/幂等/时序；角色 TD-02.roles.administrator |
| 前置条件 | 完成9.1通用前提；关闭 Q-07、Q-11、Q-12、Q-15；每个子场景独立还原，不能沿用上一子场景的修改 |
| 具体数据 | TD-01、TD-02、TD-06、TD-08、TD-09；TD-08.delegation[0]；恢复当前状态=[*]；版本/时间/授权前提按第六章对应行 |
| 操作步骤 | 1. 按对应状态表准备身份、初态和时间。2. 通过批准的事件入口触发 提交申请。3. 查询状态/关联对象及适用审计；失败分支另恢复初态后注入前提不满足。 |
| 预期结果与禁止副作用 | 目标状态为 pending，副作用/失败处理逐项符合第六章该行；失败不能谎称转换成功，自循环不得恢复终态有效。 HTTP/业务码依9.1分列；非本例目标对象、凭据与授权关系不得附带变化。 |
| 清理/重跑 | 保存脱敏证据，按ID映射只清理本例生成对象并恢复初始字段/版本；关系先子后父；不清共享审计；步骤见9.5 |
| 实际执行 | 阻断；实际结果/环境/构建版本/执行人/时间/证据均无；拟证据目录 validation/business/TC-20-003/ |

#### TC-20-004：delegation：pending —批准申请→ active

| 项目 | 执行定义 |
| --- | --- |
| 关联与角色 | AC-20；US-12 / BR-06、BR-18、BR-30；API-12、API-16 / 状态/幂等/时序；角色 TD-02.roles.administrator |
| 前置条件 | 完成9.1通用前提；关闭 Q-07、Q-11、Q-12、Q-15；每个子场景独立还原，不能沿用上一子场景的修改 |
| 具体数据 | TD-01、TD-02、TD-06、TD-08、TD-09；TD-08.delegation[1]；恢复当前状态=pending；版本/时间/授权前提按第六章对应行 |
| 操作步骤 | 1. 按对应状态表准备身份、初态和时间。2. 通过批准的事件入口触发 批准申请。3. 查询状态/关联对象及适用审计；失败分支另恢复初态后注入前提不满足。 |
| 预期结果与禁止副作用 | 目标状态为 active，副作用/失败处理逐项符合第六章该行；失败不能谎称转换成功，自循环不得恢复终态有效。 HTTP/业务码依9.1分列；非本例目标对象、凭据与授权关系不得附带变化。 |
| 清理/重跑 | 保存脱敏证据，按ID映射只清理本例生成对象并恢复初始字段/版本；关系先子后父；不清共享审计；步骤见9.5 |
| 实际执行 | 阻断；实际结果/环境/构建版本/执行人/时间/证据均无；拟证据目录 validation/business/TC-20-004/ |

#### TC-20-005：delegation：pending —拒绝申请→ rejected

| 项目 | 执行定义 |
| --- | --- |
| 关联与角色 | AC-20；US-12 / BR-06、BR-18、BR-30；API-12、API-16 / 状态/幂等/时序；角色 TD-02.roles.administrator |
| 前置条件 | 完成9.1通用前提；关闭 Q-07、Q-11、Q-12、Q-15；每个子场景独立还原，不能沿用上一子场景的修改 |
| 具体数据 | TD-01、TD-02、TD-06、TD-08、TD-09；TD-08.delegation[2]；恢复当前状态=pending；版本/时间/授权前提按第六章对应行 |
| 操作步骤 | 1. 按对应状态表准备身份、初态和时间。2. 通过批准的事件入口触发 拒绝申请。3. 查询状态/关联对象及适用审计；失败分支另恢复初态后注入前提不满足。 |
| 预期结果与禁止副作用 | 目标状态为 rejected，副作用/失败处理逐项符合第六章该行；失败不能谎称转换成功，自循环不得恢复终态有效。 HTTP/业务码依9.1分列；非本例目标对象、凭据与授权关系不得附带变化。 |
| 清理/重跑 | 保存脱敏证据，按ID映射只清理本例生成对象并恢复初始字段/版本；关系先子后父；不清共享审计；步骤见9.5 |
| 实际执行 | 阻断；实际结果/环境/构建版本/执行人/时间/证据均无；拟证据目录 validation/business/TC-20-005/ |

#### TC-20-006：delegation：active —撤销委托→ revoked

| 项目 | 执行定义 |
| --- | --- |
| 关联与角色 | AC-20；US-12 / BR-06、BR-18、BR-30；API-12、API-16 / 状态/幂等/时序；角色 TD-02.roles.administrator |
| 前置条件 | 完成9.1通用前提；关闭 Q-07、Q-11、Q-12、Q-15；每个子场景独立还原，不能沿用上一子场景的修改 |
| 具体数据 | TD-01、TD-02、TD-06、TD-08、TD-09；TD-08.delegation[3]；恢复当前状态=active；版本/时间/授权前提按第六章对应行 |
| 操作步骤 | 1. 按对应状态表准备身份、初态和时间。2. 通过批准的事件入口触发 撤销委托。3. 查询状态/关联对象及适用审计；失败分支另恢复初态后注入前提不满足。 |
| 预期结果与禁止副作用 | 目标状态为 revoked，副作用/失败处理逐项符合第六章该行；失败不能谎称转换成功，自循环不得恢复终态有效。 HTTP/业务码依9.1分列；非本例目标对象、凭据与授权关系不得附带变化。 |
| 清理/重跑 | 保存脱敏证据，按ID映射只清理本例生成对象并恢复初始字段/版本；关系先子后父；不清共享审计；步骤见9.5 |
| 实际执行 | 阻断；实际结果/环境/构建版本/执行人/时间/证据均无；拟证据目录 validation/business/TC-20-006/ |

#### TC-20-007：delegation：active —超过有效结束时间→ expired

| 项目 | 执行定义 |
| --- | --- |
| 关联与角色 | AC-20；US-12 / BR-06、BR-18、BR-30；API-12、API-16 / 状态/幂等/时序；角色 TD-02.roles.administrator |
| 前置条件 | 完成9.1通用前提；关闭 Q-07、Q-11、Q-12、Q-15；每个子场景独立还原，不能沿用上一子场景的修改 |
| 具体数据 | TD-01、TD-02、TD-06、TD-08、TD-09；TD-08.delegation[4]；恢复当前状态=active；版本/时间/授权前提按第六章对应行 |
| 操作步骤 | 1. 按对应状态表准备身份、初态和时间。2. 通过批准的事件入口触发 超过有效结束时间。3. 查询状态/关联对象及适用审计；失败分支另恢复初态后注入前提不满足。 |
| 预期结果与禁止副作用 | 目标状态为 expired，副作用/失败处理逐项符合第六章该行；失败不能谎称转换成功，自循环不得恢复终态有效。 HTTP/业务码依9.1分列；非本例目标对象、凭据与授权关系不得附带变化。 |
| 清理/重跑 | 保存脱敏证据，按ID映射只清理本例生成对象并恢复初始字段/版本；关系先子后父；不清共享审计；步骤见9.5 |
| 实际执行 | 阻断；实际结果/环境/构建版本/执行人/时间/证据均无；拟证据目录 validation/business/TC-20-007/ |

#### TC-20-008：delegation：pending —过期申请尝试批准→ pending

| 项目 | 执行定义 |
| --- | --- |
| 关联与角色 | AC-20；US-12 / BR-06、BR-18、BR-30；API-12、API-16 / 状态/幂等/时序；角色 TD-02.roles.administrator |
| 前置条件 | 完成9.1通用前提；关闭 Q-07、Q-11、Q-12、Q-15；每个子场景独立还原，不能沿用上一子场景的修改 |
| 具体数据 | TD-01、TD-02、TD-06、TD-08、TD-09；TD-08.delegation[5]；恢复当前状态=pending；版本/时间/授权前提按第六章对应行 |
| 操作步骤 | 1. 按对应状态表准备身份、初态和时间。2. 通过批准的事件入口触发 过期申请尝试批准。3. 查询状态/关联对象及适用审计；失败分支另恢复初态后注入前提不满足。 |
| 预期结果与禁止副作用 | 目标状态为 pending，副作用/失败处理逐项符合第六章该行；失败不能谎称转换成功，自循环不得恢复终态有效。 HTTP/业务码依9.1分列；非本例目标对象、凭据与授权关系不得附带变化。 |
| 清理/重跑 | 保存脱敏证据，按ID映射只清理本例生成对象并恢复初始字段/版本；关系先子后父；不清共享审计；步骤见9.5 |
| 实际执行 | 阻断；实际结果/环境/构建版本/执行人/时间/证据均无；拟证据目录 validation/business/TC-20-008/ |

#### TC-20-009：delegation：expired —重试或重放终态申请→ expired

| 项目 | 执行定义 |
| --- | --- |
| 关联与角色 | AC-20；US-12 / BR-06、BR-18、BR-30；API-12、API-16 / 状态/幂等/时序；角色 TD-02.roles.administrator |
| 前置条件 | 完成9.1通用前提；关闭 Q-07、Q-11、Q-12、Q-15；每个子场景独立还原，不能沿用上一子场景的修改 |
| 具体数据 | TD-01、TD-02、TD-06、TD-08、TD-09；TD-08.delegation[6]；恢复当前状态=expired；版本/时间/授权前提按第六章对应行 |
| 操作步骤 | 1. 按对应状态表准备身份、初态和时间。2. 通过批准的事件入口触发 重试或重放终态申请。3. 查询状态/关联对象及适用审计；失败分支另恢复初态后注入前提不满足。 |
| 预期结果与禁止副作用 | 目标状态为 expired，副作用/失败处理逐项符合第六章该行；失败不能谎称转换成功，自循环不得恢复终态有效。 HTTP/业务码依9.1分列；非本例目标对象、凭据与授权关系不得附带变化。 |
| 清理/重跑 | 保存脱敏证据，按ID映射只清理本例生成对象并恢复初始字段/版本；关系先子后父；不清共享审计；步骤见9.5 |
| 实际执行 | 阻断；实际结果/环境/构建版本/执行人/时间/证据均无；拟证据目录 validation/business/TC-20-009/ |

#### TC-20-010：delegation：revoked —重试或重放终态申请→ revoked

| 项目 | 执行定义 |
| --- | --- |
| 关联与角色 | AC-20；US-12 / BR-06、BR-18、BR-30；API-12、API-16 / 状态/幂等/时序；角色 TD-02.roles.administrator |
| 前置条件 | 完成9.1通用前提；关闭 Q-07、Q-11、Q-12、Q-15；每个子场景独立还原，不能沿用上一子场景的修改 |
| 具体数据 | TD-01、TD-02、TD-06、TD-08、TD-09；TD-08.delegation[7]；恢复当前状态=revoked；版本/时间/授权前提按第六章对应行 |
| 操作步骤 | 1. 按对应状态表准备身份、初态和时间。2. 通过批准的事件入口触发 重试或重放终态申请。3. 查询状态/关联对象及适用审计；失败分支另恢复初态后注入前提不满足。 |
| 预期结果与禁止副作用 | 目标状态为 revoked，副作用/失败处理逐项符合第六章该行；失败不能谎称转换成功，自循环不得恢复终态有效。 HTTP/业务码依9.1分列；非本例目标对象、凭据与授权关系不得附带变化。 |
| 清理/重跑 | 保存脱敏证据，按ID映射只清理本例生成对象并恢复初始字段/版本；关系先子后父；不清共享审计；步骤见9.5 |
| 实际执行 | 阻断；实际结果/环境/构建版本/执行人/时间/证据均无；拟证据目录 validation/business/TC-20-010/ |

#### TC-20-011：delegation：rejected —重试或重放终态申请→ rejected

| 项目 | 执行定义 |
| --- | --- |
| 关联与角色 | AC-20；US-12 / BR-06、BR-18、BR-30；API-12、API-16 / 状态/幂等/时序；角色 TD-02.roles.administrator |
| 前置条件 | 完成9.1通用前提；关闭 Q-07、Q-11、Q-12、Q-15；每个子场景独立还原，不能沿用上一子场景的修改 |
| 具体数据 | TD-01、TD-02、TD-06、TD-08、TD-09；TD-08.delegation[8]；恢复当前状态=rejected；版本/时间/授权前提按第六章对应行 |
| 操作步骤 | 1. 按对应状态表准备身份、初态和时间。2. 通过批准的事件入口触发 重试或重放终态申请。3. 查询状态/关联对象及适用审计；失败分支另恢复初态后注入前提不满足。 |
| 预期结果与禁止副作用 | 目标状态为 rejected，副作用/失败处理逐项符合第六章该行；失败不能谎称转换成功，自循环不得恢复终态有效。 HTTP/业务码依9.1分列；非本例目标对象、凭据与授权关系不得附带变化。 |
| 清理/重跑 | 保存脱敏证据，按ID映射只清理本例生成对象并恢复初始字段/版本；关系先子后父；不清共享审计；步骤见9.5 |
| 实际执行 | 阻断；实际结果/环境/构建版本/执行人/时间/证据均无；拟证据目录 validation/business/TC-20-011/ |

#### TC-23-002：archive：[*] —创建归档任务→ queued

| 项目 | 执行定义 |
| --- | --- |
| 关联与角色 | AC-23；US-13 / BR-23；API-13 / 分区/归档候选记录；角色 TD-02.roles.administrator |
| 前置条件 | 完成9.1通用前提；关闭 Q-09、Q-13、Q-15；每个子场景独立还原，不能沿用上一子场景的修改 |
| 具体数据 | TD-01、TD-02、TD-06、TD-08、TD-09；TD-08.archive[0]；恢复当前状态=[*]；版本/时间/授权前提按第六章对应行 |
| 操作步骤 | 1. 按对应状态表准备身份、初态和时间。2. 通过批准的事件入口触发 创建归档任务。3. 查询状态/关联对象及适用审计；失败分支另恢复初态后注入前提不满足。 |
| 预期结果与禁止副作用 | 目标状态为 queued，副作用/失败处理逐项符合第六章该行；失败不能谎称转换成功，自循环不得恢复终态有效。 HTTP/业务码依9.1分列；非本例目标对象、凭据与授权关系不得附带变化。 |
| 清理/重跑 | 保存脱敏证据，按ID映射只清理本例生成对象并恢复初始字段/版本；关系先子后父；不清共享审计；步骤见9.5 |
| 实际执行 | 阻断；实际结果/环境/构建版本/执行人/时间/证据均无；拟证据目录 validation/business/TC-23-002/ |

#### TC-23-003：archive：queued —启动归档→ processing

| 项目 | 执行定义 |
| --- | --- |
| 关联与角色 | AC-23；US-13 / BR-23；API-13 / 分区/归档候选记录；角色 TD-02.roles.administrator |
| 前置条件 | 完成9.1通用前提；关闭 Q-09、Q-13、Q-15；每个子场景独立还原，不能沿用上一子场景的修改 |
| 具体数据 | TD-01、TD-02、TD-06、TD-08、TD-09；TD-08.archive[1]；恢复当前状态=queued；版本/时间/授权前提按第六章对应行 |
| 操作步骤 | 1. 按对应状态表准备身份、初态和时间。2. 通过批准的事件入口触发 启动归档。3. 查询状态/关联对象及适用审计；失败分支另恢复初态后注入前提不满足。 |
| 预期结果与禁止副作用 | 目标状态为 processing，副作用/失败处理逐项符合第六章该行；失败不能谎称转换成功，自循环不得恢复终态有效。 HTTP/业务码依9.1分列；非本例目标对象、凭据与授权关系不得附带变化。 |
| 清理/重跑 | 保存脱敏证据，按ID映射只清理本例生成对象并恢复初始字段/版本；关系先子后父；不清共享审计；步骤见9.5 |
| 实际执行 | 阻断；实际结果/环境/构建版本/执行人/时间/证据均无；拟证据目录 validation/business/TC-23-003/ |

#### TC-23-004：archive：processing —复制与完整性校验通过→ verified

| 项目 | 执行定义 |
| --- | --- |
| 关联与角色 | AC-23；US-13 / BR-23；API-13 / 分区/归档候选记录；角色 TD-02.roles.administrator |
| 前置条件 | 完成9.1通用前提；关闭 Q-09、Q-13、Q-15；每个子场景独立还原，不能沿用上一子场景的修改 |
| 具体数据 | TD-01、TD-02、TD-06、TD-08、TD-09；TD-08.archive[2]；恢复当前状态=processing；版本/时间/授权前提按第六章对应行 |
| 操作步骤 | 1. 按对应状态表准备身份、初态和时间。2. 通过批准的事件入口触发 复制与完整性校验通过。3. 查询状态/关联对象及适用审计；失败分支另恢复初态后注入前提不满足。 |
| 预期结果与禁止副作用 | 目标状态为 verified，副作用/失败处理逐项符合第六章该行；失败不能谎称转换成功，自循环不得恢复终态有效。 HTTP/业务码依9.1分列；非本例目标对象、凭据与授权关系不得附带变化。 |
| 清理/重跑 | 保存脱敏证据，按ID映射只清理本例生成对象并恢复初始字段/版本；关系先子后父；不清共享审计；步骤见9.5 |
| 实际执行 | 阻断；实际结果/环境/构建版本/执行人/时间/证据均无；拟证据目录 validation/business/TC-23-004/ |

#### TC-23-005：archive：processing —复制或校验失败→ failed

| 项目 | 执行定义 |
| --- | --- |
| 关联与角色 | AC-23；US-13 / BR-23；API-13 / 分区/归档候选记录；角色 TD-02.roles.administrator |
| 前置条件 | 完成9.1通用前提；关闭 Q-09、Q-13、Q-15；每个子场景独立还原，不能沿用上一子场景的修改 |
| 具体数据 | TD-01、TD-02、TD-06、TD-08、TD-09；TD-08.archive[3]；恢复当前状态=processing；版本/时间/授权前提按第六章对应行 |
| 操作步骤 | 1. 按对应状态表准备身份、初态和时间。2. 通过批准的事件入口触发 复制或校验失败。3. 查询状态/关联对象及适用审计；失败分支另恢复初态后注入前提不满足。 |
| 预期结果与禁止副作用 | 目标状态为 failed，副作用/失败处理逐项符合第六章该行；失败不能谎称转换成功，自循环不得恢复终态有效。 HTTP/业务码依9.1分列；非本例目标对象、凭据与授权关系不得附带变化。 |
| 清理/重跑 | 保存脱敏证据，按ID映射只清理本例生成对象并恢复初始字段/版本；关系先子后父；不清共享审计；步骤见9.5 |
| 实际执行 | 阻断；实际结果/环境/构建版本/执行人/时间/证据均无；拟证据目录 validation/business/TC-23-005/ |

#### TC-23-006：archive：verified —确认可恢复并完成策略处理→ completed

| 项目 | 执行定义 |
| --- | --- |
| 关联与角色 | AC-23；US-13 / BR-23；API-13 / 分区/归档候选记录；角色 TD-02.roles.administrator |
| 前置条件 | 完成9.1通用前提；关闭 Q-09、Q-13、Q-15；每个子场景独立还原，不能沿用上一子场景的修改 |
| 具体数据 | TD-01、TD-02、TD-06、TD-08、TD-09；TD-08.archive[4]；恢复当前状态=verified；版本/时间/授权前提按第六章对应行 |
| 操作步骤 | 1. 按对应状态表准备身份、初态和时间。2. 通过批准的事件入口触发 确认可恢复并完成策略处理。3. 查询状态/关联对象及适用审计；失败分支另恢复初态后注入前提不满足。 |
| 预期结果与禁止副作用 | 目标状态为 completed，副作用/失败处理逐项符合第六章该行；失败不能谎称转换成功，自循环不得恢复终态有效。 HTTP/业务码依9.1分列；非本例目标对象、凭据与授权关系不得附带变化。 |
| 清理/重跑 | 保存脱敏证据，按ID映射只清理本例生成对象并恢复初始字段/版本；关系先子后父；不清共享审计；步骤见9.5 |
| 实际执行 | 阻断；实际结果/环境/构建版本/执行人/时间/证据均无；拟证据目录 validation/business/TC-23-006/ |

#### TC-23-007：archive：verified —完成确认失败→ failed

| 项目 | 执行定义 |
| --- | --- |
| 关联与角色 | AC-23；US-13 / BR-23；API-13 / 分区/归档候选记录；角色 TD-02.roles.administrator |
| 前置条件 | 完成9.1通用前提；关闭 Q-09、Q-13、Q-15；每个子场景独立还原，不能沿用上一子场景的修改 |
| 具体数据 | TD-01、TD-02、TD-06、TD-08、TD-09；TD-08.archive[5]；恢复当前状态=verified；版本/时间/授权前提按第六章对应行 |
| 操作步骤 | 1. 按对应状态表准备身份、初态和时间。2. 通过批准的事件入口触发 完成确认失败。3. 查询状态/关联对象及适用审计；失败分支另恢复初态后注入前提不满足。 |
| 预期结果与禁止副作用 | 目标状态为 failed，副作用/失败处理逐项符合第六章该行；失败不能谎称转换成功，自循环不得恢复终态有效。 HTTP/业务码依9.1分列；非本例目标对象、凭据与授权关系不得附带变化。 |
| 清理/重跑 | 保存脱敏证据，按ID映射只清理本例生成对象并恢复初始字段/版本；关系先子后父；不清共享审计；步骤见9.5 |
| 实际执行 | 阻断；实际结果/环境/构建版本/执行人/时间/证据均无；拟证据目录 validation/business/TC-23-007/ |

#### TC-23-008：archive：failed —核对进度后重试→ processing

| 项目 | 执行定义 |
| --- | --- |
| 关联与角色 | AC-23；US-13 / BR-23；API-13 / 分区/归档候选记录；角色 TD-02.roles.administrator |
| 前置条件 | 完成9.1通用前提；关闭 Q-09、Q-13、Q-15；每个子场景独立还原，不能沿用上一子场景的修改 |
| 具体数据 | TD-01、TD-02、TD-06、TD-08、TD-09；TD-08.archive[6]；恢复当前状态=failed；版本/时间/授权前提按第六章对应行 |
| 操作步骤 | 1. 按对应状态表准备身份、初态和时间。2. 通过批准的事件入口触发 核对进度后重试。3. 查询状态/关联对象及适用审计；失败分支另恢复初态后注入前提不满足。 |
| 预期结果与禁止副作用 | 目标状态为 processing，副作用/失败处理逐项符合第六章该行；失败不能谎称转换成功，自循环不得恢复终态有效。 HTTP/业务码依9.1分列；非本例目标对象、凭据与授权关系不得附带变化。 |
| 清理/重跑 | 保存脱敏证据，按ID映射只清理本例生成对象并恢复初始字段/版本；关系先子后父；不清共享审计；步骤见9.5 |
| 实际执行 | 阻断；实际结果/环境/构建版本/执行人/时间/证据均无；拟证据目录 validation/business/TC-23-008/ |

### 9.4 测试数据集与具体样例

全部数据使用固定 seed=20260912、namespace=auth-prd、referenceTime=2026-09-12T00:30:00Z；默认业务资源4条。JSON 中 TD 键及子字段是下表选择器。表字段样例和测试上下文分开，不能把上下文属性直接 INSERT 到原 DDL。

| TD | 内容/数量与分布 | 样例/关联 | 生成及校验边界 |
| --- | --- | --- | --- |
| TD-01 | 14 个原 DDL 表的字段样例：账号4、组织5、用户组1、成员2、令牌4、参数1、字典1、操作4、权限组3、用户授权1、组织授权1、应用4、委托1、审计1 | tables.account[1].id=102；org11与org21同名不同树；app501=SELF、502=DEPT、503=frozen、504=SPECIFIED[21]；delegation601=active | 共33条。字段类型与引用可作本地检查，但密码/secret/token为不可用标记；不是可直接装载或登录的合法认证种子。 |
| TD-02 | 2条组织归属、4个角色标签、1个委托应用映射、4个令牌上下文 | 102→11，103→21；601→app501；701/702/703属于session-a | 原DDL缺少这些关系；仅测试适配上下文，受Q-01/Q-02/Q-06/Q-07阻断。 |
| TD-03 | 默认4条业务资源；可参数化至100000条 | dev-001=(creator102,dept11)，dev-002=(103,11)，dev-003=(103,12)，dev-004=(103,21) | 不是新增授权中心业务表。SELF/DEPT/SPECIFIED采用该资源矩阵；扩展数据固定种子，分布/规模需批准后才可用于性能。 |
| TD-04 | 应用、密码、IP、证书与场景输入 | 无效key=fixture-unknown；允许IP=192.0.2.10，拒绝IP=198.51.100.10；scene-b | 示例IP为测试值。凭据/证书仅引用标签，必须由已批准测试设施注入有效/失效材料；不生成真实凭据。 |
| TD-05 | 合法边界与故意非法请求 | username64/65、中文name128/129、text512/513、缺失/null/空串、空数组/对象、未知ID999999、大ID字符串9007199254740993、非法排序、只读字段、HTML字样 | 故意非法输入不能作为合法基线预装；逐项检查长度/类型/缺失区别，不在生成器中修正坏数据。 |
| TD-06 | 4个边界时刻、1个等价偏移时刻及过期待审批输入 | 23:59:59.999Z/00:00Z/01:00Z/01:00:00.001Z；08:30+08与00:30Z相等 | 委托区间两端包含；token过期边界按Q-06单独确定；旧TIMESTAMP时区映射仍待Q-11。 |
| TD-07 | 两个v7请求、一个幂等键、两类相同组合 | requestA.operationIds=[201]，requestB=[202]；同version=7；key=auth-prd-apply-001 | version/幂等键不在原DDL；只能在批准并发方案的测试适配中使用，不能声称已有数据库列。 |
| TD-08 | 5种状态机，共29条迁移 | account3、app3、token7、delegation9、archive7；含自循环 | 与第六章图/表逐条核对；rejected/consumed/归档任务状态为候选或逻辑状态，不作为已批准表列。 |
| TD-09 | 6种故障标签、归档批次、审计trace和3类敏感标记 | 权限源超时、缓存不可用、审计失败、复制失败、校验错、完成确认失败 | 标签不自动注入故障；适配由Q-08/Q-09批准。记录归档范围、数量和摘要，清理不能删除唯一副本。 |
| TD-10 | 迁移问题清单与性能参数占位 | 原DDL三类建库障碍；performanceApproval/concurrency/p95TargetMs/rto/rpo=null | null表示没有批准参数，不是零指标；不生成伪造旧库/容量基线，不执行DDL。 |

### 9.5 数据如何生成、校验、装载与清理

生成工具：Python 3.10+ 标准库，本轮实际运行版本见交付验证报告。已交付同目录的 测试数据/生成测试数据.py，完整内容也在下面，可从单独的 MD/HTML 复制重建。无需联网、数据库或认证信息。

在授权中心目录执行；输出目录是本次独立夹具目录。默认只写 authorization-fixtures.json 和 manifest.json；同参数重跑字节相同，已有不同内容时拒绝覆盖，请改用新目录。

```bash
python 测试数据/生成测试数据.py --out-dir 测试数据/baseline --seed 20260912 --namespace auth-prd --resource-count 4
python 测试数据/生成测试数据.py --out-dir 测试数据/repeat --seed 20260912 --namespace auth-prd --resource-count 4
```

容量数据生成示例（仅演示生成能力，非批准性能规模）：

```bash
python 测试数据/生成测试数据.py --out-dir 测试数据/scale-10000 --seed 20260912 --namespace auth-prd --resource-count 10000
```

```python
#!/usr/bin/env python3
"""生成独立的授权中心合成 JSON；不连接数据库、接口或凭据设施。"""
import argparse
import hashlib
import json
from pathlib import Path
import random
import re
import uuid


def generate(seed=20260912, namespace='auth-prd', resource_count=4):
    if not re.fullmatch(r'[a-z][a-z0-9-]{0,19}', namespace):
        raise ValueError('namespace 必须为 1—20 位小写字母、数字、连字符，首位为字母')
    if not 4 <= resource_count <= 100000:
        raise ValueError('resource-count 范围为 4—100000；规模不代表已批准性能目标')
    rng = random.Random(seed)
    reference = '2026-09-12T00:30:00Z'
    start, end = '2026-09-12T00:00:00Z', '2026-09-12T01:00:00Z'
    common = {'created_at': start, 'updated_at': start}
    def uid(label):
        return str(uuid.uuid5(uuid.NAMESPACE_URL, f'{namespace}/{seed}/{label}'))
    accounts = [dict(id=n, uuid=uid(f'account/{n}'), username=f'{namespace}-{label}',
                     password='SYNTHETIC-NOT-A-LOGIN-HASH', phone=None, email=None,
                     account_type=kind, status='normal', ip_whitelist=ips, **common)
                for n, label, kind, ips in [(101,'admin','person',[]),(102,'member','person',[]),
                                           (103,'delegate','person',[]),(104,'service','service',['192.0.2.10/32'])]]
    orgs = [dict(id=n,parent_id=parent,org_path=path,org_name=name,org_type=kind,**common)
            for n,parent,path,name,kind in [(10,0,'/10','测试单位A','company'),
                (11,10,'/10/11','同名部门','department'),(12,11,'/10/11/12','测试班组','team'),
                (20,0,'/20','测试单位B','company'),(21,20,'/20/21','同名部门','department')]]
    operations = [dict(id=n,operation_code=code,operation_name=name,resource_type=resource,**common)
                  for n,code,name,resource in [(201,'DeviceController.list','设备列表','device'),
                      (202,'DeviceController.control','设备控制','device'),
                      (203,'DeviceController.detail','设备详情','device'),
                      (204,'AccountController.list','账号列表','account')]]
    groups = [dict(id=401,name='测试静态权限',operation_ids=[201,202,203,204],**common),
              dict(id=402,name='测试空权限',operation_ids=[],**common),
              dict(id=403,name='测试委托权限',operation_ids=[202],**common)]
    apps = [dict(id=n,app_code=f'{namespace}-{name}',permission_group_id=group,
                 app_key=f'fixture-{namespace}-{name}',app_secret='SYNTHETIC-NOT-A-SECRET',
                 data_scope_type=scope,specified_org_ids=specified,status=status,**common)
            for n,name,group,scope,specified,status in [(501,'app-a',401,'SELF',[],'active'),
                (502,'app-b',403,'DEPT',[],'active'),(503,'frozen',401,'SELF',[],'frozen'),
                (504,'specified',401,'SPECIFIED',[21],'active')]]
    tokens = [dict(id=n,token=f'fixture-{namespace}-token-{n}',account_id=102,token_type=kind,
                   refresh_type=refresh,scene_id=scene,expires_at=end,revoked=revoked,**common)
              for n,kind,refresh,scene,revoked in [(701,'Master-Token','access_token',None,False),
                  (702,'Master-Token','refresh_token',None,False),
                  (703,'Scene-Token','access_token','scene-a',False),
                  (704,'Master-Token','access_token',None,True)]]
    delegation = dict(id=601,grantor_id=101,grantee_id=103,permission_group_id=403,
                      resource_type='device',resource_ids=['dev-001'],valid_from=start,
                      valid_until=end,status='active',reason='合成测试',**common)
    tables = {'account':accounts,'organization':orgs,
        'user_group':[dict(id=301,group_code=f'{namespace}-cross',group_name='跨部门测试组',**common)],
        'user_group_account':[dict(id=311,user_group_id=301,account_id=102,created_at=start),
                              dict(id=312,user_group_id=301,account_id=103,created_at=start)],
        'token':tokens,'sys_param':[dict(id=801,param_code=f'{namespace}-param',param_value='demo',**common)],
        'sys_dict':[dict(id=901,dict_code=f'{namespace}-dict',dict_items=['启用','禁用'],**common)],
        'operation':operations,'permission_group':groups,
        'permission_group_account':[dict(id=411,permission_group_id=401,account_id=101,created_at=start)],
        'permission_group_org':[dict(id=421,permission_group_id=401,org_id=11,created_at=start)],
        'app_authorization':apps,'delegation':[delegation],
        'audit_log':[dict(id=1001,trace_id=uid('audit/1001'),account_id=103,
                         app_code=f'{namespace}-app-a',operation_code='DeviceController.control',
                         resource_id='dev-001',resource_type='device',result='denied',
                         log_level='warn',reason='合成拒绝事件',created_at=start)]}
    resources = [dict(id='dev-001',creator_id=102,dept_id=11),
                 dict(id='dev-002',creator_id=103,dept_id=11),
                 dict(id='dev-003',creator_id=103,dept_id=12),
                 dict(id='dev-004',creator_id=103,dept_id=21)]
    for n in range(5,resource_count+1):
        resources.append(dict(id=f'dev-{n:06d}',creator_id=rng.choice([102,103]),dept_id=rng.choice([11,12,21])))
    transitions = {
        'account':[('[*]','创建账号','normal'),('normal','冻结账号','frozen'),('frozen','解冻账号','normal')],
        'app':[('[*]','注册应用','active'),('active','冻结应用','frozen'),('frozen','解冻应用','active')],
        'token':[('[*]','签发成功','valid'),('valid','刷新轮换成功','consumed'),
                 ('valid','到达过期阈值','expired'),('valid','退出或注销或冻结关联处理','revoked'),
                 ('consumed','重放已消费令牌','consumed'),('expired','重复注销或刷新过期令牌','expired'),
                 ('revoked','重复注销或刷新撤销令牌','revoked')],
        'delegation':[('[*]','提交申请','pending'),('pending','批准申请','active'),
                      ('pending','拒绝申请','rejected'),('active','撤销委托','revoked'),
                      ('active','超过有效结束时间','expired'),('pending','过期申请尝试批准','pending'),
                      ('expired','重试或重放终态申请','expired'),('revoked','重试或重放终态申请','revoked'),
                      ('rejected','重试或重放终态申请','rejected')],
        'archive':[('[*]','创建归档任务','queued'),('queued','启动归档','processing'),
                   ('processing','复制与完整性校验通过','verified'),('processing','复制或校验失败','failed'),
                   ('verified','确认可恢复并完成策略处理','completed'),('verified','完成确认失败','failed'),
                   ('failed','核对进度后重试','processing')]}
    return {'meta':{'synthetic':True,'seed':seed,'namespace':namespace,'referenceTime':reference,
                    'resourceCount':resource_count,'credentialsUsable':False,
                    'scope':'表字段样例，不是可直接装载的种子；认证/时区/主键映射需批准适配'},
        'TD-01':{'tables':tables},
        'TD-02':{'memberships':[{'accountId':102,'orgId':11},{'accountId':103,'orgId':21}],
                 'roles':{'administrator':101,'staticUser':102,'delegatedUser':103,'service':104},
                 'delegationApp':{'601':501},'tokenContexts':{'701':'session-a','702':'session-a',
                                                             '703':'session-a/scene-a','704':'session-b'},
                 'notice':'测试上下文，不是原 DDL 的表/列；组织归属、会话及委托应用绑定待 Q-02/Q-06/Q-07'},
        'TD-03':{'resources':resources,'notice':'业务资源模拟，不是授权中心新增业务表'},
        'TD-04':{'appInvalid':'fixture-unknown','appFrozenId':503,'allowedIp':'192.0.2.10',
                 'deniedIp':'198.51.100.10','untrustedForwardedIp':'192.0.2.10',
                 'passwordAttempt':'SYNTHETIC-DO-NOT-LOGIN','credentialRef':'fixture:service-104',
                 'certificateRef':'fixture:certificate-104','wrongScene':'scene-b'},
        'TD-05':{'username64':'u'*64,'username65':'u'*65,'name128':'名'*128,'name129':'名'*129,
                 'text512':'文'*512,'text513':'文'*513,'missing':{},'null':{'remark':None},
                 'empty':{'remark':''},'emptyArray':[],'wrongObject':{},'unknownId':999999,
                 'largeId':'9007199254740993','invalidSort':'id;DROP TABLE account',
                 'readonly':{'createdBy':'103','uuid':'00000000-0000-0000-0000-000000000000'},
                 'unknownOperation':[999999],'unknownScope':'ALL','htmlText':'<img src="https://invalid.example/pixel" onerror="alert(1)">'},
        'TD-06':{'validFrom':start,'validUntil':end,'beforeFrom':'2026-09-11T23:59:59.999Z',
                 'atFrom':start,'atUntil':end,'afterUntil':'2026-09-12T01:00:00.001Z',
                 'sameInstantOffset':'2026-09-12T08:30:00+08:00','pendingExpired':{'status':'pending','now':'2026-09-12T01:00:00.001Z'}},
        'TD-07':{'readVersion':7,'requestA':{'version':7,'operationIds':[201]},
                 'requestB':{'version':7,'operationIds':[202]},'idempotencyKey':f'{namespace}-apply-001',
                 'uniqueAccountPair':{'permissionGroupId':403,'accountId':103},
                 'uniqueOrgPair':{'permissionGroupId':403,'orgId':21},
                 'notice':'版本/幂等键为方案测试元数据；DDL 未定义这些字段'},
        'TD-08':{key:[dict(current=a,event=b,next=c) for a,b,c in rows] for key,rows in transitions.items()},
        'TD-09':{'faults':['permission-source-timeout','cache-unavailable','audit-write-failure',
                          'archive-copy-failure','archive-checksum-mismatch','archive-finalize-failure'],
                 'archiveBatch':f'{namespace}-archive-001','auditTrace':uid('audit/1001'),
                 'sensitiveMarkers':['SYNTHETIC-NOT-A-SECRET','SYNTHETIC-NOT-A-LOGIN-HASH',f'fixture-{namespace}-token-701']},
        'TD-10':{'baselineResourceCount':resource_count,'distribution':{'creators':[102,103],'departments':[11,12,21]},
                 'migrationInput':'DDL.md：保留原始错误，实际修订版/旧库快照另行批准',
                 'ddlFaults':['created_by 后 10 处缺逗号','idx_token_account_id 重名','分区主键不含 created_at'],
                 'performanceApproval':None,'concurrency':None,'p95TargetMs':None,'rto':None,'rpo':None,
                 'notice':'未批准 Q-13/Q-16；夹具数量不证明性能或迁移已通过'}}


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out-dir',required=True,type=Path)
    parser.add_argument('--seed',type=int,default=20260912)
    parser.add_argument('--namespace',default='auth-prd')
    parser.add_argument('--resource-count',type=int,default=4)
    args=parser.parse_args()
    data=generate(args.seed,args.namespace,args.resource_count)
    raw=(json.dumps(data,ensure_ascii=False,indent=2)+'\n').encode('utf-8')
    manifest={'schemaVersion':1,'seed':args.seed,'namespace':args.namespace,'datasets':10,
              'referenceTime':data['meta']['referenceTime'],'resourceCount':args.resource_count,
              'file':'authorization-fixtures.json','sha256':hashlib.sha256(raw).hexdigest(),
              'businessExecution':'未装载数据库；未调用接口；未执行业务验收'}
    outputs={'authorization-fixtures.json':raw,
             'manifest.json':(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n').encode('utf-8')}
    args.out_dir.mkdir(parents=True,exist_ok=True)
    for name,value in outputs.items():
        path=args.out_dir/name
        if path.exists() and path.read_bytes()!=value:
            raise SystemExit('已有内容不同，请使用新隔离目录：'+str(path))
    for name,value in outputs.items():(args.out_dir/name).write_bytes(value)
    print(json.dumps(manifest,ensure_ascii=False))


if __name__=='__main__':
    main()
```

生成后校验：manifest中的SHA-256须与JSON原始字节一致；两次同参数输出相同；TD-01中主键、用户名/编码及组合不重复，全部已声明外键能解析；父路径与层次一致；TD-03默认资源矩阵精确匹配上表；TD-05中各长度和缺失/null/空串独立；TD-06边界前后相差1毫秒；TD-08的29条迁移逐条等于第六章图和表。附带 validation/v3.1.1/check_delivery.py 在本地执行这些检查，结果只能代表夹具与文档检查。

装载前提与顺序：原DDL存在DB-01—DB-03等问题，先由DBA批准并在隔离库验证修订方案；再配置测试身份/范围及凭据设施；通过已核验测试工厂依次建立 account、organization、operation、user_group、sys_param/sys_dict、permission_group，再建立各关联、app_authorization、token、delegation，最后配置审计读取/归档副本。所有生成ID由装载工具返回，保存合成ID→实际ID映射，JSONB内的操作/组织/资源引用也要映射，禁止假设生产id=101或序列从1开始。

TD-01认证字段只有不可用标记，不能直接插表后当真实认证数据；服务账号password非空冲突、令牌真实格式与存储方式由Q-05/Q-06解决。TD-02的成员/会话/应用归属、TD-07版本及TD-08逻辑状态只通过批准适配建立。TD-03资源在业务测试桩或获准业务测试服务中建立，不创建未经确认的新授权中心表。UTC字符串装载原TIMESTAMP前必须执行Q-11批准的时区转换。

清理：所有并发请求完成并保存证据后，用本例ID映射精确定位，先撤销/清理委托和令牌，再处理应用、权限与成员关联，再清理专用组、操作、账号和组织（组织自叶到根），参数/字典先检查消费引用。审计副本与归档按批准留存规则处理，不删除共享日志。若恢复旧状态/版本，必须用已批准测试重置机制，不能以普通业务编辑接口猜测回滚。原数据库/用户资料不在清理范围。

本地清理只删除本次 baseline/repeat/scale-10000 输出目录中的 authorization-fixtures.json 与 manifest.json 两个已知文件；确认目录属于本次运行后逐文件删除，不递归清空共享目录。程序不提供任何业务删除命令。

### 9.6 多对多追溯与待补范围

| 测试组 | US/BR | AC | API/数据约束 | 独立用例 | TD |
| --- | --- | --- | --- | --- | --- |
| TC-01 | US-11 / BR-01 | AC-01 | API-11 / 应用状态和唯一键 | TC-01-001, TC-01-002 | TD-01, TD-04 |
| TC-02 | US-01、US-04 / BR-02 | AC-02 | API-01、API-10 / DB-05 | TC-02-001, TC-02-002, TC-02-003, TC-02-004, TC-02-005 | TD-01, TD-04 |
| TC-03 | US-09、US-11 / BR-03、BR-04 | AC-03 | API-08、API-11 / 用户授权组合 | TC-03-001, TC-03-002, TC-03-003 | TD-01, TD-02 |
| TC-04 | US-02、US-10 / BR-03、BR-09 | AC-04 | API-02、API-09、API-15 / DB-04、DB-07 | TC-04-001, TC-04-002 | TD-01, TD-02, TD-09 |
| TC-05 | US-11 / BR-04、BR-05 | AC-05 | API-11 / 数据范围和资源映射 | TC-05-001, TC-05-002, TC-05-003, TC-05-004 | TD-01, TD-02, TD-03, TD-05 |
| TC-06 | US-11、US-12 / BR-04、BR-06 | AC-06 | API-11、API-12 / 委托资源与时间 | TC-06-001, TC-06-002, TC-06-003, TC-06-004, TC-06-005, TC-06-006, TC-06-007 | TD-01, TD-02, TD-03, TD-06 |
| TC-07 | US-12 / BR-07、BR-18 | AC-07 | API-11、API-16 / DB-09 | TC-07-001, TC-07-002, TC-07-003, TC-07-004, TC-07-005, TC-07-006 | TD-01, TD-02, TD-06 |
| TC-08 | US-11、US-12 / BR-04、BR-05 | AC-08 | API-11 / 目标资源归属 | TC-08-001 | TD-01, TD-02, TD-03 |
| TC-09 | US-01 / BR-08、BR-25、BR-26 | AC-09 | API-01 / 账号唯一约束 | TC-09-001, TC-09-002, TC-09-003, TC-09-004, TC-09-005, TC-09-006, TC-09-007, TC-09-008, TC-09-009 | TD-01, TD-02, TD-05, TD-06, TD-07, TD-08, TD-09 |
| TC-10 | US-02 / BR-09、BR-27 | AC-10 | API-02 / 组织树与版本 | TC-10-001, TC-10-002, TC-10-003, TC-10-004, TC-10-005, TC-10-006 | TD-01, TD-02, TD-07 |
| TC-11 | US-03 / BR-10、BR-12 | AC-11 | API-03、API-15 / 成员组合唯一 | TC-11-001, TC-11-002, TC-11-003, TC-11-004, TC-11-005, TC-11-006 | TD-01, TD-02, TD-07 |
| TC-12 | US-05、US-06 / BR-08、BR-20 | AC-12 | API-04、API-05 / 编码与 JSON | TC-12-001, TC-12-002, TC-12-003, TC-12-004, TC-12-005, TC-12-006, TC-12-007, TC-12-008, TC-12-009, TC-12-010, TC-12-011 | TD-01, TD-02, TD-05, TD-07 |
| TC-13 | US-07、US-08 / BR-08、BR-11 | AC-13 | API-06、API-07 / 操作引用 | TC-13-001, TC-13-002, TC-13-003, TC-13-004, TC-13-005, TC-13-006, TC-13-007, TC-13-008, TC-13-009 | TD-01, TD-02, TD-05, TD-07 |
| TC-14 | US-09、US-10 / BR-12、BR-30 | AC-14 | API-08、API-09 / 组合唯一 | TC-14-001, TC-14-002, TC-14-003, TC-14-004, TC-14-005, TC-14-006, TC-14-007, TC-14-008, TC-14-009, TC-14-010, TC-14-011 | TD-01, TD-02, TD-07 |
| TC-15 | US-11 / BR-03、BR-13 | AC-15 | API-11 / 应用组和 app 唯一 | TC-15-001, TC-15-002, TC-15-003, TC-15-004, TC-15-005, TC-15-006 | TD-01, TD-02, TD-06, TD-08, TD-09 |
| TC-16 | US-11 / BR-14、BR-17 | AC-16 | API-11 / 策略版本/缓存候选 | TC-16-001 | TD-01, TD-07, TD-10 |
| TC-17 | US-04 / BR-02、BR-15 | AC-17 | API-10、API-17 / token 类型与 scene | TC-17-001, TC-17-002, TC-17-003, TC-17-004, TC-17-005 | TD-01, TD-02, TD-04, TD-06, TD-08, TD-09 |
| TC-18 | US-04、US-14 / BR-16、BR-30 | AC-18 | API-10、API-14 / 轮换原子约束 | TC-18-001, TC-18-002, TC-18-003, TC-18-004 | TD-01, TD-02, TD-06, TD-07, TD-08, TD-09 |
| TC-19 | US-04、US-14 / BR-17 | AC-19 | API-10、API-14 / 撤销集合 | TC-19-001, TC-19-002, TC-19-003 | TD-01, TD-02, TD-06, TD-08, TD-09 |
| TC-20 | US-12 / BR-06、BR-18、BR-30 | AC-20 | API-12、API-16 / 状态/幂等/时序 | TC-20-001, TC-20-002, TC-20-003, TC-20-004, TC-20-005, TC-20-006, TC-20-007, TC-20-008, TC-20-009, TC-20-010, TC-20-011 | TD-01, TD-02, TD-06, TD-07, TD-08, TD-09 |
| TC-21 | US-01、US-02、US-08 / BR-19 | AC-21 | API-01—API-09 / 全部引用与级联 | TC-21-001, TC-21-002, TC-21-003 | TD-01, TD-07 |
| TC-22 | US-13 / BR-21、BR-22 | AC-22 | API-13 / DB-03、DB-16 | TC-22-001, TC-22-002 | TD-01, TD-02, TD-09 |
| TC-23 | US-13 / BR-23 | AC-23 | API-13 / 分区/归档候选记录 | TC-23-001, TC-23-002, TC-23-003, TC-23-004, TC-23-005, TC-23-006, TC-23-007, TC-23-008 | TD-01, TD-02, TD-06, TD-08, TD-09, TD-10 |
| TC-24 | US-14 / BR-24、BR-25 | AC-24 | API-14 / 用户字段白名单 | TC-24-001, TC-24-002 | TD-01, TD-02, TD-04 |
| TC-25 | US-08、US-11、US-12 / BR-26、BR-27 | AC-25 | API-07、API-11、API-16 / 版本机制 | TC-25-001 | TD-01, TD-07 |
| TC-26 | US-04、US-12 / BR-06、BR-28 | AC-26 | API-10—API-12 / 时间约束 | TC-26-001, TC-26-002, TC-26-003, TC-26-004, TC-26-005 | TD-01, TD-02, TD-06 |
| TC-27 | US-11、US-13 / BR-29 | AC-27 | API-11、API-13 / 故障策略 | TC-27-001, TC-27-002, TC-27-003 | TD-01, TD-09 |
| TC-28 | US-01—US-14 / BR-25、BR-26 | AC-28 | API-01—API-17 / 全部适用字段约束 | TC-28-001, TC-28-002 | TD-01, TD-05 |
| TC-29 | US-01—US-14 / BR-08、BR-19、BR-28 | AC-29 | 适用全部 API / DB-01—DB-18 | TC-29-001, TC-29-002 | TD-01, TD-05, TD-10 |
| TC-30 | US-11、US-13 / BR-17、BR-23、BR-29 | AC-30 | API-11、API-13 / 索引与分区 | TC-30-001 | TD-03, TD-09, TD-10 |

状态覆盖：TD-08每条迁移均有对应的独立状态用例。没有状态列的组织/组/参数/字典等按第六章N/A处理。性能代表性分布、真实迁移旧库、业务适配与可执行路由尚缺资料，分别由Q-13/Q-16/Q-15阻断；本轮不将通用夹具当作这些缺失资料。成员与委托处理等候选API是否纳入本期仍须关闭原Q，不因增加用例自动扩大功能范围。

## 十、逐项验收计划与结果

### 10.1 验收点与放行标准

逐项复用AC-01—AC-30。每项须执行下列全部独立用例，并核对第二章Given/When/Then及对应状态表；用例有多个明确参数组时，每组分别保留结果。任何必要断言尚待Q或没有证据，都不能将该AC标通过。

| AC / 验收点 | 关联需求 / 明确放行标准 | 验证步骤与TC/TD | 所需证据 / 重验范围 |
| --- | --- | --- | --- |
| AC-01 / 应用身份拒绝 | US-11 / BR-01；返回 HTTP 401；不查询委托放行，不执行业务动作 | 按9.3逐例准备→操作→核对前后状态及副作用：TC-01-001, TC-01-002；数据 TD-01, TD-04 | 保存脱敏请求/响应、页面或持久快照、适用日志及执行信息；状态项对照第六章，运行项附原始测量/环境。失败修复后重验本AC全部受影响子例与关联BR/API。 |
| AC-02 / 服务账号认证 | US-01、US-04 / BR-02；拒绝且不签发令牌；合法凭据和合法 IP 的对照组可进入后续认证 | 按9.3逐例准备→操作→核对前后状态及副作用：TC-02-001, TC-02-002, TC-02-003, TC-02-004, TC-02-005；数据 TD-01, TD-04 | 保存脱敏请求/响应、页面或持久快照、适用日志及执行信息；状态项对照第六章，运行项附原始测量/环境。失败修复后重验本AC全部受影响子例与关联BR/API。 |
| AC-03 / 直接静态权限 | US-09、US-11 / BR-03、BR-04；返回 STATIC 与数据范围；不查询委托 | 按9.3逐例准备→操作→核对前后状态及副作用：TC-03-001, TC-03-002, TC-03-003；数据 TD-01, TD-02 | 保存脱敏请求/响应、页面或持久快照、适用日志及执行信息；状态项对照第六章，运行项附原始测量/环境。失败修复后重验本AC全部受影响子例与关联BR/API。 |
| AC-04 / 组织继承 | US-02、US-10 / BR-03、BR-09；仅符合归属规则者继承；同名组织不互相继承 | 按9.3逐例准备→操作→核对前后状态及副作用：TC-04-001, TC-04-002；数据 TD-01, TD-02, TD-09 | 保存脱敏请求/响应、页面或持久快照、适用日志及执行信息；状态项对照第六章，运行项附原始测量/环境。失败修复后重验本AC全部受影响子例与关联BR/API。 |
| AC-05 / 三种数据范围 | US-11 / BR-04、BR-05；各自仅使用批准范围；空集合不放大；行限制不决定按钮许可 | 按9.3逐例准备→操作→核对前后状态及副作用：TC-05-001, TC-05-002, TC-05-003, TC-05-004；数据 TD-01, TD-02, TD-03, TD-05 | 保存脱敏请求/响应、页面或持久快照、适用日志及执行信息；状态项对照第六章，运行项附原始测量/环境。失败修复后重验本AC全部受影响子例与关联BR/API。 |
| AC-06 / 委托兜底条件 | US-11、US-12 / BR-04、BR-06；匹配允许且只允许指定资源；任一不符 HTTP 403 | 按9.3逐例准备→操作→核对前后状态及副作用：TC-06-001, TC-06-002, TC-06-003, TC-06-004, TC-06-005, TC-06-006, TC-06-007；数据 TD-01, TD-02, TD-03, TD-06 | 保存脱敏请求/响应、页面或持久快照、适用日志及执行信息；状态项对照第六章，运行项附原始测量/环境。失败修复后重验本AC全部受影响子例与关联BR/API。 |
| AC-07 / 委托状态和越权 | US-12 / BR-07、BR-18；按批准规则全部拒绝；不能借状态字段或客户端 ID 绕过检查 | 按9.3逐例准备→操作→核对前后状态及副作用：TC-07-001, TC-07-002, TC-07-003, TC-07-004, TC-07-005, TC-07-006；数据 TD-01, TD-02, TD-06 | 保存脱敏请求/响应、页面或持久快照、适用日志及执行信息；状态项对照第六章，运行项附原始测量/环境。失败修复后重验本AC全部受影响子例与关联BR/API。 |
| AC-08 / 静态行权限不兜底 | US-11、US-12 / BR-04、BR-05；按原文不进入委托；不产生修改；若业务需改变须先批准 Q-04 | 按9.3逐例准备→操作→核对前后状态及副作用：TC-08-001；数据 TD-01, TD-02, TD-03 | 保存脱敏请求/响应、页面或持久快照、适用日志及执行信息；状态项对照第六章，运行项附原始测量/环境。失败修复后重验本AC全部受影响子例与关联BR/API。 |
| AC-09 / 账号维护 | US-01 / BR-08、BR-25、BR-26；正常流程成功；重复和只读字段拒绝；输出不含密码散列 | 按9.3逐例准备→操作→核对前后状态及副作用：TC-09-001, TC-09-002, TC-09-003, TC-09-004, TC-09-005, TC-09-006, TC-09-007, TC-09-008, TC-09-009；数据 TD-01, TD-02, TD-05, TD-06, TD-07, TD-08, TD-09 | 保存脱敏请求/响应、页面或持久快照、适用日志及执行信息；状态项对照第六章，运行项附原始测量/环境。失败修复后重验本AC全部受影响子例与关联BR/API。 |
| AC-10 / 组织树一致 | US-02 / BR-09、BR-27；合法树和路径一致；循环/旧版本写入失败，原树保持一致 | 按9.3逐例准备→操作→核对前后状态及副作用：TC-10-001, TC-10-002, TC-10-003, TC-10-004, TC-10-005, TC-10-006；数据 TD-01, TD-02, TD-07 | 保存脱敏请求/响应、页面或持久快照、适用日志及执行信息；状态项对照第六章，运行项附原始测量/环境。失败修复后重验本AC全部受影响子例与关联BR/API。 |
| AC-11 / 跨部门用户组 | US-03 / BR-10、BR-12；成员组合唯一；加入用户组不会自动获得操作权限 | 按9.3逐例准备→操作→核对前后状态及副作用：TC-11-001, TC-11-002, TC-11-003, TC-11-004, TC-11-005, TC-11-006；数据 TD-01, TD-02, TD-07 | 保存脱敏请求/响应、页面或持久快照、适用日志及执行信息；状态项对照第六章，运行项附原始测量/环境。失败修复后重验本AC全部受影响子例与关联BR/API。 |
| AC-12 / 参数字典维护 | US-05、US-06 / BR-08、BR-20；合法流程可用；非法输入及禁止删除拒绝，原值保留 | 按9.3逐例准备→操作→核对前后状态及副作用：TC-12-001, TC-12-002, TC-12-003, TC-12-004, TC-12-005, TC-12-006, TC-12-007, TC-12-008, TC-12-009, TC-12-010, TC-12-011；数据 TD-01, TD-02, TD-05, TD-07 | 保存脱敏请求/响应、页面或持久快照、适用日志及执行信息；状态项对照第六章，运行项附原始测量/环境。失败修复后重验本AC全部受影响子例与关联BR/API。 |
| AC-13 / 操作与权限组 | US-07、US-08 / BR-08、BR-11；合法引用保存；重复操作码/无效操作拒绝；无未批准操作编辑/删除入口 | 按9.3逐例准备→操作→核对前后状态及副作用：TC-13-001, TC-13-002, TC-13-003, TC-13-004, TC-13-005, TC-13-006, TC-13-007, TC-13-008, TC-13-009；数据 TD-01, TD-02, TD-05, TD-07 | 保存脱敏请求/响应、页面或持久快照、适用日志及执行信息；状态项对照第六章，运行项附原始测量/环境。失败修复后重验本AC全部受影响子例与关联BR/API。 |
| AC-14 / 授权关联维护 | US-09、US-10 / BR-12、BR-30；最多一条同组合关联；修改原子完成；重复请求不额外授予 | 按9.3逐例准备→操作→核对前后状态及副作用：TC-14-001, TC-14-002, TC-14-003, TC-14-004, TC-14-005, TC-14-006, TC-14-007, TC-14-008, TC-14-009, TC-14-010, TC-14-011；数据 TD-01, TD-02, TD-07 | 保存脱敏请求/响应、页面或持久快照、适用日志及执行信息；状态项对照第六章，运行项附原始测量/环境。失败修复后重验本AC全部受影响子例与关联BR/API。 |
| AC-15 / 应用注册与绑定 | US-11 / BR-03、BR-13；app_code/app_key 唯一；超额操作拒绝；不得无提示改变其他应用权限 | 按9.3逐例准备→操作→核对前后状态及副作用：TC-15-001, TC-15-002, TC-15-003, TC-15-004, TC-15-005, TC-15-006；数据 TD-01, TD-02, TD-06, TD-08, TD-09 | 保存脱敏请求/响应、页面或持久快照、适用日志及执行信息；状态项对照第六章，运行项附原始测量/环境。失败修复后重验本AC全部受影响子例与关联BR/API。 |
| AC-16 / 授权刷新及撤权 | US-11 / BR-14、BR-17；在批准时限内所有节点拒绝旧权限；无额外密钥轮换 | 按9.3逐例准备→操作→核对前后状态及副作用：TC-16-001；数据 TD-01, TD-07, TD-10 | 保存脱敏请求/响应、页面或持久快照、适用日志及执行信息；状态项对照第六章，运行项附原始测量/环境。失败修复后重验本AC全部受影响子例与关联BR/API。 |
| AC-17 / 主/场景令牌 | US-04 / BR-02、BR-15；正确场景有效；错误/过期拒绝；寿命符合批准 Q-06 | 按9.3逐例准备→操作→核对前后状态及副作用：TC-17-001, TC-17-002, TC-17-003, TC-17-004, TC-17-005；数据 TD-01, TD-02, TD-04, TD-06, TD-08, TD-09 | 保存脱敏请求/响应、页面或持久快照、适用日志及执行信息；状态项对照第六章，运行项附原始测量/环境。失败修复后重验本AC全部受影响子例与关联BR/API。 |
| AC-18 / 并发刷新 | US-04、US-14 / BR-16、BR-30；按批准轮换方案至多一次有效换发；旧令牌不能重复扩大会话 | 按9.3逐例准备→操作→核对前后状态及副作用：TC-18-001, TC-18-002, TC-18-003, TC-18-004；数据 TD-01, TD-02, TD-06, TD-07, TD-08, TD-09 | 保存脱敏请求/响应、页面或持久快照、适用日志及执行信息；状态项对照第六章，运行项附原始测量/环境。失败修复后重验本AC全部受影响子例与关联BR/API。 |
| AC-19 / 退出与注销 | US-04、US-14 / BR-17；只影响批准范围；其他会话按规则保留或撤销；重复不恢复令牌 | 按9.3逐例准备→操作→核对前后状态及副作用：TC-19-001, TC-19-002, TC-19-003；数据 TD-01, TD-02, TD-06, TD-08, TD-09 | 保存脱敏请求/响应、页面或持久快照、适用日志及执行信息；状态项对照第六章，运行项附原始测量/环境。失败修复后重验本AC全部受影响子例与关联BR/API。 |
| AC-20 / 委托申请与处理 | US-12 / BR-06、BR-18、BR-30；申请仅 pending；同幂等键不新增；仅合法转换生效；不自动批准 | 按9.3逐例准备→操作→核对前后状态及副作用：TC-20-001, TC-20-002, TC-20-003, TC-20-004, TC-20-005, TC-20-006, TC-20-007, TC-20-008, TC-20-009, TC-20-010, TC-20-011；数据 TD-01, TD-02, TD-06, TD-07, TD-08, TD-09 | 保存脱敏请求/响应、页面或持久快照、适用日志及执行信息；状态项对照第六章，运行项附原始测量/环境。失败修复后重验本AC全部受影响子例与关联BR/API。 |
| AC-21 / 引用删除 | US-01、US-02、US-08 / BR-19；按批准策略拒绝或完整处理；不能产生半删除、意外级联或丢失审计 | 按9.3逐例准备→操作→核对前后状态及副作用：TC-21-001, TC-21-002, TC-21-003；数据 TD-01, TD-07 | 保存脱敏请求/响应、页面或持久快照、适用日志及执行信息；状态项对照第六章，运行项附原始测量/环境。失败修复后重验本AC全部受影响子例与关联BR/API。 |
| AC-22 / 日志追加与查询 | US-13 / BR-21、BR-22；主体/阶段/结果可区分且脱敏；无主体拒绝可记录；用户不能伪造/修改日志 | 按9.3逐例准备→操作→核对前后状态及副作用：TC-22-001, TC-22-002；数据 TD-01, TD-02, TD-09 | 保存脱敏请求/响应、页面或持久快照、适用日志及执行信息；状态项对照第六章，运行项附原始测量/环境。失败修复后重验本AC全部受影响子例与关联BR/API。 |
| AC-23 / 归档与恢复 | US-13 / BR-23；完整性验证后按策略处理原记录；故障不静默丢数据；恢复可查询 | 按9.3逐例准备→操作→核对前后状态及副作用：TC-23-001, TC-23-002, TC-23-003, TC-23-004, TC-23-005, TC-23-006, TC-23-007, TC-23-008；数据 TD-01, TD-02, TD-06, TD-08, TD-09, TD-10 | 保存脱敏请求/响应、页面或持久快照、适用日志及执行信息；状态项对照第六章，运行项附原始测量/环境。失败修复后重验本AC全部受影响子例与关联BR/API。 |
| AC-24 / 开放用户信息 | US-14 / BR-24、BR-25；仅返回获准账号字段和当前应用权限；不返回散列、密钥、完整令牌 | 按9.3逐例准备→操作→核对前后状态及副作用：TC-24-001, TC-24-002；数据 TD-01, TD-02, TD-04 | 保存脱敏请求/响应、页面或持久快照、适用日志及执行信息；状态项对照第六章，运行项附原始测量/环境。失败修复后重验本AC全部受影响子例与关联BR/API。 |
| AC-25 / 并发编辑 | US-08、US-11、US-12 / BR-26、BR-27；首次成功后，旧版本冲突；保留输入供比较；不静默覆盖 | 按9.3逐例准备→操作→核对前后状态及副作用：TC-25-001；数据 TD-01, TD-07 | 保存脱敏请求/响应、页面或持久快照、适用日志及执行信息；状态项对照第六章，运行项附原始测量/环境。失败修复后重验本AC全部受影响子例与关联BR/API。 |
| AC-26 / 时间边界 | US-04、US-12 / BR-06、BR-28；委托遵循闭区间；过期判断不依赖定时任务；不同偏移表示同一时刻结果相同 | 按9.3逐例准备→操作→核对前后状态及副作用：TC-26-001, TC-26-002, TC-26-003, TC-26-004, TC-26-005；数据 TD-01, TD-02, TD-06 | 保存脱敏请求/响应、页面或持久快照、适用日志及执行信息；状态项对照第六章，运行项附原始测量/环境。失败修复后重验本AC全部受影响子例与关联BR/API。 |
| AC-27 / 依赖故障 | US-11、US-13 / BR-29；按批准故障策略处理；不把异常变成许可；返回诊断标识 | 按9.3逐例准备→操作→核对前后状态及副作用：TC-27-001, TC-27-002, TC-27-003；数据 TD-01, TD-09 | 保存脱敏请求/响应、页面或持久快照、适用日志及执行信息；状态项对照第六章，运行项附原始测量/环境。失败修复后重验本AC全部受影响子例与关联BR/API。 |
| AC-28 / 输入与读取权限 | US-01—US-14 / BR-25、BR-26；遵守第三/五章；大 ID 不丢精度；非法排序不能拼接执行；越权不泄露对象详情 | 按9.3逐例准备→操作→核对前后状态及副作用：TC-28-001, TC-28-002；数据 TD-01, TD-05 | 保存脱敏请求/响应、页面或持久快照、适用日志及执行信息；状态项对照第六章，运行项附原始测量/环境。失败修复后重验本AC全部受影响子例与关联BR/API。 |
| AC-29 / 数据库交付 | US-01—US-14 / BR-08、BR-19、BR-28；结构可建立、约束拒绝非法数据、序列不撞键、恢复结果可核对；本次未执行 | 按9.3逐例准备→操作→核对前后状态及副作用：TC-29-001, TC-29-002；数据 TD-01, TD-05, TD-10 | 保存脱敏请求/响应、页面或持久快照、适用日志及执行信息；状态项对照第六章，运行项附原始测量/环境。失败修复后重验本AC全部受影响子例与关联BR/API。 |
| AC-30 / 运行指标 | US-11、US-13 / BR-17、BR-23、BR-29；按第七章测量边界出报告；未填目标时不得声称达标 | 按9.3逐例准备→操作→核对前后状态及副作用：TC-30-001；数据 TD-03, TD-09, TD-10 | 保存脱敏请求/响应、页面或持久快照、适用日志及执行信息；状态项对照第六章，运行项附原始测量/环境。失败修复后重验本AC全部受影响子例与关联BR/API。 |

### 10.2 逐项实际执行记录

公共执行信息：环境、代码/DDL/策略版本、执行者、时间、实际观察与证据均未提供。本表每行都是未执行业务验收的阻断状态；证据目录仅为计划。

| AC | 状态 | 阻断Q | 实际结果 / 证据 | 环境/版本/人员/时间 |
| --- | --- | --- | --- | --- |
| AC-01 | 阻断 | Q-05、Q-15；尚无业务环境 | 未执行 / 无 | 未提供 |
| AC-02 | 阻断 | Q-05、Q-06、Q-15；尚无业务环境 | 未执行 / 无 | 未提供 |
| AC-03 | 阻断 | Q-03、Q-04、Q-15；尚无业务环境 | 未执行 / 无 | 未提供 |
| AC-04 | 阻断 | Q-02、Q-03、Q-15；尚无业务环境 | 未执行 / 无 | 未提供 |
| AC-05 | 阻断 | Q-02、Q-04、Q-15；尚无业务环境 | 未执行 / 无 | 未提供 |
| AC-06 | 阻断 | Q-03、Q-04、Q-07、Q-11、Q-15；尚无业务环境 | 未执行 / 无 | 未提供 |
| AC-07 | 阻断 | Q-07、Q-08、Q-15；尚无业务环境 | 未执行 / 无 | 未提供 |
| AC-08 | 阻断 | Q-04、Q-15；尚无业务环境 | 未执行 / 无 | 未提供 |
| AC-09 | 阻断 | Q-01、Q-05、Q-08、Q-10、Q-12、Q-15；尚无业务环境 | 未执行 / 无 | 未提供 |
| AC-10 | 阻断 | Q-02、Q-12、Q-15；尚无业务环境 | 未执行 / 无 | 未提供 |
| AC-11 | 阻断 | Q-02、Q-10、Q-12、Q-15；尚无业务环境 | 未执行 / 无 | 未提供 |
| AC-12 | 阻断 | Q-10、Q-14、Q-15；尚无业务环境 | 未执行 / 无 | 未提供 |
| AC-13 | 阻断 | Q-03、Q-12、Q-15；尚无业务环境 | 未执行 / 无 | 未提供 |
| AC-14 | 阻断 | Q-01、Q-12、Q-15；尚无业务环境 | 未执行 / 无 | 未提供 |
| AC-15 | 阻断 | Q-03、Q-05、Q-08、Q-12、Q-15；尚无业务环境 | 未执行 / 无 | 未提供 |
| AC-16 | 阻断 | Q-08、Q-13、Q-15；尚无业务环境 | 未执行 / 无 | 未提供 |
| AC-17 | 阻断 | Q-05、Q-06、Q-11、Q-12、Q-15；尚无业务环境 | 未执行 / 无 | 未提供 |
| AC-18 | 阻断 | Q-06、Q-11、Q-12、Q-15；尚无业务环境 | 未执行 / 无 | 未提供 |
| AC-19 | 阻断 | Q-06、Q-08、Q-11、Q-12、Q-15；尚无业务环境 | 未执行 / 无 | 未提供 |
| AC-20 | 阻断 | Q-07、Q-11、Q-12、Q-15；尚无业务环境 | 未执行 / 无 | 未提供 |
| AC-21 | 阻断 | Q-10、Q-12、Q-15；尚无业务环境 | 未执行 / 无 | 未提供 |
| AC-22 | 阻断 | Q-09、Q-15；尚无业务环境 | 未执行 / 无 | 未提供 |
| AC-23 | 阻断 | Q-09、Q-13、Q-15；尚无业务环境 | 未执行 / 无 | 未提供 |
| AC-24 | 阻断 | Q-01、Q-15；尚无业务环境 | 未执行 / 无 | 未提供 |
| AC-25 | 阻断 | Q-12、Q-15；尚无业务环境 | 未执行 / 无 | 未提供 |
| AC-26 | 阻断 | Q-06、Q-11、Q-15；尚无业务环境 | 未执行 / 无 | 未提供 |
| AC-27 | 阻断 | Q-08、Q-09、Q-15；尚无业务环境 | 未执行 / 无 | 未提供 |
| AC-28 | 阻断 | Q-01、Q-12、Q-14、Q-15；尚无业务环境 | 未执行 / 无 | 未提供 |
| AC-29 | 阻断 | Q-16；尚无业务环境 | 未执行 / 无 | 未提供 |
| AC-30 | 阻断 | Q-08、Q-09、Q-13、Q-15；尚无业务环境 | 未执行 / 无 | 未提供 |

### 10.3 发布放行与重验

- [x] 指定Q责任人并关闭影响本次实现的阻断项，留下选择与批准依据。
- [ ] 14项原文范围及新增候选动作经业务确认；静态失败才委托的分支未被暗改。
- [ ] DDL初始化/迁移、非法数据约束、序列及恢复在批准隔离环境有实际证据。
- [ ] 所有适用TC按版本执行；AC逐项记录真实结果及缺陷；未执行项不能勾成通过。
- [ ] 接入业务完成行过滤、单资源写入拒绝、撤权传播、审计与归档恢复端到端验证。
- [ ] 性能/可用性/恢复指标满足Q-13批准目标，由责任角色签署放行。

Q-02/03/04变化重验组织/静态/范围/委托；Q-05/06/08变化重验认证/令牌/撤权；Q-07变化重验委托；Q-09变化重验审计/归档/故障；Q-10/11/12/16变化重验删除/时间/并发/迁移；Q-15变化重验全部适配和兼容调用方。旧版无业务通过证据可沿用。

本轮完成的是资料梳理、双格式生成、本地合成夹具生成和文档质量验证；实际工具、时间与证据见《交付验证报告》。文档勾选不是测试执行，数据生成检查也不是授权中心业务验收。

## 十一、技术简报与发布

### 11.1 复用事实与拟新增设计

已核实的可复用资料是 14 表的数据概念与原文鉴权步骤；没有核实可复用的授权中心代码。开放令牌接口应与令牌管理共享同一生命周期实现，权限查询应与实际鉴权使用一致的权限计算逻辑，组织成员应优先使用项目已有权威来源。实际复用的类、服务、SDK、迁移工具及公共响应需在代码提供后登记，不能把拟复用写成已存在。

| 设计事项 | 建议方向 | 取舍与放行前提 |
|---|---|---|
| 应用和用户操作组合 | 应用集合限制允许调用的操作，用户直接/组织权限决定主体许可 | 防止只拿 AppKey 或只拿用户权限越界；Q-03 批准 |
| 数据范围结果 | 返回结构化逻辑范围，由业务服务按实际字段执行 | 需要每个接入资源提供映射并验证写入一致性；Q-04 |
| 组织归属 | 先核验既有组织数据来源，再决定关系模型 | 多部门/主部门/下级继承影响广，不能只加一个 dept_id 了事；Q-02 |
| 权限组操作 JSONB | 评审保留 JSONB 与关系表方案 | 保留时承担元素引用和原子完整性校验；关系表有迁移成本；Q-03 |
| 委托 | 绑定应用、资源、操作、时间和明确处理记录 | 明确当前授出权限还是批准快照，组变化不得隐式扩权；Q-07 |
| 缓存和撤权 | 先确定生效时延，再评审版本/失效机制 | 授权刷新不等于换密钥；不能凭性能偏好无限缓存；Q-08 |
| 审计 | 可信追加事件，阶段/主体/授权来源清晰，归档有恢复证据 | 同步阻断与可靠补记各有可用性代价；Q-09 |

### 11.2 建议实施顺序

先完成身份/权限/组织/数据范围等 Q 决策和公共协议核验，再修订数据模型与隔离测试；随后实现账号/组织/操作/组/应用配置、静态鉴权和令牌闭环，再补委托与开放接口，最后验证归档、撤权传播和运行指标。该顺序是依赖安排，不是拆掉原文功能或已承诺里程碑。

### 11.3 发布与恢复

发布负责人需登记实现版本、DDL/迁移版本、目标数据库版本、兼容调用方清单和审批记录。涉及 URL、字段、业务码、ID 序列化、令牌或数据范围变化，必须先验证旧客户端兼容或安排明确切换，不静默改变公共协议。

放行前重点检查 DB-01—DB-03 已有执行证据、默认初始化凭据已替换为安全流程、Q-01—Q-16 的相关阻断范围已关闭、委托不能绕过应用/账号拒绝、静态数据范围已经在真实业务服务落地、撤权和审计故障行为可复现。发布监控与恢复按第四/七章执行计划定稿；本次没有执行部署或数据库变更。

## 十二、待决策事项

所有问题当前状态均为待决策，具体责任人和期限待指定；没有把任何建议标为已批准。阻断的是相关实现/发布放行，不阻断本份需求草案交付。

| Q | 问题与冲突证据 | 选项及建议理由 | 决策角色 | 阻断范围 | 期限/状态/决策证据 |
|---|---|---|---|---|---|
| Q-01 | 是否多租户；管理角色可管理哪些账号、组织、应用和字段；管理员权限如何获得？原文未定义 | 选项：单平台全局范围/按组织或应用委派/租户隔离。先明确业务隔离模型，再决定唯一键和权限矩阵；不能默认所有管理员全权 | 产品、业务、安全负责人 | 全部权限范围、唯一性、开放信息与审计 | 待定 / 待决策 / 无 |
| Q-02 | 账号组织关系缺失；DEPT 原文为所在部门、DDL 为本部门及以下；是否多部门、主部门、跨级继承、用户组参与授权？ | 选项：权威外部组织源/本地成员关系；DEPT 精确所属/所属及后代。建议显式确定成员及继承集合；用户组先仅管理成员，额外授权另批 | 产品、组织业务、技术负责人 | US-02/US-03/US-10、DEPT、API-15、DB-04/DB-07/DB-12 | 待定 / 待决策 / 两份原文存在差异 |
| Q-03 | 应用操作许可与用户权限如何组合；应用是一组还是多组；绑定操作是否会改变共享组？ | 建议应用操作上限与用户权限求交；单组/多组按实际需求决定；绑定应有独立归属与影响范围，不默改共享组。确认权限组 name 唯一性和操作 JSONB/关系表选型 | 产品、安全、技术负责人 | 应用绑定、静态鉴权、委托应用上限、DB-06 | 待定 / 待决策 / 原文未明确 |
| Q-04 | 行范围如何落地；资源字段和归属由谁提供；静态有权但超行范围能否委托；列表/批量无单 ID 时如何判定？ | 保留原文“静态失败才兜底”；如需行失败兜底须显式变更。建议结构化范围+业务服务验证，列表委托枚举/合并或暂不支持需业务选择；批量全成全败/逐项也需确定 | 产品、业务系统、技术、安全负责人 | 数据过滤、单资源写入、列表/批量委托、AC-05/AC-08 | 待定 / 待决策 / S-01 流程明确，覆盖场景不全 |
| Q-05 | 自然人登录方式；AppKey 是否还需 secret/签名；服务账号如何绑定凭据/证书；白名单、可信代理 IP、默认账号和密钥轮换策略？ | 自然人可选用户名密码等已支持方式，不预设手机短信。建议服务账号单独凭据绑定、禁密码、非空白名单；明确证书校验/撤销及 AppSecret 安全存储与首次展示；不投产示例默认凭据 | 安全、身份认证、技术负责人 | 认证、账号创建、应用注册、DB-05/DB-14 | 待定 / 待决策 / 服务账号限制已给定，机制缺失 |
| Q-06 | 1 小时适用于哪些令牌；刷新寿命、Master/Scene 签发/兑换、会话绑定、并发轮换、退出与注销影响范围？ | 建议先明确访问与刷新两种寿命，绑定账号/应用/会话/场景，刷新原子轮换；退出当前会话与管理员注销分开；存摘要还是完整 JWT 根据实际认证实现评审 | 产品、安全、认证/技术负责人 | US-04/US-14、API-10/API-17、DB-08 | 待定 / 待决策 / 原文仅概述类型与 1 小时 |
| Q-07 | 谁申请/批准/拒绝/撤销；是否允许自批/转授；委托绑定哪个应用；grantor 权限和组变化按当前还是快照？ | 建议申请 pending、独立处理人、拒绝独立状态、绑定应用、限可授出的操作和资源、禁止默认自批/转授；当前权限重验与批准快照二选一并定义撤权；明确多委托合并、过期 pending 处理 | 业务、安全、产品、技术负责人 | 整个委托生命周期与兜底、API-12/API-16、DB-09 | 待定 / 待决策 / DDL 状态存在但处理流程缺失 |
| Q-08 | “应用授权刷新”具体含义；冻结/撤权对旧令牌和多节点缓存多久生效；依赖失败和鉴权到执行窗口如何处理？ | 建议授权刷新用于授权重算/失效，与密钥轮换分开；撤权时延先定指标，再选版本和缓存机制；依赖异常拒绝受保护操作 | 产品、安全、技术/运维负责人 | 权限刷新、冻结、撤权传播、资源执行一致性、AC-16/AC-27 | 待定 / 待决策 / 原文没有时延或机制 |
| Q-09 | 日志谁能写/读；未知主体如何记；授权/执行如何区分；审计失败是否阻断；保留/归档/恢复、分区主键如何定？ | 建议可信系统追加、明确未知身份和授权来源/阶段；高风险写同步可靠记录或采用批准的可靠补记；保留/删除先定业务要求，再定分区与归档任务及详情键 | 安全、审计、运维、DBA、技术负责人 | US-13、全链路审计、归档、DB-03/DB-16/DB-17 | 待定 / 待决策 / 未提供运行和保留要求 |
| Q-10 | 删除是物理/软删除/停用；引用如何处理；编码大小写/空值规范化和删除后复用；哪些名称需唯一？ | 建议被授权/被引用对象先明确停用或禁止删除，不默认级联删除应用凭据；对无引用对象按批准删除策略执行；唯一规范化与数据库约束同步 | 产品、业务、安全、DBA | 所有删除和唯一性、DB-13/DB-14 | 待定 / 待决策 / PRD CRUD 与 DDL CASCADE 尚未对齐 |
| Q-11 | 统一时钟/时区、旧 TIMESTAMP 的时区、过期精度、更新时间维护方？ | 建议 API 使用显式偏移时间点，统一服务端比较；迁移前确认旧时间含义；委托保留原文闭区间，不随意改半开区间；updated_at 明确由应用/ORM/触发器之一维护 | 技术、DBA、业务负责人 | token/delegation、日志分区、迁移和时间测试 | 待定 / 待决策 / 原文无时区约定 |
| Q-12 | 编辑全量还是局部；关键写并发/引用竞态/幂等作用域与保留期；超时结果如何查询？ | 建议白名单局部更新和原子版本比较，关系组合唯一，委托申请/凭据签发独立幂等；结果未知先查状态；低风险后写覆盖必须明确接受 | 技术、产品、安全负责人 | 全部写接口、版本字段、事务和重试 | 待定 / 待决策 / DDL 无版本或幂等模型 |
| Q-13 | 性能/容量/可用性、撤权和归档延迟、告警、RTO/RPO 的目标及环境？ | 按第七章测量表补数据规模、分布、负载、分位数、错误率和责任人；先实测基线再批准目标，不抄模板数值 | 产品、技术、测试、运维负责人 | 性能/运行验收和上线容量结论 | 待定 / 待决策 / 无基线或数值 |
| Q-14 | 参数值类型、空串和敏感值、生效方式；字典是字符串数组还是键值对象；引用删除规则？ | 原 DDL 字符串数组可作最小候选；需要标签/编码/禁用状态时再扩展。参数必须有类型/验证和消费方，不默认任意参数控制鉴权 | 产品、配置消费方、技术负责人 | US-05/US-06、字段和引用校验 | 待定 / 待决策 / 只有 TEXT/JSONB 声明 |
| Q-15 | 实际接口方法/URL、响应、业务码、分页、ID 表达、对象不可见错误与开放字段范围？ | 先提供现有协议/代码核验；保留原文鉴权 HTTP 401/403，若采用全 200 需确认兼容；建议 ID 字符串和字段白名单；所有新增码值待分配 | 技术、接入方、安全、产品负责人 | API-01—API-17 的公开实现与兼容性 | 待定 / 待决策 / 未提供既有接口 |
| Q-16 | 后端框架、数据库确切版本、已有库/迁移工具、发布恢复窗口；技能基线是否适用？ | 以本项目实际依赖为准；先修语法/重名/分区问题，再做隔离验证；不自动改 tb_ 或升级 DB，不将示例建库当迁移 | 技术、DBA、运维负责人 | 可执行 DDL、存量兼容、部署/恢复 | 待定 / 待决策 / DDL 与技能背景不同 |

## 文档评审记录

本轮由 Codex 按产品、技术负责人、开发者、业务用户四种视角自检，未调用独立评审人，也不冒充真人批准。后续可在 HTML 中添加针对 US/BR/AC/API/TC/Q 的意见；填写人身份未经验证，意见会写回 Markdown。

| 视角 | 本轮检查结果 | 仍需责任角色确认 |
|---|---|---|
| 产品 | 14 项原文功能均有用户故事、操作范围和验收入口；追加功能标为建议 | 优先级、组织/委托规则、管理范围、成功指标 |
| 技术负责人 | 应用、账号、操作、资源检查分开；数据库阻断、撤权、审计和迁移风险有定位 | 安全设计、数据模型、并发、故障/恢复方案 |
| 开发者 | 字段空值/可写性、状态、接口输入输出和失败效果已列；未知协议未伪造 | 实际 API/框架/DTO/业务码以及所有阻断 Q |
| 业务用户 | 登录、申请、查询、失败提示和冲突后恢复有描述 | 是否符合真实业务场景，静态行范围失败不兜底是否可接受 |

暂无真人评审意见、批准签名或业务验收结果。

全文编辑合成标记。

### RV-MTXXJ36U

> 目标章节：文档说明
> 关联编号：Q-02
> 填写人（未验证）：自动化合成验证
> 记录时间：2026-09-12T05:13:19.590Z

> 合成批注：核对组织范围。<script>window.__prdPwned=1</script>

- [ ] RV-MTXXJ36U 已处理（仅评审事项，不代表业务验收）
